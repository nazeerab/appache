﻿// Decompiled with JetBrains decompiler
// Type: ExceptionHandler.Loger
// Assembly: ExceptionHandler, Version=1.0.0.0, Culture=neutral, PublicKeyToken=0c15d54584087478
// MVID: 5C3E5B5A-7F96-4C3F-B207-DBB70CFB7B69
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\ExceptionHandler.dll

using ExceptionHandler.App_Code;
using System;

namespace ExceptionHandler
{
  public class Loger
  {
    public static void Log(Exception ex)
    {
      new Logger().LogIt(ex);
    }

    public static void Log(string msg)
    {
      new Logger().LogIt(msg);
    }

    public static string ShowPath()
    {
      return new Logger().ShowPath();
    }
  }
}
