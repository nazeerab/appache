﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.ISCCON_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.ISCCON;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BackEndLayers.BLL
{
  public class ISCCON_Manager
  {
    private static List<MessageBodyCreditConfirmationTransaction> GetAll_Group_CC_Transactions(
      string companyCode,
      out TransactionRef_List grpRefs)
    {
      TransactionRef transactionRef1 = new TransactionRef();
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList1 = new CFCS_PAYMENTS_LOG_List();
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList2 = new CFCS_PAYMENTS_LOG_List();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog1 = new CFCS_PAYMENTS_LOG();
      List<MessageBodyCreditConfirmationTransaction> confirmationTransactionList = new List<MessageBodyCreditConfirmationTransaction>();
      MessageBodyCreditConfirmationTransaction confirmationTransaction1 = new MessageBodyCreditConfirmationTransaction();
      MessageBodyCreditConfirmationTransactionInvoiceDetail transactionInvoiceDetail = new MessageBodyCreditConfirmationTransactionInvoiceDetail();
      TransactionData transactionData1 = new TransactionData();
      CFCS_CUSTOMERS cfcsCustomers1 = new CFCS_CUSTOMERS();
      grpRefs = new TransactionRef_List();
      CFCS_PAYMENTS_LOG_List source = CFCS_PAYMENTS_LOG_Manager.Get(companyCode, string.Empty, PaymentStatus.INIT, InqType.GS);
      for (int index1 = 0; index1 < source.Count<CFCS_PAYMENTS_LOG>(); ++index1)
      {
        int payGrpTotInv = (int) source[index1].PAY_GRP_TOT_INV;
        MessageBodyCreditConfirmationTransaction confirmationTransaction2 = new MessageBodyCreditConfirmationTransaction();
        TransactionRef transactionRef2 = new TransactionRef();
        cfcsPaymentsLogList1 = new CFCS_PAYMENTS_LOG_List();
        cfcsPaymentsLog1 = new CFCS_PAYMENTS_LOG();
        CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList3 = CFCS_PAYMENTS_LOG_Manager.Get(companyCode, source[index1].PAY_TXN_REFERENCE, PaymentStatus.INIT, InqType.GD);
        CFCS_PAYMENTS_LOG cfcsPaymentsLog2 = CFCS_PAYMENTS_LOG_Manager.GetItem(companyCode, source[index1].PAY_TXN_REFERENCE, PaymentStatus.INIT, InqType.GX);
        if (payGrpTotInv == cfcsPaymentsLogList3.Count<CFCS_PAYMENTS_LOG>() && ISCCON_Manager.VerifyBalence(cfcsPaymentsLogList3, source[index1].TOTAL_INV_AMOUNT))
        {
          confirmationTransaction2.InvoiceDetail = new MessageBodyCreditConfirmationTransactionInvoiceDetail[cfcsPaymentsLogList3.Count<CFCS_PAYMENTS_LOG>()];
          TransactionData transactionData2 = new TransactionData();
          confirmationTransaction2.SequenceNumber = CFCS_COLC_REF_Manager.Get(source[index1].COMP_CODE);
          transactionData2.Tag_20 = confirmationTransaction2.SequenceNumber;
          transactionData2.Tag_21 = source[index1].CUSTOMER_ID;
          transactionData2.Tag_25 = cfcsPaymentsLog2.CREDT_ACCT_NO;
          transactionData2.Tag_32A.TransDate = source[index1].TRANS_DATE;
          transactionData2.Tag_32A.CreditAcctCrcny = cfcsPaymentsLog2.CREDT_ACCT_CRNCY;
          transactionData2.Tag_32A.CreditAmt = source[index1].TOTAL_INV_AMOUNT;
          if (cfcsPaymentsLog2.TRANS_TYPE.Trim().ToLower() == "cpch")
          {
            transactionData2.Tag_72 = "/PAYTYPE/Cash";
            transactionData2.Tag_50K.Value = "130";
          }
          else
          {
            CFCS_CUSTOMERS cfcsCustomers2 = CFCS_CUSTOMERS_Manager.Get(source[index1].CUSTOMER_ID, companyCode);
            transactionData2.Tag_72 = "/PAYTYPE/Account";
            transactionData2.Tag_50K.DebitAcctNo = cfcsPaymentsLog2.DEBIT_ACCT_NO;
            transactionData2.Tag_50K.CustomerName = cfcsCustomers2.CUSTOMER_NAME;
            transactionData2.Tag_50K.City = cfcsCustomers2.CUSTOMER_CITY;
          }
          for (int index2 = 0; index2 < cfcsPaymentsLogList3.Count<CFCS_PAYMENTS_LOG>(); ++index2)
            confirmationTransaction2.InvoiceDetail[index2] = new MessageBodyCreditConfirmationTransactionInvoiceDetail()
            {
              InvoiceDate = cfcsPaymentsLogList3[index2].INV_DATE.ToString(Util.GetDateFormat()),
              InvoiceNumber = cfcsPaymentsLogList3[index2].INV_NO
            };
          confirmationTransaction2.TransactionData = transactionData2.Print();
          confirmationTransactionList.Add(confirmationTransaction2);
          transactionRef2.TransRef = source[index1].PAY_TXN_REFERENCE;
          transactionRef2.SequenceNo = confirmationTransaction2.SequenceNumber;
          grpRefs.Add(transactionRef2);
        }
      }
      return confirmationTransactionList;
    }

    private static List<MessageBodyCreditConfirmationTransaction> GetAll_Indiviual_CC_Transactions(
      string companyCode,
      out TransactionRef_List indRefs)
    {
      TransactionRef transactionRef1 = new TransactionRef();
      List<MessageBodyCreditConfirmationTransaction> confirmationTransactionList = new List<MessageBodyCreditConfirmationTransaction>();
      MessageBodyCreditConfirmationTransaction confirmationTransaction1 = new MessageBodyCreditConfirmationTransaction();
      MessageBodyCreditConfirmationTransactionInvoiceDetail transactionInvoiceDetail1 = new MessageBodyCreditConfirmationTransactionInvoiceDetail();
      TransactionData transactionData = new TransactionData();
      CFCS_CUSTOMERS cfcsCustomers1 = new CFCS_CUSTOMERS();
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList = new CFCS_PAYMENTS_LOG_List();
      indRefs = new TransactionRef_List();
      CFCS_PAYMENTS_LOG_List source = CFCS_PAYMENTS_LOG_Manager.Get(companyCode, string.Empty, PaymentStatus.INIT, InqType.I);
      for (int index = 0; index < source.Count<CFCS_PAYMENTS_LOG>(); ++index)
      {
        MessageBodyCreditConfirmationTransactionInvoiceDetail transactionInvoiceDetail2 = new MessageBodyCreditConfirmationTransactionInvoiceDetail();
        MessageBodyCreditConfirmationTransaction confirmationTransaction2 = new MessageBodyCreditConfirmationTransaction();
        cfcsCustomers1 = new CFCS_CUSTOMERS();
        TransactionRef transactionRef2 = new TransactionRef();
        if (source[index].INV_NO.Trim() != "")
        {
          transactionInvoiceDetail2.InvoiceNumber = source[index].INV_NO.Trim();
          transactionInvoiceDetail2.InvoiceDate = source[index].INV_DATE.ToString(Util.GetDateFormat());
        }
        else
        {
          transactionInvoiceDetail2.InvoiceNumber = (string) null;
          transactionInvoiceDetail2.InvoiceDate = (string) null;
        }
        confirmationTransaction2.InvoiceDetail = new MessageBodyCreditConfirmationTransactionInvoiceDetail[1];
        confirmationTransaction2.InvoiceDetail[0] = transactionInvoiceDetail2;
        confirmationTransaction2.SequenceNumber = CFCS_COLC_REF_Manager.Get(source[index].COMP_CODE);
        transactionData.Tag_20 = confirmationTransaction2.SequenceNumber;
        transactionData.Tag_21 = source[index].CUSTOMER_ID;
        transactionData.Tag_25 = source[index].CREDT_ACCT_NO;
        transactionData.Tag_32A.TransDate = source[index].TRANS_DATE;
        transactionData.Tag_32A.CreditAcctCrcny = source[index].CREDT_ACCT_CRNCY;
        transactionData.Tag_32A.CreditAmt = source[index].CREDT_AMOUNT;
        if (source[index].TRANS_TYPE.Trim().ToLower() == "cpch")
        {
          transactionData.Tag_72 = "/PAYTYPE/Cash";
          transactionData.Tag_50K.Value = "130";
        }
        else
        {
          CFCS_CUSTOMERS cfcsCustomers2 = CFCS_CUSTOMERS_Manager.Get(source[index].CUSTOMER_ID, companyCode);
          transactionData.Tag_72 = "/PAYTYPE/Account";
          transactionData.Tag_50K.DebitAcctNo = source[index].DEBIT_ACCT_NO;
          transactionData.Tag_50K.CustomerName = cfcsCustomers2.CUSTOMER_NAME;
          transactionData.Tag_50K.City = cfcsCustomers2.CUSTOMER_CITY;
        }
        confirmationTransaction2.TransactionData = transactionData.Print();
        confirmationTransactionList.Add(confirmationTransaction2);
        transactionRef2.SequenceNo = confirmationTransaction2.SequenceNumber;
        transactionRef2.TransRef = source[index].PAY_TXN_REFERENCE;
        indRefs.Add(transactionRef2);
      }
      return confirmationTransactionList;
    }

    private static MessageHeader GetHeader(string companyCode)
    {
      return new MessageHeader()
      {
        MessageType = !(CFCS_COMPANY_PROFILE_Manager.Item(companyCode, "COMPPROF").PAYMENT_TYPE.ToLower().Trim() == "p") ? "ISCCCON-CREDIT" : "CCRES",
        MessageDescription = "Customer Credit Confirmation - Credit",
        Receiver = CFCS_COMPANY_PROFILE_Manager.Item(companyCode, "COMPPROF").COMP_SYS_CODE.Trim().ToUpper(),
        Sender = Codes.BankID,
        TimeStamp = Util.GetTimeStamp()
      };
    }

    private static MessageResponseStatus GetResponseStatus(
      string detail,
      ResponseStatus R)
    {
      MessageResponseStatus messageResponseStatus = new MessageResponseStatus();
      switch (R)
      {
        case ResponseStatus.FAILED:
          messageResponseStatus.StatusCode = R.ToString();
          messageResponseStatus.StatusDetail = detail;
          break;
        case ResponseStatus.NOTR:
          messageResponseStatus.StatusCode = R.ToString();
          messageResponseStatus.StatusDetail = detail.ToString();
          break;
        case ResponseStatus.OK:
          messageResponseStatus.StatusCode = R.ToString();
          messageResponseStatus.StatusDetail = detail.ToString();
          break;
      }
      return messageResponseStatus;
    }

    public static Message GetMessage(
      string companyCode,
      out string fileRef,
      out TransactionRef_List O_grpRefs,
      out TransactionRef_List O_indRefs,
      out bool isNotr)
    {
      isNotr = false;
      Message message = new Message();
      MessageBody messageBody = new MessageBody();
      MessageResponseStatus messageResponseStatus = new MessageResponseStatus();
      List<MessageBodyCreditConfirmationTransaction> confirmationTransactionList1 = new List<MessageBodyCreditConfirmationTransaction>();
      List<MessageBodyCreditConfirmationTransaction> confirmationTransactionList2 = new List<MessageBodyCreditConfirmationTransaction>();
      List<MessageBodyCreditConfirmationTransaction> source = new List<MessageBodyCreditConfirmationTransaction>();
      TransactionRef_List grpRefs = new TransactionRef_List();
      TransactionRef_List indRefs = new TransactionRef_List();
      fileRef = ISCCON_Manager.GetFileRef(companyCode);
      List<MessageBodyCreditConfirmationTransaction> indiviualCcTransactions = ISCCON_Manager.GetAll_Indiviual_CC_Transactions(companyCode, out indRefs);
      List<MessageBodyCreditConfirmationTransaction> groupCcTransactions = ISCCON_Manager.GetAll_Group_CC_Transactions(companyCode, out grpRefs);
      O_grpRefs = grpRefs;
      O_indRefs = indRefs;
      TransactionRef_List transactionRefList1 = ISCCON_Manager.UpdateFileRef(companyCode, fileRef, true, grpRefs);
      TransactionRef_List transactionRefList2 = ISCCON_Manager.UpdateFileRef(companyCode, fileRef, false, indRefs);
      for (int index = 0; index < transactionRefList1.Count<TransactionRef>(); ++index)
        O_grpRefs.Remove(transactionRefList1[index]);
      for (int index = 0; index < transactionRefList2.Count<TransactionRef>(); ++index)
        O_indRefs.Remove(transactionRefList2[index]);
      source.AddRange((IEnumerable<MessageBodyCreditConfirmationTransaction>) ISCCON_Manager.RemoveTransaction(indiviualCcTransactions, transactionRefList2));
      source.AddRange((IEnumerable<MessageBodyCreditConfirmationTransaction>) ISCCON_Manager.RemoveTransaction(groupCcTransactions, transactionRefList1));
      messageBody.CreditConfirmation = new MessageBodyCreditConfirmationTransaction[source.Count<MessageBodyCreditConfirmationTransaction>()];
      messageBody.CreditConfirmation = source.ToArray();
      message.Items = new object[3];
      message.Items[0] = (object) ISCCON_Manager.GetHeader("ARI");
      if (((IEnumerable<MessageBodyCreditConfirmationTransaction>) messageBody.CreditConfirmation).Count<MessageBodyCreditConfirmationTransaction>() > 0)
      {
        MessageResponseStatus responseStatus = ISCCON_Manager.GetResponseStatus("OK", ResponseStatus.OK);
        message.Items[1] = (object) messageBody;
        message.Items[2] = (object) responseStatus;
      }
      else
      {
        isNotr = true;
        MessageResponseStatus responseStatus = ISCCON_Manager.GetResponseStatus("No customer credits received", ResponseStatus.NOTR);
        message.Items[1] = (object) null;
        message.Items[2] = (object) responseStatus;
      }
      return message;
    }

    private static bool VerifyBalence(
      CFCS_PAYMENTS_LOG_List CFCS_PAYMENTS_LOG_List,
      double creditAmt)
    {
      double num = 0.0;
      for (int index = 0; index < CFCS_PAYMENTS_LOG_List.Count<CFCS_PAYMENTS_LOG>(); ++index)
      {
        if (!(CFCS_PAYMENTS_LOG_List[index].CREDT_ACCT_CRNCY.Trim().ToLower() == CFCS_PAYMENTS_LOG_List[index].DEBIT_ACCT_CRNCY.Trim().ToLower()))
          return false;
        num += CFCS_PAYMENTS_LOG_List[index].CREDT_AMOUNT;
      }
      return Math.Round(num, 2) == creditAmt;
    }

    private static List<MessageBodyCreditConfirmationTransaction> RemoveTransaction(
      List<MessageBodyCreditConfirmationTransaction> MessageBodyCreditConfirmationTransaction_List,
      TransactionRef_List TransRef)
    {
      for (int index1 = 0; index1 < TransRef.Count<TransactionRef>(); ++index1)
      {
        for (int index2 = 0; index2 < MessageBodyCreditConfirmationTransaction_List.Count<MessageBodyCreditConfirmationTransaction>(); ++index2)
        {
          if (MessageBodyCreditConfirmationTransaction_List[index2].SequenceNumber.Trim().ToLower() == TransRef[index1].SequenceNo.Trim().ToLower())
          {
            MessageBodyCreditConfirmationTransaction_List.RemoveAt(index2);
            break;
          }
        }
      }
      return MessageBodyCreditConfirmationTransaction_List;
    }

    private static string GetFileRef(string companyCode)
    {
      string empty = string.Empty;
      return Util.GetRef(CFCS_COLC_REF_Manager.Get(companyCode));
    }

    public static MessageBody GetMessageBody(Message M)
    {
      MessageBody messageBody = new MessageBody();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageBody":
                return (MessageBody) M.Items[index];
              default:
                continue;
            }
          }
        }
      }
      return messageBody;
    }

    private static TransactionRef_List UpdateFileRef(
      string compCode,
      string fileRef,
      bool isGrp,
      TransactionRef_List TransactionsRefs)
    {
      CFCS_PAYMENTS_LOG cfcsPaymentsLog = new CFCS_PAYMENTS_LOG();
      TransactionRef_List transactionRefList = new TransactionRef_List();
      for (int index = 0; index < TransactionsRefs.Count<TransactionRef>(); ++index)
      {
        CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG = new CFCS_PAYMENTS_LOG();
        myCFCS_PAYMENTS_LOG.COMP_CODE = compCode;
        myCFCS_PAYMENTS_LOG.CFC_FILE_REF = fileRef;
        myCFCS_PAYMENTS_LOG.CFC_REFERENCE = TransactionsRefs[index].SequenceNo;
        if (isGrp)
        {
          myCFCS_PAYMENTS_LOG.PAY_TXN_REFERENCE = TransactionsRefs[index].TransRef;
          if (CFCS_PAYMENTS_LOG_Manager.Save(myCFCS_PAYMENTS_LOG, UpdateType.G).Code != "0000")
            transactionRefList.Add(TransactionsRefs[index]);
        }
        else
        {
          myCFCS_PAYMENTS_LOG.PAY_TXN_REFERENCE = TransactionsRefs[index].TransRef;
          if (CFCS_PAYMENTS_LOG_Manager.Save(myCFCS_PAYMENTS_LOG, UpdateType.I).Code != "0000")
            transactionRefList.Add(TransactionsRefs[index]);
        }
      }
      return transactionRefList;
    }

    public static TransactionRef_List RollbackFileRef(
      string compCode,
      bool isGrp,
      TransactionRef_List TransactionsRefs)
    {
      CFCS_PAYMENTS_LOG cfcsPaymentsLog = new CFCS_PAYMENTS_LOG();
      TransactionRef_List transactionRefList = new TransactionRef_List();
      for (int index = 0; index < TransactionsRefs.Count<TransactionRef>(); ++index)
      {
        CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG = new CFCS_PAYMENTS_LOG();
        myCFCS_PAYMENTS_LOG.COMP_CODE = compCode;
        myCFCS_PAYMENTS_LOG.CFC_FILE_REF = "";
        myCFCS_PAYMENTS_LOG.CFC_REFERENCE = "";
        if (isGrp)
        {
          myCFCS_PAYMENTS_LOG.PAY_TXN_REFERENCE = TransactionsRefs[index].TransRef;
          if (CFCS_PAYMENTS_LOG_Manager.Save(myCFCS_PAYMENTS_LOG, UpdateType.G).Code != "0000")
            transactionRefList.Add(TransactionsRefs[index]);
        }
        else
        {
          myCFCS_PAYMENTS_LOG.PAY_TXN_REFERENCE = TransactionsRefs[index].TransRef;
          if (CFCS_PAYMENTS_LOG_Manager.Save(myCFCS_PAYMENTS_LOG, UpdateType.I).Code != "0000")
            transactionRefList.Add(TransactionsRefs[index]);
        }
      }
      return transactionRefList;
    }

    public static Message XMLtoISCCON(string path)
    {
      Message message = new Message();
      string xml = Util.ReadFile(path);
      if (xml != null)
      {
        try
        {
          message = Util.DeserializeFromXml<Message>(xml);
        }
        catch (Exception ex)
        {
          throw ex;
        }
      }
      return message;
    }

    public static string ISCCONtoXML(Message Msg)
    {
      string str = string.Empty;
      if (Msg != null)
      {
        try
        {
          str = Util.SerializeToFile<Message>(Msg);
        }
        catch (Exception ex)
        {
          throw ex;
        }
      }
      return str;
    }
  }
}
