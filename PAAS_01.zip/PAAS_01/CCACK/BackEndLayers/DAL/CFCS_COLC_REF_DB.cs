﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.DAL.CFCS_COLC_REF_DB
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using BackEndLayers.BO;
using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace BackEndLayers.DAL
{
  public class CFCS_COLC_REF_DB
  {
    public static Status Get(string companyCode, string type)
    {
      Status status = new Status();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.GET_REFERENCE", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (companyCode == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) companyCode);
          if (type == string.Empty)
            oracleCommand.Parameters.Add("PI_TYPE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_TYPE", (object) type);
          OracleParameter oracleParameter1 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_REFERENCE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          ((DbConnection) conn).Open();
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            status.Code = ((DbParameter) oracleParameter1).Value.ToString();
            status.Description = ((DbParameter) oracleParameter2).Value.ToString();
          }
          catch (Exception ex)
          {
            status.Code = "FAILED";
            status.Description = ex.Message;
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
      return status;
    }
  }
}
