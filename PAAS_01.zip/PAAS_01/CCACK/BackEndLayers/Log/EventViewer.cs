﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.EventViewer
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System.Diagnostics;

namespace BackEndLayers.Log
{
  public static class EventViewer
  {
    private static string Source = "ARAMCOPASS2";

    public static void Log(string sEvent, Eventtype Etype)
    {
      if (sEvent.Length > 32766)
        sEvent = sEvent.Substring(0, 32763) + "...";
      int eventID = (int) Etype;
      if (!EventLog.SourceExists(EventViewer.Source))
        EventLog.CreateEventSource(EventViewer.Source, EventViewer.Source);
      switch (eventID)
      {
        case 1:
          EventLog.WriteEntry(EventViewer.Source, sEvent, EventLogEntryType.Error, eventID);
          break;
        case 2:
          EventLog.WriteEntry(EventViewer.Source, sEvent, EventLogEntryType.Warning, eventID);
          break;
        case 3:
          EventLog.WriteEntry(EventViewer.Source, sEvent, EventLogEntryType.Information, eventID);
          break;
        default:
          EventLog.WriteEntry(EventViewer.Source, sEvent, EventLogEntryType.Error, eventID);
          break;
      }
    }
  }
}
