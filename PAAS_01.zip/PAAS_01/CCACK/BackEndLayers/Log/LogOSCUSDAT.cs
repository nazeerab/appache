﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.LogOSCUSDAT
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSDAT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BackEndLayers.Log
{
  public class LogOSCUSDAT : Logs
  {
    public void Log(
      List<MessageBodyCustomerInfo> TCustomers,
      CFCS_CUSTOMERS_List ValidCustomers,
      string fileName,
      string[] sucess_Status)
    {
      StringBuilder stringBuilder = new StringBuilder();
      int num1 = 0;
      int num2 = 0;
      for (int index1 = 0; index1 < TCustomers.Count<MessageBodyCustomerInfo>(); ++index1)
      {
        bool flag = false;
        for (int index2 = 0; index2 < ValidCustomers.Count<CFCS_CUSTOMERS>(); ++index2)
        {
          if (TCustomers[index1].CustomerID.Trim() == ValidCustomers[index2].CUSTOMER_ID.Trim())
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          ++num2;
      }
      stringBuilder.Append("Process: OSCUSDAT");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Customers: " + TCustomers.Count<MessageBodyCustomerInfo>().ToString());
      stringBuilder.Append(Environment.NewLine);
      for (int index = 0; index < ValidCustomers.Count<CFCS_CUSTOMERS>(); ++index)
      {
        stringBuilder.Append("Invoice Number: " + ValidCustomers[index].CUSTOMER_ID.ToString().Trim());
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("DB Status: " + sucess_Status[index]);
        stringBuilder.Append(Environment.NewLine);
      }
      for (int index = 0; index < ((IEnumerable<string>) sucess_Status).Count<string>(); ++index)
      {
        if (sucess_Status[index] != null)
        {
          if (sucess_Status[index].Trim().ToLower() != "ok")
            ++num2;
          else
            ++num1;
        }
      }
      stringBuilder.Append("OverAll Success: " + num1.ToString() + " / Failed: " + num2.ToString());
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), Eventtype.informaton);
    }

    public void Log(string str, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: OSCUSDAT");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(str);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }

    public void Log(Exception ex, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: OSCUSDAT");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Exception:  " + (object) ex);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }
  }
}
