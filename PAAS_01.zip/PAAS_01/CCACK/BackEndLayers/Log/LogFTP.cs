﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.LogFTP
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using System;
using System.Linq;
using System.Text;

namespace BackEndLayers.Log
{
  public class LogFTP : Logs
  {
    public void Log(PayFile_List Files, PayFile_List Sendfiles)
    {
      int num1 = Files.Count<PayFile>();
      int num2 = Sendfiles.Count<PayFile>();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("ISCONN Totoal Files: " + Files.Count<PayFile>().ToString());
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("ISCONN Received Files");
      stringBuilder.Append(Environment.NewLine);
      if (num1 > 0)
      {
        for (int index = 0; index < Files.Count<PayFile>(); ++index)
        {
          stringBuilder.Append("[" + Files[index].Name + ", " + Files[index].FileRef + "]");
          stringBuilder.Append(Environment.NewLine);
        }
      }
      else
        stringBuilder.Append("No file found.");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("ISCONN Totoal Files Sent: " + Sendfiles.Count<PayFile>().ToString());
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("ISCONN Sent Files");
      stringBuilder.Append(Environment.NewLine);
      if (num2 > 0)
      {
        for (int index = 0; index < Sendfiles.Count<PayFile>(); ++index)
        {
          stringBuilder.Append("[" + Sendfiles[index].Name + ", " + Sendfiles[index].FileRef + "]");
          stringBuilder.Append(Environment.NewLine);
        }
      }
      else
        stringBuilder.Append("No file found.");
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), Eventtype.informaton);
    }

    public void Log(string str, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: FTP");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(str);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }

    public void Log(Exception ex, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: FTP");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Exception:  " + (object) ex);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }

    public void Log(Exception ex, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: FTP");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Exception:  " + (object) ex);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }
  }
}
