﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Header
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.ComponentModel;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "Header")]
  [Serializable]
  public class Header
  {
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(DataType = "string", ElementName = "Sender", IsNullable = false)]
    public string __Sender;
    [XmlElement(DataType = "string", ElementName = "Receiver", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __Receiver;
    [XmlElement(DataType = "string", ElementName = "MessageType", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __MessageType;
    [XmlElement(DataType = "string", ElementName = "MessageDescription", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __MessageDescription;
    [XmlElement(DataType = "string", ElementName = "TimeStamp", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __TimeStamp;

    [XmlIgnore]
    [NotEmptyStringValidator("Sender should not be empty.")]
    public string Sender
    {
      get
      {
        return this.__Sender;
      }
      set
      {
        this.__Sender = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("Receiver should not be empty.")]
    public string Receiver
    {
      get
      {
        return this.__Receiver;
      }
      set
      {
        this.__Receiver = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("MessageType should not be empty.")]
    public string MessageType
    {
      get
      {
        return this.__MessageType;
      }
      set
      {
        this.__MessageType = value;
      }
    }

    [NotEmptyStringValidator("MessageDescription should not be empty.")]
    [XmlIgnore]
    public string MessageDescription
    {
      get
      {
        return this.__MessageDescription;
      }
      set
      {
        this.__MessageDescription = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("TimeStamp should not be empty.")]
    public string TimeStamp
    {
      get
      {
        return this.__TimeStamp;
      }
      set
      {
        this.__TimeStamp = value;
      }
    }
  }
}
