﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Body
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.Collections;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "Body")]
  [Serializable]
  public class Body
  {
    [XmlElement(ElementName = "CreditConfirmationAck", IsNullable = false, Type = typeof (CreditConfirmationAck))]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public CreditConfirmationAckCollection __CreditConfirmationAckCollection;

    [DispId(-4)]
    public IEnumerator GetEnumerator()
    {
      return this.CreditConfirmationAckCollection.GetEnumerator();
    }

    public CreditConfirmationAck Add(CreditConfirmationAck obj)
    {
      return this.CreditConfirmationAckCollection.Add(obj);
    }

    [XmlIgnore]
    public CreditConfirmationAck this[int index]
    {
      get
      {
        return this.CreditConfirmationAckCollection[index];
      }
    }

    [XmlIgnore]
    public int Count
    {
      get
      {
        return this.CreditConfirmationAckCollection.Count;
      }
    }

    public void Clear()
    {
      this.CreditConfirmationAckCollection.Clear();
    }

    public CreditConfirmationAck Remove(int index)
    {
      CreditConfirmationAck creditConfirmationAck = this.CreditConfirmationAckCollection[index];
      this.CreditConfirmationAckCollection.Remove(creditConfirmationAck);
      return creditConfirmationAck;
    }

    public void Remove(object obj)
    {
      this.CreditConfirmationAckCollection.Remove(obj);
    }

    [XmlIgnore]
    public CreditConfirmationAckCollection CreditConfirmationAckCollection
    {
      get
      {
        if (this.__CreditConfirmationAckCollection == null)
          this.__CreditConfirmationAckCollection = new CreditConfirmationAckCollection();
        return this.__CreditConfirmationAckCollection;
      }
      set
      {
        this.__CreditConfirmationAckCollection = value;
      }
    }
  }
}
