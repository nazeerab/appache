﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Report
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class Report
  {
    private string _detail = string.Empty;
    private string _code = string.Empty;

    public string Detail
    {
      get
      {
        return this._detail;
      }
      set
      {
        this._detail = value;
      }
    }

    public string Code
    {
      get
      {
        return this._code;
      }
      set
      {
        this._code = value;
      }
    }
  }
}
