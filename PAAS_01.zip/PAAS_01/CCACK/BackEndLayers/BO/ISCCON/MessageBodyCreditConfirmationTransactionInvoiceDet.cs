﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.MessageBodyCreditConfirmationTransactionInvoiceDetail
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.ISCCON
{
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [DesignerCategory("code")]
  [XmlType(AnonymousType = true)]
  [Serializable]
  public class MessageBodyCreditConfirmationTransactionInvoiceDetail
  {
    private string invoiceNumberField;
    private string invoiceDateField;

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceNumber
    {
      get
      {
        return this.invoiceNumberField;
      }
      set
      {
        this.invoiceNumberField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceDate
    {
      get
      {
        return this.invoiceDateField;
      }
      set
      {
        this.invoiceDateField = value;
      }
    }
  }
}
