﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.TransactionRef
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

namespace BackEndLayers.BO.ISCCON
{
  public class TransactionRef
  {
    private string _transRef = string.Empty;
    private string _sequenceNo = string.Empty;

    public string TransRef
    {
      get
      {
        return this._transRef;
      }
      set
      {
        this._transRef = value;
      }
    }

    public string SequenceNo
    {
      get
      {
        return this._sequenceNo;
      }
      set
      {
        this._sequenceNo = value;
      }
    }
  }
}
