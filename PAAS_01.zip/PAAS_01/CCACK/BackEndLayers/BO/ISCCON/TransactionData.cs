﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.TransactionData
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.Text;

namespace BackEndLayers.BO.ISCCON
{
  public class TransactionData
  {
    private string _tag_20 = string.Empty;
    private string _tag_21 = string.Empty;
    private string _tag_25 = string.Empty;
    private Tag32A _tag_32A = new Tag32A();
    private Tag50K _tag_50K = new Tag50K();
    private string _tag_72 = string.Empty;

    public string Tag_20
    {
      get
      {
        return this._tag_20;
      }
      set
      {
        this._tag_20 = value;
      }
    }

    public string Tag_21
    {
      get
      {
        return this._tag_21;
      }
      set
      {
        this._tag_21 = value;
      }
    }

    public string Tag_25
    {
      get
      {
        return this._tag_25;
      }
      set
      {
        this._tag_25 = value;
      }
    }

    public Tag32A Tag_32A
    {
      get
      {
        return this._tag_32A;
      }
      set
      {
        this._tag_32A = value;
      }
    }

    public Tag50K Tag_50K
    {
      get
      {
        return this._tag_50K;
      }
      set
      {
        this._tag_50K = value;
      }
    }

    public string Tag_72
    {
      get
      {
        return this._tag_72;
      }
      set
      {
        this._tag_72 = value;
      }
    }

    public string Print()
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(":20:");
      stringBuilder.Append(this._tag_20);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(":21:");
      stringBuilder.Append(this._tag_21);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(":25:");
      stringBuilder.Append(this.Tag_25);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(":32A:");
      stringBuilder.Append(this._tag_32A.TransDate.ToString("yyMMdd"));
      stringBuilder.Append(this._tag_32A.CreditAcctCrcny);
      stringBuilder.Append(string.Format("{0:0.00}", (object) this._tag_32A.CreditAmt).Replace(".", ","));
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(":50K:");
      stringBuilder.Append("/");
      if (this._tag_50K.Value.Trim() != "")
      {
        stringBuilder.Append(this._tag_50K.Value);
      }
      else
      {
        stringBuilder.Append(this._tag_50K.DebitAcctNo);
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append(this._tag_50K.CustomerName);
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append(this._tag_50K.City);
        stringBuilder.Append(Environment.NewLine);
      }
      stringBuilder.Append(":72:");
      stringBuilder.Append(this._tag_72);
      stringBuilder.Append(Environment.NewLine);
      return stringBuilder.ToString();
    }
  }
}
