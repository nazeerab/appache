﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.MessageBodyCreditConfirmationTransaction
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.ISCCON
{
  [DebuggerStepThrough]
  [XmlType(AnonymousType = true)]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DesignerCategory("code")]
  [Serializable]
  public class MessageBodyCreditConfirmationTransaction
  {
    private string sequenceNumberField;
    private string transactionDataField;
    private MessageBodyCreditConfirmationTransactionInvoiceDetail[] invoiceDetailField;

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string SequenceNumber
    {
      get
      {
        return this.sequenceNumberField;
      }
      set
      {
        this.sequenceNumberField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string TransactionData
    {
      get
      {
        return this.transactionDataField;
      }
      set
      {
        this.transactionDataField = value;
      }
    }

    [XmlElement("InvoiceDetail", Form = XmlSchemaForm.Unqualified)]
    public MessageBodyCreditConfirmationTransactionInvoiceDetail[] InvoiceDetail
    {
      get
      {
        return this.invoiceDetailField;
      }
      set
      {
        this.invoiceDetailField = value;
      }
    }
  }
}
