﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.Tag32A
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;

namespace BackEndLayers.BO.ISCCON
{
  public class Tag32A
  {
    private DateTime _transDate = new DateTime();
    private string _creditAcctCrcny = string.Empty;
    private double _creditAmt;

    public DateTime TransDate
    {
      get
      {
        return this._transDate;
      }
      set
      {
        this._transDate = value;
      }
    }

    public string CreditAcctCrcny
    {
      get
      {
        return this._creditAcctCrcny;
      }
      set
      {
        this._creditAcctCrcny = value;
      }
    }

    public double CreditAmt
    {
      get
      {
        return this._creditAmt;
      }
      set
      {
        this._creditAmt = value;
      }
    }
  }
}
