﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Collections.CFCS_PAYMENTS_LOG_List
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System.Collections.Generic;

namespace BackEndLayers.BO.Collections
{
  public class CFCS_PAYMENTS_LOG_List : List<CFCS_PAYMENTS_LOG>
  {
  }
}
