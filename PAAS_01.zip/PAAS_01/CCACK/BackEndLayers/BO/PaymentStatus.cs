﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.PaymentStatus
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public enum PaymentStatus
  {
    INIT = 1,
    CONF = 2,
    ACK = 3,
    REJC = 4,
  }
}
