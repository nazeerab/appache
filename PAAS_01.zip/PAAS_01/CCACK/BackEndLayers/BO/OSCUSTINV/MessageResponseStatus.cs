﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.OSCUSTINV.MessageResponseStatus
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.OSCUSTINV
{
  [DesignerCategory("code")]
  [DebuggerStepThrough]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [XmlType(AnonymousType = true)]
  [Serializable]
  public class MessageResponseStatus
  {
    private string statusCodeField;
    private string statusDetailField;

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string StatusCode
    {
      get
      {
        return this.statusCodeField;
      }
      set
      {
        this.statusCodeField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string StatusDetail
    {
      get
      {
        return this.statusDetailField;
      }
      set
      {
        this.statusDetailField = value;
      }
    }
  }
}
