﻿// Decompiled with JetBrains decompiler
// Type: Validation.LengthValidatorAttribute
// Assembly: Validation, Version=1.0.0.0, Culture=neutral, PublicKeyToken=1a90df434b5983da
// MVID: 1C021FFF-105C-494E-A893-F630EC01D70B
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\Validation.dll

using System;

namespace Validation
{
  public class LengthValidatorAttribute : ValidatorAttribute
  {
    private int _maxLength;
    private int _minLength;

    public int MinLength
    {
      get
      {
        return this._minLength;
      }
      set
      {
        this._minLength = value;
      }
    }

    public int MaxLength
    {
      get
      {
        return this._maxLength;
      }
      set
      {
        this._maxLength = value;
      }
    }

    public LengthValidatorAttribute(string message)
      : base(message)
    {
      this._maxLength = 0;
      this._minLength = 0;
    }

    internal override bool IsValid(object item)
    {
      return (this._maxLength <= 0 || item == null || Convert.ToString(item).Length <= this.MaxLength) && (this._minLength <= 0 || item != null && Convert.ToString(item).Length >= this.MinLength);
    }
  }
}
