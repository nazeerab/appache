﻿// Decompiled with JetBrains decompiler
// Type: Validation.StringNotContainsAllZerosAttribute
// Assembly: Validation, Version=1.0.0.0, Culture=neutral, PublicKeyToken=1a90df434b5983da
// MVID: 1C021FFF-105C-494E-A893-F630EC01D70B
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\Validation.dll

using System;
using System.Text.RegularExpressions;

namespace Validation
{
  public class StringNotContainsAllZerosAttribute : ValidatorAttribute
  {
    private string res = string.Empty;

    public StringNotContainsAllZerosAttribute(string message)
      : base(message)
    {
    }

    internal override bool IsValid(object item)
    {
      if (item != null)
      {
        this.res = Convert.ToString(item);
        if (!(this.res != "") || StringNotContainsAllZerosAttribute.IsAllZeros(this.res))
          return false;
      }
      return true;
    }

    private static bool IsAllZeros(string acctNo)
    {
      Regex regex = new Regex("^([\\d]*[1-9]+[\\d]*)$");
      return !(acctNo.Trim() != "") || !regex.IsMatch(acctNo.Trim());
    }
  }
}
