﻿// Decompiled with JetBrains decompiler
// Type: Validation.ValidationExceptionDetail
// Assembly: Validation, Version=1.0.0.0, Culture=neutral, PublicKeyToken=1a90df434b5983da
// MVID: 1C021FFF-105C-494E-A893-F630EC01D70B
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\Validation.dll

namespace Validation
{
  public class ValidationExceptionDetail
  {
    private string _propertyName;
    private string _message;

    public ValidationExceptionDetail(string propertyName, string message)
    {
      this._propertyName = propertyName;
      this._message = message;
    }

    public ValidationExceptionDetail(string message)
      : this(string.Empty, message)
    {
    }

    public string PropertyName
    {
      get
      {
        return this._propertyName;
      }
      set
      {
        this._propertyName = value;
      }
    }

    public string Message
    {
      get
      {
        return this._message;
      }
      set
      {
        this._message = value;
      }
    }
  }
}
