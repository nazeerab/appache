﻿// Decompiled with JetBrains decompiler
// Type: Validation.IntRangeValidatorAttribute
// Assembly: Validation, Version=1.0.0.0, Culture=neutral, PublicKeyToken=1a90df434b5983da
// MVID: 1C021FFF-105C-494E-A893-F630EC01D70B
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\Validation.dll

using System;

namespace Validation
{
  public class IntRangeValidatorAttribute : ValidatorAttribute
  {
    private int _maxRange;
    private int _minRange;

    public int MaxRange
    {
      get
      {
        return this._maxRange;
      }
      set
      {
        this._maxRange = value;
      }
    }

    public int MinRange
    {
      get
      {
        return this._minRange;
      }
      set
      {
        this._minRange = value;
      }
    }

    public IntRangeValidatorAttribute(string message)
      : base(message)
    {
      this._maxRange = 0;
      this._minRange = 0;
    }

    internal override bool IsValid(object item)
    {
      return (this._maxRange <= 0 || item == null || Convert.ToInt32(item) <= this.MaxRange) && (this._minRange <= 0 || item != null && Convert.ToInt32(item) >= this.MinRange);
    }
  }
}
