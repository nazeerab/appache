﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCopyright("Copyright © BSF 2010")]
[assembly: AssemblyTitle("Validation")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("Validation")]
[assembly: Guid("981c546d-efef-4d94-b768-eb89e5fcadbe")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
