﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CCACK")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("CCACK")]
[assembly: AssemblyCopyright("Copyright © BSF 2011")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("2142d886-496d-4813-a269-45bef7d9e40c")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
