﻿// Decompiled with JetBrains decompiler
// Type: CCACK.Program
// Assembly: CCACK, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4269F6C7-3D06-4F1A-8AC7-F82260A398A1
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\CCACK.exe

using BackEndLayers.BLL;
using BackEndLayers.BO;
using BackEndLayers.BO.CCACK;
using BackEndLayers.Log;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CCACK
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      DateTime now = DateTime.Now;
      Message message1 = new Message();
      Reports reports = new Reports();
      Fin_Out_TuxMsg finOutTuxMsg = new Fin_Out_TuxMsg();
      Status status1 = new Status();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog = new CFCS_PAYMENTS_LOG();
      LogCCACK logCcack = new LogCCACK();
      List<Transaction> Valid_ACK = new List<Transaction>();
      List<Transaction> transactionList = new List<Transaction>();
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string fileName = string.Empty;
      string empty3 = string.Empty;
      string reply = string.Empty;
      bool isValid = false;
      bool flag = true;
      Console.WriteLine("Process CCACK is started.");
      try
      {
        string companyCode = args[0];
        Console.WriteLine("Company Code: " + companyCode);
        string str = args[1];
        Console.WriteLine("File path: " + str);
        fileName = Util.GetFileName(str);
        Console.WriteLine("File name: " + fileName);
        Console.WriteLine("Parsing message.");
        Message message2 = CCACK_Manager.XMLtoCCACK(str);
        Console.WriteLine("Parsing message done.");
        Console.WriteLine("Fetching Acks done.");
        List<Transaction> ackTransaction = CCACK_Manager.GetAckTransaction(message2);
        Console.WriteLine("Fetching Acks done.");
        Console.WriteLine("Runing validation on message.");
        Reports R = CCACKValidation_Manager.MessageValidation(message2, fileName, companyCode, out Valid_ACK, out isValid);
        Console.WriteLine("Validation on message done.");
        DateTime businessDate = Util.GetBusinessDate();
        switch (isValid)
        {
          case false:
            logCcack.Log(Util.PrintReport(R), fileName, Eventtype.informaton);
            Console.WriteLine(Util.PrintReport(R));
            break;
          case true:
            for (int index = 0; index < Valid_ACK.Count<Transaction>(); ++index)
            {
              switch (Valid_ACK[index].StatusCode.Trim().ToLower())
              {
                case "ok":
                  try
                  {
                    string msg = Tuxedo_Manager.TuxMsgIn(CFCS_COLC_REF_Manager.Get(companyCode), Valid_ACK[index].SequenceNumber, Valid_ACK[index].AckNumber, companyCode, Valid_ACK[index].StatusCode, businessDate.ToString("yyyyMMdd"));
                    try
                    {
                      Valid_ACK[index].TuxMsgIn = msg;
                      finOutTuxMsg = Tuxedo_Manager.Tuxedo(msg, out reply);
                      Valid_ACK[index].TuxMsgOut = reply;
                    }
                    catch (Exception ex)
                    {
                      Valid_ACK[index].TuxMsgOut = "Tuxedo Failure|" + ex.Message;
                      finOutTuxMsg.CAMMActionCode = "";
                      finOutTuxMsg.FTSActionCode = "";
                    }
                    if (finOutTuxMsg.CAMMActionCode == "0000" && finOutTuxMsg.FTSActionCode == "0000")
                    {
                      Valid_ACK[index].IsTux = true;
                      Status status2 = CFCS_PAYMENTS_LOG_Manager.SavePayment(new CFCS_PAYMENTS_LOG()
                      {
                        COMP_CODE = companyCode,
                        CFC_REFERENCE = Valid_ACK[index].SequenceNumber,
                        COMP_ACK_REFERENCE = Valid_ACK[index].AckNumber,
                        PAYMENT_STATUS = PaymentStatus.ACK.ToString(),
                        COMP_ACTION_REMARKS = Valid_ACK[index].StatusDetail.Trim()
                      });
                      if (status2.Code == "0000")
                      {
                        Valid_ACK[index].IsDb = true;
                        break;
                      }
                      Valid_ACK[index].IsDb = false;
                      Valid_ACK[index].DbFailReason = "DB Failure | " + status2.Code + "|" + status2.Description;
                      break;
                    }
                    throw new Exception("Tuxedo  failure, verify tuxedo message. CAMM = " + finOutTuxMsg.CAMMActionCode.Trim() + " ,FTS = " + finOutTuxMsg.FTSActionCode.Trim() + ".");
                  }
                  catch (Exception ex)
                  {
                    logCcack.Log(ex, fileName, Eventtype.Error);
                    break;
                  }
                case "de":
                  try
                  {
                    string msg = Tuxedo_Manager.TuxMsgIn(CFCS_COLC_REF_Manager.Get(companyCode), Valid_ACK[index].SequenceNumber, Valid_ACK[index].AckNumber, companyCode, Valid_ACK[index].StatusCode, businessDate.ToString("yyyyMMdd"));
                    try
                    {
                      Valid_ACK[index].TuxMsgIn = msg;
                      finOutTuxMsg = Tuxedo_Manager.Tuxedo(msg, out reply);
                      Valid_ACK[index].TuxMsgOut = reply;
                    }
                    catch (Exception ex)
                    {
                      Valid_ACK[index].TuxMsgOut = "Tuxedo failure|" + ex.Message;
                      finOutTuxMsg.CAMMActionCode = "";
                      finOutTuxMsg.FTSActionCode = "";
                    }
                    if (finOutTuxMsg.CAMMActionCode == "0000" && finOutTuxMsg.FTSActionCode == "0000")
                    {
                      Valid_ACK[index].IsTux = true;
                      Status status2 = CFCS_PAYMENTS_LOG_Manager.SavePayment(new CFCS_PAYMENTS_LOG()
                      {
                        COMP_CODE = companyCode,
                        CFC_REFERENCE = Valid_ACK[index].SequenceNumber,
                        COMP_ACK_REFERENCE = string.Empty,
                        PAYMENT_STATUS = PaymentStatus.REJC.ToString(),
                        COMP_ACTION_REMARKS = Valid_ACK[index].StatusDetail.Trim()
                      });
                      if (status2.Code == "0000")
                      {
                        Valid_ACK[index].IsDb = true;
                        break;
                      }
                      Valid_ACK[index].IsDb = false;
                      Valid_ACK[index].DbFailReason = "DB Failure | " + status2.Code + "|" + status2.Description;
                      break;
                    }
                    throw new Exception("Tuxedo  failure, verify tuxedo message. CAMM = " + finOutTuxMsg.CAMMActionCode.Trim() + " ,FTS = " + finOutTuxMsg.FTSActionCode.Trim() + ".");
                  }
                  catch (Exception ex)
                  {
                    logCcack.Log(ex, fileName, Eventtype.Error);
                    break;
                  }
                default:
                  logCcack.Log("Wrong status found", fileName, Eventtype.Warning);
                  break;
              }
            }
            logCcack.Log(fileName, Valid_ACK, ackTransaction, R);
            break;
        }
      }
      catch (IndexOutOfRangeException ex)
      {
        logCcack.Log((Exception) ex, fileName, Eventtype.Error);
        Console.WriteLine("Please provide compnay code as args[0] and path as args[1]");
        flag = false;
      }
      catch (Exception ex)
      {
        logCcack.Log(ex, fileName, Eventtype.Error);
        Console.WriteLine("Application terminated unsuccessfully, please check logs for detail.");
        flag = false;
      }
      if (flag)
        Console.WriteLine("Process end with Success.");
      else
        Console.WriteLine("Process end with Failure.");
      Console.WriteLine("Process tooks " + (DateTime.Now - now).Milliseconds.ToString() + " MS to compelete.");
    }
  }
}
