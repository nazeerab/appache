﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Codes
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace BackEndLayers
{
  [DebuggerNonUserCode]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
  [CompilerGenerated]
  internal class Codes
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Codes()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) Codes.resourceMan, (object) null))
          Codes.resourceMan = new ResourceManager("BackEndLayers.Codes", typeof (Codes).Assembly);
        return Codes.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return Codes.resourceCulture;
      }
      set
      {
        Codes.resourceCulture = value;
      }
    }

    internal static string BankID
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (BankID), Codes.resourceCulture);
      }
    }

    internal static string CompanyCode
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (CompanyCode), Codes.resourceCulture);
      }
    }

    internal static string MessageParametersInvalid
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (MessageParametersInvalid), Codes.resourceCulture);
      }
    }

    internal static string MessageType
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (MessageType), Codes.resourceCulture);
      }
    }

    internal static string Sender
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (Sender), Codes.resourceCulture);
      }
    }

    internal static string StatusCode
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (StatusCode), Codes.resourceCulture);
      }
    }

    internal static string StatusDetail
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (StatusDetail), Codes.resourceCulture);
      }
    }

    internal static string XMLMessageParametersMissing
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (XMLMessageParametersMissing), Codes.resourceCulture);
      }
    }
  }
}
