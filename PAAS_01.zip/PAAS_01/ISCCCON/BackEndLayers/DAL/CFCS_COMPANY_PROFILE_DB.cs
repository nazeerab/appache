﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.DAL.CFCS_COMPANY_PROFILE_DB
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace BackEndLayers.DAL
{
  public class CFCS_COMPANY_PROFILE_DB
  {
    public static CFCS_COMPANY_PROFILE_List GetList(
      string COMP_CODE,
      string TYPE)
    {
      CFCS_COMPANY_PROFILE_List companyProfileList = new CFCS_COMPANY_PROFILE_List();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("cfcs_pkg.get_comp_dets", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) COMP_CODE, ParameterDirection.Input);
          if (TYPE == string.Empty)
            oracleCommand.Parameters.Add("PI_TYPE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_TYPE", OracleDbType.Varchar2, (object) TYPE, ParameterDirection.Input);
          oracleCommand.Parameters.Add("PO_CUR_INVC", OracleDbType.RefCursor, (object) DBNull.Value, ParameterDirection.Output);
          ((DbConnection) conn).Open();
          using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader())
          {
            if (((DbDataReader) oracleDataReader).HasRows)
            {
              while (((DbDataReader) oracleDataReader).Read())
                companyProfileList.Add(CFCS_COMPANY_PROFILE_DB.FillDataRecord((IDataRecord) oracleDataReader));
            }
            ((DbDataReader) oracleDataReader).Close();
          }
          ((DbConnection) conn).Close();
        }
      }
      return companyProfileList;
    }

    public static CFCS_COMPANY_PROFILE Item(string COMP_CODE, string TYPE)
    {
      CFCS_COMPANY_PROFILE cfcsCompanyProfile = new CFCS_COMPANY_PROFILE();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("cfcs_pkg.get_comp_dets", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) COMP_CODE, ParameterDirection.Input);
          if (TYPE == string.Empty)
            oracleCommand.Parameters.Add("PI_TYPE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_TYPE", OracleDbType.Varchar2, (object) TYPE, ParameterDirection.Input);
          oracleCommand.Parameters.Add("PO_CUR_INVC", OracleDbType.RefCursor, ParameterDirection.Output);
          ((DbConnection) conn).Open();
          using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader())
          {
            if (((DbDataReader) oracleDataReader).HasRows)
              cfcsCompanyProfile = CFCS_COMPANY_PROFILE_DB.FillDataRecord((IDataRecord) oracleDataReader);
            ((DbDataReader) oracleDataReader).Close();
          }
          ((DbConnection) conn).Close();
        }
      }
      return cfcsCompanyProfile;
    }

    private static CFCS_COMPANY_PROFILE FillDataRecord(IDataRecord myDataRecord)
    {
      CFCS_COMPANY_PROFILE cfcsCompanyProfile = new CFCS_COMPANY_PROFILE();
      int fieldCount = myDataRecord.FieldCount;
      for (int i = 0; i < fieldCount; ++i)
      {
        switch (myDataRecord.GetName(i))
        {
          case "COMP_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.COMP_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "DESCR_ENG":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.DESCR_ENG = myDataRecord.GetString(i);
              break;
            }
            break;
          case "DESCR_ARB":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.DESCR_ENG = myDataRecord.GetString(i);
              break;
            }
            break;
          case "STATUS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.STATUS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "PAYMENT_MODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.PAYMENT_MODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "PAYMENT_TYPE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.PAYMENT_TYPE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "BSF_MAINTAINS_ID":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.PAYMENT_TYPE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "ID_LENGTH":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.ID_LENGTH = Convert.ToDouble(myDataRecord.GetDecimal(i));
              break;
            }
            break;
          case "CREATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.CREATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.CREATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "UPDATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.UPDATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "UPDATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.UPDATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "INCOMING_TRF_ALLOWED":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.INCOMING_TRF_ALLOWED = myDataRecord.GetString(i);
              break;
            }
            break;
          case "COMP_SYS_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.COMP_SYS_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CRNCY_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCompanyProfile.CRNCY_Code = myDataRecord.GetString(i);
              break;
            }
            break;
          default:
            throw new Exception("New column found in CFCS_COMPANY_PROFILE or column name not matched, verify data persistence over class", new Exception("myCFCS_COMPANY_PROFILE filling failed"));
        }
      }
      return cfcsCompanyProfile;
    }
  }
}
