﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CCACK_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO.CCACK;
using System;
using System.Collections.Generic;

namespace BackEndLayers.BLL
{
  public class CCACK_Manager
  {
    public static Message XMLtoCCACK(string path)
    {
      Message message = new Message();
      try
      {
        string xml = Util.ReadFile(path);
        if (xml != null)
          message = Util.DeserializeFromXml<Message>(xml);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return message;
    }

    public static Body GetMessageBody(Message M)
    {
      Body body = new Body();
      if (M != null && M.BodyCollection != null && M.BodyCollection.Count > 0)
        return M.BodyCollection[0];
      return body;
    }

    public static Header GetMessageHeader(Message M)
    {
      Header header = new Header();
      if (M != null && M.HeaderCollection != null && M.HeaderCollection.Count > 0)
        return M.HeaderCollection[0];
      return header;
    }

    public static List<Transaction> GetAckTransaction(Message M)
    {
      Body body = new Body();
      List<Transaction> transactionList = new List<Transaction>();
      Body messageBody = CCACK_Manager.GetMessageBody(M);
      for (int index1 = 0; index1 < messageBody.CreditConfirmationAckCollection.Count; ++index1)
      {
        for (int index2 = 0; index2 < messageBody.CreditConfirmationAckCollection[index1].Count; ++index2)
          transactionList.Add(messageBody.CreditConfirmationAckCollection[index1].TransactionCollection[index2]);
      }
      return transactionList;
    }
  }
}
