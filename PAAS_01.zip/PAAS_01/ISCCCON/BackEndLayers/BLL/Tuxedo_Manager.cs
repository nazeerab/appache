﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.Tuxedo_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO;
using System;
using System.Configuration;
using System.Text;

namespace BackEndLayers.BLL
{
  public class Tuxedo_Manager
  {
    private static string GetSpaces(int length)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < length; ++index)
        stringBuilder.Append(" ");
      return stringBuilder.ToString();
    }

    private static string GetConfig(string attrib)
    {
      return ConfigurationManager.AppSettings[attrib].ToString().Trim();
    }

    public static string TuxMsgIn(
      string ftsRef,
      string bsfCfcRef,
      string aramcoRef,
      string companyCode,
      string status,
      string bDate)
    {
      Fin_In_TuxMsg finInTuxMsg1 = new Fin_In_TuxMsg();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog1 = new CFCS_PAYMENTS_LOG();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog2 = new CFCS_PAYMENTS_LOG();
      StringBuilder stringBuilder1 = new StringBuilder();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog3 = CFCS_PAYMENTS_LOG_Manager.GetItem(companyCode, bsfCfcRef, PaymentStatus.CONF, InqType.SQDET);
      CFCS_PAYMENTS_LOG cfcsPaymentsLog4 = CFCS_PAYMENTS_LOG_Manager.GetItem(companyCode, bsfCfcRef, PaymentStatus.CONF, InqType.SQSMRY);
      finInTuxMsg1.SourceSystem = Tuxedo_Manager.GetConfig("SourceSystem");
      finInTuxMsg1.RequestFunction = "FINUPD04";
      finInTuxMsg1.ServerDate = DateTime.Now.ToString("yyyyMMdd");
      finInTuxMsg1.ServerTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg1.FTSReferece = ftsRef.PadRight(10, ' ');
      finInTuxMsg1.FTSTransFunc = Tuxedo_Manager.GetSpaces(10);
      finInTuxMsg1.CammTranNum = "000000";
      finInTuxMsg1.NoOfBlocks = "1".PadLeft(3, '0');
      finInTuxMsg1.CurrBlockNo = "1".PadLeft(3, '0');
      finInTuxMsg1.NoOfItems = "1".PadLeft(3, '0');
      finInTuxMsg1.CustomerCode = Tuxedo_Manager.GetSpaces(10);
      finInTuxMsg1.AccountNo = Tuxedo_Manager.GetSpaces(20);
      finInTuxMsg1.InitBranch = Tuxedo_Manager.GetConfig("InitBranch").PadRight(6, ' ');
      finInTuxMsg1.InitOfficer = Tuxedo_Manager.GetConfig("InitOfficer").PadRight(9, ' ');
      finInTuxMsg1.CardNumber = Tuxedo_Manager.GetSpaces(23);
      finInTuxMsg1.CAMMActionCode = "5555";
      finInTuxMsg1.LastUpdateDate = DateTime.Now.ToString("yyyyMMdd");
      finInTuxMsg1.LastUpdateTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg1.TransactionStatus = "NOR";
      finInTuxMsg1.FTSActionCode = "6666";
      finInTuxMsg1.ProcessingSeq = "1".PadLeft(3, '0');
      finInTuxMsg1.DetailLength = "529".PadLeft(4, '0');
      if (status.Trim().ToLower() == "ok")
        finInTuxMsg1.TransType = Tuxedo_Manager.GetConfig("ok_Status");
      else if (status.Trim().ToLower() == "de")
        finInTuxMsg1.TransType = Tuxedo_Manager.GetConfig("de_Status");
      finInTuxMsg1.TransDate = bDate;
      finInTuxMsg1.ValueDate = bDate;
      finInTuxMsg1.TransCrncy = cfcsPaymentsLog3.CREDT_ACCT_CRNCY.PadRight(3, ' ');
      Fin_In_TuxMsg finInTuxMsg2 = finInTuxMsg1;
      double num = cfcsPaymentsLog4.TOTAL_INV_AMOUNT;
      string str1 = num.ToString().PadLeft(16, '0');
      finInTuxMsg2.TransAmount = str1;
      Fin_In_TuxMsg finInTuxMsg3 = finInTuxMsg1;
      num = cfcsPaymentsLog4.TOTAL_INV_AMOUNT + 1.0;
      string str2 = num.ToString().PadLeft(16, '0');
      finInTuxMsg3.TransAmountSar = str2;
      if (status.Trim().ToLower() == "ok")
      {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.Append("AR");
        stringBuilder2.Append(" ");
        stringBuilder2.Append("ACK#");
        stringBuilder2.Append(aramcoRef);
        stringBuilder2.Append(" ");
        stringBuilder2.Append(bsfCfcRef);
        stringBuilder2.Append(" ");
        finInTuxMsg1.GenNarrative = stringBuilder2.ToString().PadRight(40, ' ');
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.Append(finInTuxMsg1.GenNarrative);
        stringBuilder3.Append(cfcsPaymentsLog3.CUSTOMER_ID.PadRight(20, ' '));
        finInTuxMsg1.GenNarrative = stringBuilder3.ToString();
      }
      else if (status.Trim().ToLower() == "de")
      {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.Append("Cust ID#");
        stringBuilder2.Append(cfcsPaymentsLog3.CUSTOMER_ID);
        stringBuilder2.Append(" ");
        stringBuilder2.Append(cfcsPaymentsLog4.PAY_TXN_REFERENCE);
        stringBuilder2.Append(" ");
        stringBuilder2.Append("de BY CO.");
        finInTuxMsg1.GenNarrative = stringBuilder2.ToString().PadRight(60, ' ');
      }
      finInTuxMsg1.ScrNarrative = Tuxedo_Manager.GetSpaces(20);
      if (status.Trim().ToLower() == "de" || status.Trim().ToLower() == "ok")
      {
        finInTuxMsg1.DebitAcctNo = cfcsPaymentsLog3.CREDT_ACCT_NO.PadLeft(20, '0');
        finInTuxMsg1.DebitAcctCrncy = cfcsPaymentsLog3.CREDT_ACCT_CRNCY.PadRight(3, ' ');
        Fin_In_TuxMsg finInTuxMsg4 = finInTuxMsg1;
        num = cfcsPaymentsLog4.TOTAL_INV_AMOUNT;
        string str3 = num.ToString().PadLeft(16, '0');
        finInTuxMsg4.DebitAmount = str3;
      }
      finInTuxMsg1.DebitCrncyRate = "00.000000";
      finInTuxMsg1.DebitValueDate = bDate;
      finInTuxMsg1.DebitSrfFlag = "N";
      finInTuxMsg1.DebitBranch = Tuxedo_Manager.GetSpaces(6);
      if (status.Trim().ToLower() == "ok")
      {
        finInTuxMsg1.CreditAcctNo = cfcsPaymentsLog3.COLLCT_ACCT_NO.PadLeft(20, '0');
        finInTuxMsg1.CreditAcctCrncy = cfcsPaymentsLog3.CREDT_ACCT_CRNCY.PadRight(3, ' ');
      }
      else if (status.Trim().ToLower() == "de")
      {
        finInTuxMsg1.CreditAcctNo = cfcsPaymentsLog3.DEBIT_ACCT_NO.PadLeft(20, '0');
        finInTuxMsg1.CreditAcctCrncy = cfcsPaymentsLog3.DEBIT_ACCT_CRNCY.PadRight(3, ' ');
      }
      Fin_In_TuxMsg finInTuxMsg5 = finInTuxMsg1;
      num = cfcsPaymentsLog4.TOTAL_INV_AMOUNT;
      string str4 = num.ToString().PadLeft(16, '0');
      finInTuxMsg5.CreditAmount = str4;
      finInTuxMsg1.CreditCrncyRate = "000.00000";
      finInTuxMsg1.CreditValueDate = bDate;
      finInTuxMsg1.CreditSrfFlag = Tuxedo_Manager.GetSpaces(1);
      finInTuxMsg1.CreditBranch = Tuxedo_Manager.GetSpaces(6);
      finInTuxMsg1.CommissionCrncy = Tuxedo_Manager.GetSpaces(3);
      finInTuxMsg1.CommissionAmount = Tuxedo_Manager.GetSpaces(16);
      finInTuxMsg1.CommissionAcct = "00000000000000000000";
      finInTuxMsg1.ChargesCrncy = Tuxedo_Manager.GetSpaces(3);
      finInTuxMsg1.ChargesAmount = "0000000000000.00";
      finInTuxMsg1.ChargesAcct = "00000000000000000000";
      finInTuxMsg1.GtdDealTicket = Tuxedo_Manager.GetSpaces(20);
      finInTuxMsg1.InitTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg1.ValidationOfficer = Tuxedo_Manager.GetConfig("ValidationOfficer").PadRight(9, ' ');
      finInTuxMsg1.ValidationTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg1.AuthorznOfficer = Tuxedo_Manager.GetConfig("AuthorznOfficer").PadRight(9, ' ');
      finInTuxMsg1.AuthorznTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg1.AuthorznReason = Tuxedo_Manager.GetSpaces(10);
      finInTuxMsg1.AuthorznStatus = Tuxedo_Manager.GetSpaces(6);
      finInTuxMsg1.DynamicPartLen = "000";
      finInTuxMsg1.StaticPart_ChequeNo = Tuxedo_Manager.GetSpaces(15);
      finInTuxMsg1.StaticPart_Id_Type = Tuxedo_Manager.GetSpaces(6);
      finInTuxMsg1.StaticPart_Id_Number = Tuxedo_Manager.GetSpaces(20);
      finInTuxMsg1.StaticPart_PrintDetail = Tuxedo_Manager.GetSpaces(1);
      finInTuxMsg1.StaticPart_MailAdvice = Tuxedo_Manager.GetSpaces(1);
      finInTuxMsg1.CompanyCustomerId = cfcsPaymentsLog3.CUSTOMER_ID.PadRight(20, ' ');
      finInTuxMsg1.CompanyCode = companyCode.PadRight(3, ' ');
      finInTuxMsg1.InvoiceNumber = cfcsPaymentsLog3.INV_NO.PadRight(20, ' ');
      finInTuxMsg1.InvoiceDate = cfcsPaymentsLog3.INV_DATE.ToString("yyyyMMdd");
      finInTuxMsg1.PaymentsType = cfcsPaymentsLog4.PAY_TYPE.PadRight(3, ' ');
      finInTuxMsg1.ChannelPaymentReference = cfcsPaymentsLog4.PAY_TXN_REFERENCE.PadRight(15, ' ');
      finInTuxMsg1.CustomerDebitAcct = cfcsPaymentsLog3.DEBIT_ACCT_NO.PadLeft(20, '0');
      if (status.Trim().ToLower() == "ok")
        finInTuxMsg1.CompanyAckType = "A".PadRight(3, ' ');
      else if (status.Trim().ToLower() == "de")
        finInTuxMsg1.CompanyAckType = "R".PadRight(3, ' ');
      return finInTuxMsg1.print();
    }

    public static Fin_Out_TuxMsg TuxMsgOut(string tuxMsg)
    {
      char[] charArray = tuxMsg.ToCharArray();
      Fin_Out_TuxMsg finOutTuxMsg = new Fin_Out_TuxMsg();
      string empty1 = string.Empty;
      try
      {
        if (charArray.Length > 0)
        {
          string empty2 = string.Empty;
          for (int index = 25; index <= 34; ++index)
            empty2 += (string) (object) charArray[index];
          finOutTuxMsg.FTSReference = empty2;
          string empty3 = string.Empty;
          for (int index = 128; index <= 131; ++index)
            empty3 += (string) (object) charArray[index];
          finOutTuxMsg.CAMMActionCode = empty3;
          string empty4 = string.Empty;
          for (int index = 149; index <= 152; ++index)
            empty4 += (string) (object) charArray[index];
          finOutTuxMsg.FTSActionCode = empty4;
        }
        else
        {
          finOutTuxMsg.CAMMActionCode = "9999";
          finOutTuxMsg.FTSActionCode = "9999";
        }
      }
      catch (Exception ex)
      {
        finOutTuxMsg.CAMMActionCode = "9999";
        finOutTuxMsg.FTSActionCode = "9999";
      }
      return finOutTuxMsg;
    }

    public static Fin_Out_TuxMsg Tuxedo(string msg, out string reply)
    {
      string tuxMsg = string.Empty;
      Fin_Out_TuxMsg finOutTuxMsg1 = new Fin_Out_TuxMsg();
      TuxedoConnector tuxedoConnector = new TuxedoConnector(ConfigurationManager.AppSettings["TuxServer"], Convert.ToInt32(ConfigurationManager.AppSettings["TuxPort"].ToString()));
      Fin_Out_TuxMsg finOutTuxMsg2;
      try
      {
        tuxMsg = tuxedoConnector.SendReceiveMessage(msg);
        reply = tuxMsg;
        finOutTuxMsg2 = Tuxedo_Manager.TuxMsgOut(tuxMsg);
      }
      catch (Exception ex)
      {
        reply = ex.Message;
        finOutTuxMsg2 = Tuxedo_Manager.TuxMsgOut(tuxMsg);
      }
      return finOutTuxMsg2;
    }
  }
}
