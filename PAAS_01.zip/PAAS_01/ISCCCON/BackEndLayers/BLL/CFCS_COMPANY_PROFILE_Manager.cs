﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_COMPANY_PROFILE_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.DAL;

namespace BackEndLayers.BLL
{
  public class CFCS_COMPANY_PROFILE_Manager
  {
    public static CFCS_COMPANY_PROFILE_List Get(
      string companyCode,
      string type)
    {
      return CFCS_COMPANY_PROFILE_DB.GetList(companyCode, type);
    }

    public static CFCS_COMPANY_PROFILE Item(string companyCode, string type)
    {
      return CFCS_COMPANY_PROFILE_DB.Item(companyCode, type);
    }
  }
}
