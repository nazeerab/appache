﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.OSCUSTINV_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO.OSCUSTINV;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BackEndLayers.BLL
{
  public class OSCUSTINV_Manager
  {
    public static Message XMLtoOSCUSTINV(string path)
    {
      Message message = new Message();
      try
      {
        string xml = Util.ReadFile(path);
        if (xml != null)
          message = Util.DeserializeFromXml<Message>(xml);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return message;
    }

    public static MessageBody GetMessageBody(Message M)
    {
      MessageBody messageBody = new MessageBody();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          switch (M.Items[index].GetType().Name)
          {
            case "MessageBody":
              return (MessageBody) M.Items[index];
            default:
              continue;
          }
        }
      }
      return messageBody;
    }

    public static List<MessageBodyCustomerInvoice> GetMessageBodyInvoices(
      Message M)
    {
      List<MessageBodyCustomerInvoice> bodyCustomerInvoiceList = new List<MessageBodyCustomerInvoice>();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageBody":
                return ((IEnumerable<MessageBodyCustomerInvoice>) ((MessageBody) M.Items[index]).CustomerInvoice).ToList<MessageBodyCustomerInvoice>();
              default:
                continue;
            }
          }
        }
      }
      return bodyCustomerInvoiceList;
    }

    public static List<MessageBodyCustomerInvoiceInvoiceDetail> GetMessageBodyInvoicesDetail(
      Message M)
    {
      List<MessageBodyCustomerInvoice> bodyCustomerInvoiceList = new List<MessageBodyCustomerInvoice>();
      List<MessageBodyCustomerInvoiceInvoiceDetail> invoiceInvoiceDetailList = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      List<MessageBodyCustomerInvoice> messageBodyInvoices = OSCUSTINV_Manager.GetMessageBodyInvoices(M);
      for (int index1 = 0; index1 < messageBodyInvoices.Count<MessageBodyCustomerInvoice>(); ++index1)
      {
        for (int index2 = 0; index2 < ((IEnumerable<MessageBodyCustomerInvoiceInvoiceDetail>) messageBodyInvoices[index1].InvoiceDetail).Count<MessageBodyCustomerInvoiceInvoiceDetail>(); ++index2)
        {
          messageBodyInvoices[index1].InvoiceDetail[index2].Status = messageBodyInvoices[index1].InvoiceStatus;
          invoiceInvoiceDetailList.Add(messageBodyInvoices[index1].InvoiceDetail[index2]);
        }
      }
      return invoiceInvoiceDetailList;
    }

    public static MessageHeader GetMessageHeader(Message M)
    {
      MessageHeader messageHeader = new MessageHeader();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageHeader":
                return (MessageHeader) M.Items[index];
              default:
                continue;
            }
          }
        }
      }
      return messageHeader;
    }

    public static MessageResponseStatus GetMessageResponseStatus(Message M)
    {
      MessageResponseStatus messageResponseStatus = new MessageResponseStatus();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageResponseStatus":
                return (MessageResponseStatus) M.Items[index];
              default:
                continue;
            }
          }
        }
      }
      return messageResponseStatus;
    }

    public static MessageResponseStatus GetResponseStatus(Message M)
    {
      MessageResponseStatus messageResponseStatus = new MessageResponseStatus();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageResponseStatus":
                return (MessageResponseStatus) M.Items[index];
              default:
                continue;
            }
          }
        }
      }
      return messageResponseStatus;
    }
  }
}
