﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.TuxedoConnector
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace BackEndLayers.BLL
{
  public class TuxedoConnector
  {
    private string server;
    private int port;
    private Socket Sockt;

    public TuxedoConnector(string inServer, int inPort)
    {
      this.server = inServer;
      this.port = inPort;
      this.connectSocket();
    }

    public TuxedoConnector(string inServer, string inPort)
    {
      this.server = inServer;
      this.port = Convert.ToInt32(inPort);
      this.connectSocket();
    }

    public void connectSocket()
    {
      this.Sockt = (Socket) null;
      try
      {
        foreach (IPAddress address in Dns.GetHostEntry(this.server).AddressList)
        {
          IPEndPoint ipEndPoint = new IPEndPoint(address, this.port);
          Socket socket = new Socket(ipEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
          socket.Connect((EndPoint) ipEndPoint);
          if (socket.Connected)
          {
            this.Sockt = socket;
            break;
          }
        }
      }
      catch (Exception ex)
      {
        throw new Exception(ex.Message);
      }
    }

    public void CloseSocket()
    {
      this.Sockt.Close();
    }

    public string SendReceiveMessage(string msg)
    {
      string str1 = "";
      Encoding encoding = Encoding.Default;
      string str2 = msg;
      string s = str2.Length.ToString().PadLeft(4, '0') + str2;
      byte[] bytes = encoding.GetBytes(s);
      byte[] numArray = new byte[10240];
      string str3 = " ";
      try
      {
        if (!this.Sockt.Connected)
          this.connectSocket();
        this.Sockt.Send(bytes, bytes.Length, SocketFlags.None);
        int count = this.Sockt.Receive(numArray, numArray.Length, SocketFlags.None);
        str3 = encoding.GetString(numArray, 0, count);
        str3 = str3.PadRight(164, ' ');
        str3 = str3.Remove(0, 4);
        str1 = str3;
      }
      catch (Exception ex)
      {
      }
      try
      {
      }
      catch (Exception ex)
      {
        string message = ex.Message;
      }
      if (this.Sockt.Connected)
        this.CloseSocket();
      return str3;
    }
  }
}
