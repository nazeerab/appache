﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.TransactionCollection
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.Collections;
using System.ComponentModel;

namespace BackEndLayers.BO.CCACK
{
  [EditorBrowsable(EditorBrowsableState.Advanced)]
  [Serializable]
  public class TransactionCollection : ArrayList
  {
    public Transaction Add(Transaction obj)
    {
      this.Add((object) obj);
      return obj;
    }

    public Transaction Add()
    {
      return this.Add(new Transaction());
    }

    public void Insert(int index, Transaction obj)
    {
      this.Insert(index, (object) obj);
    }

    public void Remove(Transaction obj)
    {
      this.Remove((object) obj);
    }

    public Transaction this[int index]
    {
      get
      {
        return (Transaction) base[index];
      }
      set
      {
        this[index] = value;
      }
    }
  }
}
