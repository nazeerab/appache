﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.Tag50K
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

namespace BackEndLayers.BO.ISCCON
{
  public class Tag50K
  {
    private string _value = string.Empty;
    private string _debitAcctNo = string.Empty;
    private string _customerName = string.Empty;
    private string _city = string.Empty;

    public string Value
    {
      get
      {
        return this._value;
      }
      set
      {
        this._value = value;
      }
    }

    public string DebitAcctNo
    {
      get
      {
        return this._debitAcctNo;
      }
      set
      {
        this._debitAcctNo = value;
      }
    }

    public string CustomerName
    {
      get
      {
        return this._customerName;
      }
      set
      {
        this._customerName = value;
      }
    }

    public string City
    {
      get
      {
        return this._city;
      }
      set
      {
        this._city = value;
      }
    }
  }
}
