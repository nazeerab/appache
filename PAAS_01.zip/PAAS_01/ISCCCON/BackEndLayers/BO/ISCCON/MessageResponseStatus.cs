﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.MessageResponseStatus
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.ISCCON
{
  [XmlType(AnonymousType = true)]
  [DesignerCategory("code")]
  [DebuggerStepThrough]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [Serializable]
  public class MessageResponseStatus
  {
    private string statusCodeField;
    private string statusDetailField;

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string StatusCode
    {
      get
      {
        return this.statusCodeField;
      }
      set
      {
        this.statusCodeField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string StatusDetail
    {
      get
      {
        return this.statusDetailField;
      }
      set
      {
        this.statusDetailField = value;
      }
    }
  }
}
