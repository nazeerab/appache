﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Report
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class Report
  {
    private string _detail = string.Empty;
    private string _code = string.Empty;

    public string Detail
    {
      get
      {
        return this._detail;
      }
      set
      {
        this._detail = value;
      }
    }

    public string Code
    {
      get
      {
        return this._code;
      }
      set
      {
        this._code = value;
      }
    }
  }
}
