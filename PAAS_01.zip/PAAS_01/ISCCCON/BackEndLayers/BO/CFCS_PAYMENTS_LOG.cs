﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CFCS_PAYMENTS_LOG
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;

namespace BackEndLayers.BO
{
  public class CFCS_PAYMENTS_LOG
  {
    private string _COLLCT_ACCT_NO = string.Empty;
    private string _PAY_TYPE = string.Empty;
    private string _COMP_CODE = string.Empty;
    private string _CUSTOMER_ID = string.Empty;
    private string _INV_NO = string.Empty;
    private DateTime _INV_DATE = new DateTime();
    private string _SOURCE_SYSTEM = string.Empty;
    private string _INIT_BRANCH = string.Empty;
    private DateTime _TRANS_DATE_TIME = new DateTime();
    private string _TRANS_REFERENCE = string.Empty;
    private string _TRANS_STATUS = string.Empty;
    private string _TRANS_TYPE = string.Empty;
    private DateTime _TRANS_DATE = new DateTime();
    private DateTime _VALUE_DATE = new DateTime();
    private string _DEBIT_ACCT_NO = string.Empty;
    private string _DEBIT_ACCT_CRNCY = string.Empty;
    private double _DEBIT_AMOUNT = 0.0;
    private double _DEBIT_CRNCY_RATE = 0.0;
    private string _CREDT_ACCT_NO = string.Empty;
    private string _CREDT_ACCT_CRNCY = string.Empty;
    private double _CREDT_AMOUNT = 0.0;
    private double _CREDT_CRNCY_RATE = 0.0;
    private string _PAYMENT_STATUS = string.Empty;
    private DateTime _COLC_CONF_DATETIME = new DateTime();
    private DateTime _COLC_POST_DATETIME = new DateTime();
    private string _BSF_REMARKS = string.Empty;
    private string _COMP_ACK_REFERENCE = string.Empty;
    private DateTime _COMP_ACTION_DATE = new DateTime();
    private string _COMP_ACTION_REMARKS = string.Empty;
    private string _CREATED_BY = string.Empty;
    private DateTime _CREATED_DATE = new DateTime();
    private string _UPDATED_BY = string.Empty;
    private DateTime _UPDATED_DATE = new DateTime();
    private string _REMITTER_NAME = string.Empty;
    private string _REMITTER_BANK_REF = string.Empty;
    private double _PAY_GRP_TOT_INV = 0.0;
    private double _PAY_GRP_INV_SEQ = 0.0;
    private string _PAY_TXN_REFERENCE = string.Empty;
    private string _CFC_REFERENCE = string.Empty;
    private string _CFC_FILE_REF = string.Empty;
    private double _TOTAL_INV_AMOUNT = 0.0;
    private double _TOTAL_INV_COUNT = 0.0;

    public string PAY_TYPE
    {
      get
      {
        return this._PAY_TYPE;
      }
      set
      {
        this._PAY_TYPE = value;
      }
    }

    public string COLLCT_ACCT_NO
    {
      get
      {
        return this._COLLCT_ACCT_NO;
      }
      set
      {
        this._COLLCT_ACCT_NO = value;
      }
    }

    public string COMP_CODE
    {
      get
      {
        return this._COMP_CODE;
      }
      set
      {
        this._COMP_CODE = value;
      }
    }

    public string CUSTOMER_ID
    {
      get
      {
        return this._CUSTOMER_ID;
      }
      set
      {
        this._CUSTOMER_ID = value;
      }
    }

    public string INV_NO
    {
      get
      {
        return this._INV_NO;
      }
      set
      {
        this._INV_NO = value;
      }
    }

    public DateTime INV_DATE
    {
      get
      {
        return this._INV_DATE;
      }
      set
      {
        this._INV_DATE = value;
      }
    }

    public string SOURCE_SYSTEM
    {
      get
      {
        return this._SOURCE_SYSTEM;
      }
      set
      {
        this._SOURCE_SYSTEM = value;
      }
    }

    public string INIT_BRANCH
    {
      get
      {
        return this._INIT_BRANCH;
      }
      set
      {
        this._INIT_BRANCH = value;
      }
    }

    public DateTime TRANS_DATE_TIME
    {
      get
      {
        return this._TRANS_DATE_TIME;
      }
      set
      {
        this._TRANS_DATE_TIME = value;
      }
    }

    public string TRANS_REFERENCE
    {
      get
      {
        return this._TRANS_REFERENCE;
      }
      set
      {
        this._TRANS_REFERENCE = value;
      }
    }

    public string TRANS_STATUS
    {
      get
      {
        return this._TRANS_STATUS;
      }
      set
      {
        this._TRANS_STATUS = value;
      }
    }

    public string TRANS_TYPE
    {
      get
      {
        return this._TRANS_TYPE;
      }
      set
      {
        this._TRANS_TYPE = value;
      }
    }

    public DateTime TRANS_DATE
    {
      get
      {
        return this._TRANS_DATE;
      }
      set
      {
        this._TRANS_DATE = value;
      }
    }

    public DateTime VALUE_DATE
    {
      get
      {
        return this._VALUE_DATE;
      }
      set
      {
        this._VALUE_DATE = value;
      }
    }

    public string DEBIT_ACCT_CRNCY
    {
      get
      {
        return this._DEBIT_ACCT_CRNCY;
      }
      set
      {
        this._DEBIT_ACCT_CRNCY = value;
      }
    }

    public string DEBIT_ACCT_NO
    {
      get
      {
        return this._DEBIT_ACCT_NO;
      }
      set
      {
        this._DEBIT_ACCT_NO = value;
      }
    }

    public double DEBIT_AMOUNT
    {
      get
      {
        return this._DEBIT_AMOUNT;
      }
      set
      {
        this._DEBIT_AMOUNT = value;
      }
    }

    public double DEBIT_CRNCY_RATE
    {
      get
      {
        return this._DEBIT_CRNCY_RATE;
      }
      set
      {
        this._DEBIT_CRNCY_RATE = value;
      }
    }

    public string CREDT_ACCT_NO
    {
      get
      {
        return this._CREDT_ACCT_NO;
      }
      set
      {
        this._CREDT_ACCT_NO = value;
      }
    }

    public string CREDT_ACCT_CRNCY
    {
      get
      {
        return this._CREDT_ACCT_CRNCY;
      }
      set
      {
        this._CREDT_ACCT_CRNCY = value;
      }
    }

    public double CREDT_AMOUNT
    {
      get
      {
        return this._CREDT_AMOUNT;
      }
      set
      {
        this._CREDT_AMOUNT = value;
      }
    }

    public double CREDT_CRNCY_RATE
    {
      get
      {
        return this._CREDT_CRNCY_RATE;
      }
      set
      {
        this._CREDT_CRNCY_RATE = value;
      }
    }

    public string PAYMENT_STATUS
    {
      get
      {
        return this._PAYMENT_STATUS;
      }
      set
      {
        this._PAYMENT_STATUS = value;
      }
    }

    public DateTime COLC_CONF_DATETIME
    {
      get
      {
        return this._COLC_CONF_DATETIME;
      }
      set
      {
        this._COLC_CONF_DATETIME = value;
      }
    }

    public DateTime COLC_POST_DATETIME
    {
      get
      {
        return this._COLC_POST_DATETIME;
      }
      set
      {
        this._COLC_POST_DATETIME = value;
      }
    }

    public string BSF_REMARKS
    {
      get
      {
        return this._BSF_REMARKS;
      }
      set
      {
        this._BSF_REMARKS = value;
      }
    }

    public string COMP_ACK_REFERENCE
    {
      get
      {
        return this._COMP_ACK_REFERENCE;
      }
      set
      {
        this._COMP_ACK_REFERENCE = value;
      }
    }

    public DateTime COMP_ACTION_DATE
    {
      get
      {
        return this._COMP_ACTION_DATE;
      }
      set
      {
        this._COMP_ACTION_DATE = value;
      }
    }

    public string COMP_ACTION_REMARKS
    {
      get
      {
        return this._COMP_ACTION_REMARKS;
      }
      set
      {
        this._COMP_ACTION_REMARKS = value;
      }
    }

    public string CREATED_BY
    {
      get
      {
        return this._CREATED_BY;
      }
      set
      {
        this._CREATED_BY = value;
      }
    }

    public DateTime CREATED_DATE
    {
      get
      {
        return this._CREATED_DATE;
      }
      set
      {
        this._CREATED_DATE = value;
      }
    }

    public string UPDATED_BY
    {
      get
      {
        return this._UPDATED_BY;
      }
      set
      {
        this._UPDATED_BY = value;
      }
    }

    public DateTime UPDATED_DATE
    {
      get
      {
        return this._UPDATED_DATE;
      }
      set
      {
        this._UPDATED_DATE = value;
      }
    }

    public string REMITTER_NAME
    {
      get
      {
        return this._REMITTER_NAME;
      }
      set
      {
        this._REMITTER_NAME = value;
      }
    }

    public string REMITTER_BANK_REF
    {
      get
      {
        return this._REMITTER_BANK_REF;
      }
      set
      {
        this._REMITTER_BANK_REF = value;
      }
    }

    public double PAY_GRP_TOT_INV
    {
      get
      {
        return this._PAY_GRP_TOT_INV;
      }
      set
      {
        this._PAY_GRP_TOT_INV = value;
      }
    }

    public double PAY_GRP_INV_SEQ
    {
      get
      {
        return this._PAY_GRP_INV_SEQ;
      }
      set
      {
        this._PAY_GRP_INV_SEQ = value;
      }
    }

    public string PAY_TXN_REFERENCE
    {
      get
      {
        return this._PAY_TXN_REFERENCE;
      }
      set
      {
        this._PAY_TXN_REFERENCE = value;
      }
    }

    public string CFC_REFERENCE
    {
      get
      {
        return this._CFC_REFERENCE;
      }
      set
      {
        this._CFC_REFERENCE = value;
      }
    }

    public string CFC_FILE_REF
    {
      get
      {
        return this._CFC_FILE_REF;
      }
      set
      {
        this._CFC_FILE_REF = value;
      }
    }

    public double TOTAL_INV_AMOUNT
    {
      get
      {
        return this._TOTAL_INV_AMOUNT;
      }
      set
      {
        this._TOTAL_INV_AMOUNT = value;
      }
    }

    public double TOTAL_INV_COUNT
    {
      get
      {
        return this._TOTAL_INV_COUNT;
      }
      set
      {
        this._TOTAL_INV_COUNT = value;
      }
    }
  }
}
