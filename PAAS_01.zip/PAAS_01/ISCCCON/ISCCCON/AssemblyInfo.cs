﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ISCCCON")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("ISCCCON")]
[assembly: AssemblyCopyright("Copyright © BSF 2011")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("99abc227-1068-445e-8d89-1cbcd6938f20")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
