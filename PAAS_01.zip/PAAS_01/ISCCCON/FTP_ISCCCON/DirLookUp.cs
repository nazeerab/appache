﻿// Decompiled with JetBrains decompiler
// Type: FTP_ISCCCON.DirLookUp
// Assembly: FTP_ISCCCON, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F3B3A18E-EFA4-4D83-B0BB-8347D2BDD9A5
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\FTP_ISCCCON.exe

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FTP_ISCCCON
{
  public class DirLookUp
  {
    public static PayFile_List WalkDirectory(DirectoryInfo directory)
    {
      PayFile_List payFileList = new PayFile_List();
      PayFile payFile1 = new PayFile();
      if (directory.Exists)
      {
        foreach (FileInfo file in directory.GetFiles())
        {
          PayFile payFile2 = new PayFile();
          if (file != null && file.Name != null)
          {
            string[] strArray = file.Name.Split('.');
            if (((IEnumerable<string>) strArray).Count<string>() > 3)
            {
              payFile2.FileRef = strArray[4];
              payFile2.Name = file.Name;
              payFile2.Path = file.FullName;
            }
          }
          payFileList.Add(payFile2);
        }
      }
      return payFileList;
    }
  }
}
