﻿// Decompiled with JetBrains decompiler
// Type: FTP_ISCCCON.Program
// Assembly: FTP_ISCCCON, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F3B3A18E-EFA4-4D83-B0BB-8347D2BDD9A5
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\FTP_ISCCCON.exe

using BackEndLayers.BLL;
using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.Log;
using System;
using System.Linq;

namespace FTP_ISCCCON
{
  public class Program
  {
    private static void Main(string[] args)
    {
      DateTime now = DateTime.Now;
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string fileName = string.Empty;
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList = new CFCS_PAYMENTS_LOG_List();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog = new CFCS_PAYMENTS_LOG();
      PayFile_List payFileList1 = new PayFile_List();
      PayFile_List payFileList2 = new PayFile_List();
      LogFTP logFtp = new LogFTP();
      bool flag = true;
      Console.WriteLine("Process FTP_ISCCCON is started.");
      try
      {
        string str = args[0].ToString();
        Console.WriteLine("Company Code: " + str);
        PayFile_List ftpFiles = FTPHandler.GetFtpFiles();
        Console.WriteLine("Get File(s) to be FTP: " + ftpFiles.Count<PayFile>().ToString());
        for (int index = 0; index < ftpFiles.Count<PayFile>(); ++index)
        {
          try
          {
            fileName = ftpFiles[index].Name;
            CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG = new CFCS_PAYMENTS_LOG();
            if (FTPHandler.Upload(ftpFiles[index].Path))
            {
              myCFCS_PAYMENTS_LOG.COMP_CODE = str;
              myCFCS_PAYMENTS_LOG.CFC_FILE_REF = ftpFiles[index].FileRef;
              if (CFCS_PAYMENTS_LOG_Manager.Save(myCFCS_PAYMENTS_LOG).Code != "0000")
              {
                if (!FTPHandler.Delete(ftpFiles[0].Name))
                {
                  logFtp.Log("Failed to Delete From FTP server", fileName, Eventtype.Error);
                  Console.WriteLine("File Delete Failure: " + ftpFiles[index].FileRef);
                }
                Console.WriteLine("Db Status Update Failure: " + ftpFiles[index].FileRef);
              }
              else
              {
                payFileList2.Add(ftpFiles[index]);
                Console.WriteLine("Db Status Update Sccess: " + ftpFiles[index].FileRef);
              }
              Console.WriteLine("File Upload Success: " + ftpFiles[index].FileRef);
            }
            else
            {
              Console.WriteLine("File Upload Failure: " + ftpFiles[index].FileRef);
              logFtp.Log("Failed to FTP", fileName, Eventtype.Error);
            }
          }
          catch (Exception ex)
          {
            Console.WriteLine("Exception: " + ex.ToString());
            logFtp.Log(ex, fileName, Eventtype.Error);
            flag = false;
          }
        }
        Console.WriteLine("Moving Files.");
        FileHandler.MoveFile(payFileList2);
        Console.WriteLine("Files moving complete.");
        Console.WriteLine("Logging Files.");
        logFtp.Log(ftpFiles, payFileList2);
        Console.WriteLine("Logging Complete.");
      }
      catch (IndexOutOfRangeException ex)
      {
        flag = false;
        logFtp.Log((Exception) ex, fileName, Eventtype.Error);
        Console.WriteLine("Please provide compnay code as args[0]");
      }
      catch (Exception ex)
      {
        flag = false;
        logFtp.Log(ex, fileName, Eventtype.Error);
        Console.WriteLine("Application terminated unsuccessfully, please check logs for detail.");
      }
      if (flag)
        Console.WriteLine("Process end with Success.");
      else
        Console.WriteLine("Process end with Failure.");
      Console.WriteLine("Process tooks " + (DateTime.Now - now).Milliseconds.ToString() + " MS to compelete.");
    }
  }
}
