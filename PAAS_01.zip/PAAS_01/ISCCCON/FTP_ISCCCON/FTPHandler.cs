﻿// Decompiled with JetBrains decompiler
// Type: FTP_ISCCCON.FTPHandler
// Assembly: FTP_ISCCCON, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F3B3A18E-EFA4-4D83-B0BB-8347D2BDD9A5
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\FTP_ISCCCON.exe

using BackEndLayers.BO.Collections;
using BackEndLayers.Log;
using System;
using System.Configuration;
using System.IO;
using System.Net;

namespace FTP_ISCCCON
{
  public class FTPHandler
  {
    public static PayFile_List GetFtpFiles()
    {
      LogFTP logFtp = new LogFTP();
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList = new CFCS_PAYMENTS_LOG_List();
      PayFile_List payFileList1 = new PayFile_List();
      PayFile_List payFileList2 = new PayFile_List();
      try
      {
        payFileList1 = DirLookUp.WalkDirectory(new DirectoryInfo(ConfigurationManager.AppSettings["ISCONN_Msgs"].ToString()));
      }
      catch (Exception ex)
      {
        logFtp.Log(ex, Eventtype.Error);
      }
      return payFileList1;
    }

    public static bool Upload(string filename)
    {
      LogFTP logFtp = new LogFTP();
      string str1 = ConfigurationManager.AppSettings["FtpServer"].ToString();
      string userName = ConfigurationManager.AppSettings["ServerUserName"].ToString();
      string password = ConfigurationManager.AppSettings["ServerPassword"].ToString();
      string str2 = ConfigurationManager.AppSettings["FtpPath"].ToString();
      FileInfo fileInfo = new FileInfo(filename);
      FtpWebRequest ftpWebRequest = (FtpWebRequest) WebRequest.Create(new Uri("ftp://" + str1 + str2 + fileInfo.Name));
      ftpWebRequest.Credentials = (ICredentials) new NetworkCredential(userName, password);
      ftpWebRequest.KeepAlive = false;
      ftpWebRequest.Method = "STOR";
      ftpWebRequest.UseBinary = true;
      ftpWebRequest.ContentLength = fileInfo.Length;
      FileStream fileStream = fileInfo.OpenRead();
      try
      {
        ftpWebRequest.Proxy = (IWebProxy) null;
        Stream requestStream = ftpWebRequest.GetRequestStream();
        byte[] buffer = new byte[fileStream.Length];
        for (int count = fileStream.Read(buffer, 0, buffer.Length); count != 0; count = fileStream.Read(buffer, 0, buffer.Length))
          requestStream.Write(buffer, 0, count);
        requestStream.Close();
        fileStream.Close();
      }
      catch (Exception ex)
      {
        logFtp.Log(ex, Eventtype.Error);
        return false;
      }
      return true;
    }

    public static bool Delete(string filename)
    {
      string str1 = ConfigurationManager.AppSettings["FtpServer"].ToString();
      string userName = ConfigurationManager.AppSettings["ServerUserName"].ToString();
      string password = ConfigurationManager.AppSettings["ServerPassword"].ToString();
      string str2 = ConfigurationManager.AppSettings["FtpPath"].ToString();
      LogFTP logFtp = new LogFTP();
      FtpWebRequest ftpWebRequest = (FtpWebRequest) WebRequest.Create("ftp://" + str1 + str2 + filename);
      ftpWebRequest.Proxy = (IWebProxy) null;
      ftpWebRequest.Credentials = (ICredentials) new NetworkCredential(userName, password);
      ftpWebRequest.Method = "DELE";
      try
      {
        return ((FtpWebResponse) ftpWebRequest.GetResponse()).StatusCode.ToString().ToLower().Trim() == "FileActionOK".ToLower().Trim();
      }
      catch (Exception ex)
      {
        logFtp.Log(ex, Eventtype.Error);
        return false;
      }
    }
  }
}
