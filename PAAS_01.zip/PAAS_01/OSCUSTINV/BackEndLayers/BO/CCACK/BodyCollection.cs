﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.BodyCollection
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.Collections;
using System.ComponentModel;

namespace BackEndLayers.BO.CCACK
{
  [EditorBrowsable(EditorBrowsableState.Advanced)]
  [Serializable]
  public class BodyCollection : ArrayList
  {
    public Body Add(Body obj)
    {
      this.Add((object) obj);
      return obj;
    }

    public Body Add()
    {
      return this.Add(new Body());
    }

    public void Insert(int index, Body obj)
    {
      this.Insert(index, (object) obj);
    }

    public void Remove(Body obj)
    {
      this.Remove((object) obj);
    }

    public Body this[int index]
    {
      get
      {
        return (Body) base[index];
      }
      set
      {
        this[index] =  value;
      }
    }
  }
}
