﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("OSCUSDAT")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("OSCUSDAT")]
[assembly: AssemblyCopyright("Copyright © BSF 2011")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("f356df47-bd1a-4e20-b4a2-4b478d33473d")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
