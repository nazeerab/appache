﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.DAL.CFCS_PAYMENTS_LOG_DB
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace BackEndLayers.DAL
{
  public class CFCS_PAYMENTS_LOG_DB
  {
    public static CFCS_PAYMENTS_LOG_List GetList(
      string companyCode,
      string payStatus,
      string type,
      string grpRef)
    {
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList = new CFCS_PAYMENTS_LOG_List();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.GET_CFC_INV_PAYMENTS", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (companyCode == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) companyCode);
          if (type == string.Empty)
            oracleCommand.Parameters.Add("PI_TYPE ", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_TYPE ", (object) type);
          if (grpRef == string.Empty)
            oracleCommand.Parameters.Add("PI_REFERENCE ", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_REFERENCE ", (object) grpRef);
          if (payStatus == string.Empty)
            oracleCommand.Parameters.Add("PI_PAY_STATUS", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_PAY_STATUS", (object) payStatus);
          oracleCommand.Parameters.Add("PO_INV_CUR", OracleDbType.RefCursor, (object) DBNull.Value, ParameterDirection.Output);
          ((DbConnection) conn).Open();
          using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader())
          {
            if (((DbDataReader) oracleDataReader).HasRows)
            {
              while (((DbDataReader) oracleDataReader).Read())
                cfcsPaymentsLogList.Add(CFCS_PAYMENTS_LOG_DB.FillDataRecord((IDataRecord) oracleDataReader));
            }
            ((DbDataReader) oracleDataReader).Close();
          }
          ((DbConnection) conn).Close();
        }
      }
      return cfcsPaymentsLogList;
    }

    public static CFCS_PAYMENTS_LOG GetItem(
      string companyCode,
      string payStatus,
      string type,
      string grpRef)
    {
      CFCS_PAYMENTS_LOG cfcsPaymentsLog = new CFCS_PAYMENTS_LOG();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.GET_CFC_INV_PAYMENTS", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (companyCode == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) companyCode);
          if (type == string.Empty)
            oracleCommand.Parameters.Add("PI_TYPE ", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_TYPE ", (object) type);
          if (grpRef == string.Empty)
            oracleCommand.Parameters.Add("PI_REFERENCE ", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_REFERENCE ", (object) grpRef);
          if (payStatus == string.Empty)
            oracleCommand.Parameters.Add("PI_PAY_STATUS", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_PAY_STATUS", (object) payStatus);
          oracleCommand.Parameters.Add("PO_INV_CUR", OracleDbType.RefCursor, (object) DBNull.Value, ParameterDirection.Output);
          ((DbConnection) conn).Open();
          using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader())
          {
            if (((DbDataReader) oracleDataReader).HasRows)
            {
              while (((DbDataReader) oracleDataReader).Read())
                cfcsPaymentsLog = CFCS_PAYMENTS_LOG_DB.FillDataRecord((IDataRecord) oracleDataReader);
            }
            ((DbDataReader) oracleDataReader).Close();
          }
          ((DbConnection) conn).Close();
        }
      }
      return cfcsPaymentsLog;
    }

    public static CFCS_PAYMENTS_LOG_List GetList_ReadyFTP(string payStatus)
    {
      CFCS_PAYMENTS_LOG_List cfcsPaymentsLogList = new CFCS_PAYMENTS_LOG_List();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.GET_CFC_INV_PAYMENTS_FTP", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (payStatus == string.Empty)
            oracleCommand.Parameters.Add("PI_PAY_STATUS", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_PAY_STATUS", (object) payStatus);
          oracleCommand.Parameters.Add("PO_INV_CUR", OracleDbType.RefCursor, (object) DBNull.Value, ParameterDirection.Output);
          ((DbConnection) conn).Open();
          using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader())
          {
            if (((DbDataReader) oracleDataReader).HasRows)
            {
              while (((DbDataReader) oracleDataReader).Read())
                cfcsPaymentsLogList.Add(CFCS_PAYMENTS_LOG_DB.FillDataRecord((IDataRecord) oracleDataReader));
            }
            ((DbDataReader) oracleDataReader).Close();
          }
          ((DbConnection) conn).Close();
        }
      }
      return cfcsPaymentsLogList;
    }

    public static Status Save(CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG, string type)
    {
      Status status = new Status();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.UPDATE_CFC_FILE_REFS", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (myCFCS_PAYMENTS_LOG.COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.COMP_CODE, ParameterDirection.Input);
          if (type == string.Empty)
            oracleCommand.Parameters.Add("PI_TYPE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_TYPE", OracleDbType.Varchar2, (object) type, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.PAY_TXN_REFERENCE == string.Empty)
            oracleCommand.Parameters.Add("PI_REFERENCE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_REFERENCE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.PAY_TXN_REFERENCE, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.CFC_REFERENCE == string.Empty)
            oracleCommand.Parameters.Add("PI_CFC_REFERENCE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_CFC_REFERENCE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.CFC_REFERENCE, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.CFC_FILE_REF == string.Empty)
            oracleCommand.Parameters.Add("PI_FILE_REFERENCE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_FILE_REFERENCE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.CFC_FILE_REF, ParameterDirection.Input);
          OracleParameter oracleParameter1 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_RET_DESCR", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          ((DbConnection) conn).Open();
          OracleTransaction oracleTransaction = conn.BeginTransaction(IsolationLevel.ReadCommitted);
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            ((DbTransaction) oracleTransaction).Commit();
            status.Code = ((DbParameter) oracleParameter1).Value.ToString();
            status.Description = ((DbParameter) oracleParameter2).Value.ToString();
          }
          catch (Exception ex)
          {
            status.Code = "FAILED";
            status.Description = ex.Message;
            ((DbTransaction) oracleTransaction).Rollback();
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
      return status;
    }

    public static Status SavePayment(CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG)
    {
      Status status = new Status();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.UPDATE_CFC_PAYMENTS", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (myCFCS_PAYMENTS_LOG.COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.COMP_CODE, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.CFC_REFERENCE == string.Empty)
            oracleCommand.Parameters.Add("PI_REFERENCE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_REFERENCE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.CFC_REFERENCE, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.COMP_ACK_REFERENCE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_ACK_REF", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_ACK_REF", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.COMP_ACK_REFERENCE, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.PAYMENT_STATUS == string.Empty)
            oracleCommand.Parameters.Add("PI_PAY_STATUS", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_PAY_STATUS", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.PAYMENT_STATUS, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.COMP_ACTION_REMARKS == string.Empty)
            oracleCommand.Parameters.Add("PI_REMARKS", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_REMARKS", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.COMP_ACTION_REMARKS, ParameterDirection.Input);
          OracleParameter oracleParameter1 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_RET_DESCR", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          ((DbConnection) conn).Open();
          OracleTransaction oracleTransaction = conn.BeginTransaction(IsolationLevel.ReadCommitted);
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            ((DbTransaction) oracleTransaction).Commit();
            status.Code = ((DbParameter) oracleParameter1).Value.ToString();
            status.Description = ((DbParameter) oracleParameter2).Value.ToString();
          }
          catch (Exception ex)
          {
            status.Code = "FAILED";
            status.Description = ex.Message;
            ((DbTransaction) oracleTransaction).Rollback();
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
      return status;
    }

    public static Status Save(CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG)
    {
      Status status = new Status();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.UPDATE_CFC_CONFIRM", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (myCFCS_PAYMENTS_LOG.COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.COMP_CODE, ParameterDirection.Input);
          if (myCFCS_PAYMENTS_LOG.CFC_FILE_REF == string.Empty)
            oracleCommand.Parameters.Add("PI_FILE_REFERENCE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_FILE_REFERENCE", OracleDbType.Varchar2, (object) myCFCS_PAYMENTS_LOG.CFC_FILE_REF, ParameterDirection.Input);
          OracleParameter oracleParameter1 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_RET_DESCR", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          ((DbConnection) conn).Open();
          OracleTransaction oracleTransaction = conn.BeginTransaction(IsolationLevel.ReadCommitted);
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            ((DbTransaction) oracleTransaction).Commit();
            status.Code = ((DbParameter) oracleParameter1).Value.ToString();
            status.Description = ((DbParameter) oracleParameter2).Value.ToString();
          }
          catch (Exception ex)
          {
            status.Code = "FAILED";
            status.Description = ex.Message;
            ((DbTransaction) oracleTransaction).Rollback();
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
      return status;
    }

    private static CFCS_PAYMENTS_LOG FillDataRecord(IDataRecord myDataRecord)
    {
      CFCS_PAYMENTS_LOG cfcsPaymentsLog = new CFCS_PAYMENTS_LOG();
      int fieldCount = myDataRecord.FieldCount;
      for (int i = 0; i < fieldCount; ++i)
      {
        switch (myDataRecord.GetName(i))
        {
          case "BSF_REMARKS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.BSF_REMARKS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CFC_FILE_REF":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CFC_FILE_REF = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CFC_REFERENCE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CFC_REFERENCE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "COLC_CONF_DATETIME":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COLC_CONF_DATETIME = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "COLC_POST_DATETIME":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COLC_POST_DATETIME = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "COLLCT_ACCT_NO":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COLLCT_ACCT_NO = myDataRecord.GetString(i);
              break;
            }
            break;
          case "COMP_ACK_REFERENCE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COMP_ACK_REFERENCE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "COMP_ACTION_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COMP_ACTION_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "COMP_ACTION_REMARKS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COMP_ACTION_REMARKS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "COMP_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.COMP_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CREATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CREATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "CREDT_ACCT_CRNCY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CREDT_ACCT_CRNCY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREDT_ACCT_NO":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CREDT_ACCT_NO = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREDT_AMOUNT":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CREDT_AMOUNT = Convert.ToDouble(myDataRecord.GetDecimal(i));
              break;
            }
            break;
          case "CREDT_CRNCY_RATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CREDT_CRNCY_RATE = myDataRecord.GetDouble(i);
              break;
            }
            break;
          case "CUSTOMER_ID":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.CUSTOMER_ID = myDataRecord.GetString(i);
              break;
            }
            break;
          case "DEBIT_ACCT_CRNCY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.DEBIT_ACCT_CRNCY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "DEBIT_ACCT_NO":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.DEBIT_ACCT_NO = myDataRecord.GetString(i);
              break;
            }
            break;
          case "DEBIT_AMOUNT":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.DEBIT_AMOUNT = myDataRecord.GetDouble(i);
              break;
            }
            break;
          case "DEBIT_CRNCY_RATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.DEBIT_CRNCY_RATE = myDataRecord.GetDouble(i);
              break;
            }
            break;
          case "INIT_BRANCH":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.INIT_BRANCH = myDataRecord.GetString(i);
              break;
            }
            break;
          case "INV_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.INV_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "INV_NO":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.INV_NO = myDataRecord.GetString(i);
              break;
            }
            break;
          case "PAYMENT_STATUS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.PAYMENT_STATUS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "PAY_GRP_INV_SEQ":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.PAY_GRP_INV_SEQ = Convert.ToDouble(myDataRecord.GetDecimal(i));
              break;
            }
            break;
          case "PAY_GRP_TOT_INV":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.PAY_GRP_TOT_INV = Convert.ToDouble(myDataRecord.GetDecimal(i));
              break;
            }
            break;
          case "PAY_TXN_REFERENCE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.PAY_TXN_REFERENCE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "PAY_TYPE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.PAY_TYPE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "REMITTER_BANK_REF":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.REMITTER_BANK_REF = myDataRecord.GetString(i);
              break;
            }
            break;
          case "REMITTER_NAME":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.REMITTER_NAME = myDataRecord.GetString(i);
              break;
            }
            break;
          case "SOURCE_SYSTEM":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.SOURCE_SYSTEM = myDataRecord.GetString(i);
              break;
            }
            break;
          case "TOTAL_INV_AMOUNT":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TOTAL_INV_AMOUNT = Convert.ToDouble(myDataRecord.GetDecimal(i));
              break;
            }
            break;
          case "TOTAL_INV_COUNT":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TOTAL_INV_COUNT = Convert.ToDouble(myDataRecord.GetDecimal(i));
              break;
            }
            break;
          case "TRANS_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TRANS_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "TRANS_DATE_TIME":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TRANS_DATE_TIME = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "TRANS_REFERENCE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TRANS_REFERENCE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "TRANS_STATUS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TRANS_STATUS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "TRANS_TYPE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.TRANS_TYPE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "UPDATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.UPDATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "UPDATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.UPDATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "VALUE_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsPaymentsLog.VALUE_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          default:
            throw new Exception("New column found in CFCS_PAYMENTS_LOG or column name not matched, verify data persistence over class", new Exception("myCFCS_PAYMENTS_LOG filling failed"));
        }
      }
      return cfcsPaymentsLog;
    }
  }
}
