﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CFCS_CUSTOMERS
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;

namespace BackEndLayers.BO
{
  public class CFCS_CUSTOMERS
  {
    private string _COMP_CODE = string.Empty;
    private string _CUSTOMER_ID = string.Empty;
    private string _CUSTOMER_NAME = string.Empty;
    private string _CUSTOMER_TYPE = string.Empty;
    private string _CUSTOMER_CITY = string.Empty;
    private string _STATUS = string.Empty;
    private string _CRNCY_CODE = string.Empty;
    private DateTime _CREATED_DATE = DateTime.MinValue;
    private string _CREATED_BY = string.Empty;
    private DateTime _UPDATED_DATE = DateTime.MinValue;
    private string _UPDATED_BY = string.Empty;

    public string COMP_CODE
    {
      get
      {
        return this._COMP_CODE;
      }
      set
      {
        this._COMP_CODE = value.Trim();
      }
    }

    public string CUSTOMER_ID
    {
      get
      {
        return this._CUSTOMER_ID;
      }
      set
      {
        this._CUSTOMER_ID = value.Trim();
      }
    }

    public string CUSTOMER_NAME
    {
      get
      {
        return this._CUSTOMER_NAME;
      }
      set
      {
        this._CUSTOMER_NAME = value.Trim();
      }
    }

    public string CUSTOMER_TYPE
    {
      get
      {
        return this._CUSTOMER_TYPE;
      }
      set
      {
        this._CUSTOMER_TYPE = value.Trim();
      }
    }

    public string CUSTOMER_CITY
    {
      get
      {
        return this._CUSTOMER_CITY;
      }
      set
      {
        this._CUSTOMER_CITY = value.Trim();
      }
    }

    public string STATUS
    {
      get
      {
        return this._STATUS;
      }
      set
      {
        this._STATUS = value.Trim();
      }
    }

    public string CRNCY_CODE
    {
      get
      {
        return this._CRNCY_CODE;
      }
      set
      {
        this._CRNCY_CODE = value.Trim();
      }
    }

    public DateTime CREATED_DATE
    {
      get
      {
        return this._CREATED_DATE;
      }
      set
      {
        this._CREATED_DATE = value;
      }
    }

    public string CREATED_BY
    {
      get
      {
        return this._CREATED_BY;
      }
      set
      {
        this._CREATED_BY = value.Trim();
      }
    }

    public DateTime UPDATED_DATE
    {
      get
      {
        return this._UPDATED_DATE;
      }
      set
      {
        this._UPDATED_DATE = value;
      }
    }

    public string UPDATED_BY
    {
      get
      {
        return this._UPDATED_BY;
      }
      set
      {
        this._UPDATED_BY = value.Trim();
      }
    }
  }
}
