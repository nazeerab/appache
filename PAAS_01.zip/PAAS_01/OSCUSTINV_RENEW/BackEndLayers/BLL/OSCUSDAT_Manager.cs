﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.OSCUSDAT_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO.OSCUSDAT;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BackEndLayers.BLL
{
  public class OSCUSDAT_Manager
  {
    public static Message XMLtoOSCUSDAT(string path)
    {
      Message message = new Message();
      try
      {
        string xml = Util.ReadFile(path);
        if (xml != null)
          message = Util.DeserializeFromXml<Message>(xml);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return message;
    }

    public static MessageHeader GetMessageHeader(Message M)
    {
      MessageHeader messageHeader = new MessageHeader();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null && M.Items[index].GetType().Name == "MessageHeader")
            return (MessageHeader) M.Items[index];
        }
      }
      return messageHeader;
    }

    public static MessageBody GetMessageBody(Message M)
    {
      MessageBody messageBody = new MessageBody();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null && M.Items[index].GetType().Name == "MessageBody")
            return (MessageBody) M.Items[index];
        }
      }
      return messageBody;
    }

    public static List<MessageBodyCustomerInfo> GetCustomers(Message M)
    {
      MessageBody messageBody1 = new MessageBody();
      List<MessageBodyCustomerInfo> bodyCustomerInfoList = new List<MessageBodyCustomerInfo>();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null && M.Items[index].GetType().Name == "MessageBody")
          {
            MessageBody messageBody2 = (MessageBody) M.Items[index];
            if (messageBody2 != null && messageBody2.CustomerInfo != null)
              bodyCustomerInfoList = ((IEnumerable<MessageBodyCustomerInfo>) messageBody2.CustomerInfo).ToList<MessageBodyCustomerInfo>();
          }
        }
      }
      return bodyCustomerInfoList;
    }
  }
}
