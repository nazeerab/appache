﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.OSCUSDATValidation_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.OSCUSDAT;
using System;
using System.Collections.Generic;
using System.Linq;
using Validation;

namespace BackEndLayers.BLL
{
  public class OSCUSDATValidation_Manager
  {
    public static Reports MessageValidation(
      Message Msg,
      string fileName,
      string companyCode,
      out List<MessageBodyCustomerInfo> Valid_Customers_List,
      out bool isValid)
    {
      Reports source = new Reports();
      int num1 = 0;
      bool flag1 = true;
      bool flag2 = true;
      bool flag3 = true;
      List<MessageBodyCustomerInfo> bodyCustomerInfoList = new List<MessageBodyCustomerInfo>();
      isValid = false;
      source.AddRange((IEnumerable<Report>) OSCUSDATValidation_Manager.ValidateXmlHeader(Msg, fileName));
      int num2 = source.Count<Report>();
      if (num2 > 0)
        flag1 = false;
      source.AddRange((IEnumerable<Report>) OSCUSDATValidation_Manager.ValidateXmlBody(Msg, fileName));
      if (source.Count<Report>() != num2)
      {
        num2 += source.Count<Report>();
        flag2 = false;
      }
      source.AddRange((IEnumerable<Report>) OSCUSDATValidation_Manager.ValidateXmlCustomers(Msg, fileName, out bodyCustomerInfoList));
      if (source.Count<Report>() != num2)
        num2 += source.Count<Report>();
      if (flag1 & flag2)
      {
        source.AddRange((IEnumerable<Report>) OSCUSDATValidation_Manager.ValidateHeaderFromDb(Msg, fileName, companyCode));
        if (source.Count<Report>() != num2)
        {
          num2 += source.Count<Report>();
          flag3 = false;
        }
        if (flag3)
        {
          source.AddRange((IEnumerable<Report>) OSCUSDATValidation_Manager.ValidateCustomersFromDb(bodyCustomerInfoList, fileName, companyCode, out bodyCustomerInfoList));
          if (source.Count<Report>() != num2)
            num1 = num2 + source.Count<Report>();
        }
      }
      if (flag1 & flag2 & flag3 && bodyCustomerInfoList != null && bodyCustomerInfoList.Count<MessageBodyCustomerInfo>() > 0)
        isValid = true;
      Valid_Customers_List = bodyCustomerInfoList;
      return source;
    }

    private static Reports ValidateXmlHeader(Message Msg, string fileName)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageHeader messageHeader = new MessageHeader();
      try
      {
        ValidationEngine.Validate((object) OSCUSDAT_Manager.GetMessageHeader(Msg));
      }
      catch (Exception ex)
      {
        report.Code = Util.XMLMessageParametersMissing(fileName);
        report.Detail = ex.Message;
        reports.Add(report);
      }
      return reports;
    }

    private static Reports ValidateXmlBody(Message Msg, string fileName)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageBody messageBody = new MessageBody();
      try
      {
        ValidationEngine.Validate((object) OSCUSDAT_Manager.GetMessageBody(Msg));
      }
      catch (Exception ex)
      {
        report.Code = Util.XMLMessageParametersMissing(fileName);
        report.Detail = ex.Message;
        reports.Add(report);
      }
      return reports;
    }

    private static Reports ValidateXmlCustomers(
      Message Msg,
      string fileName,
      out List<MessageBodyCustomerInfo> Customers)
    {
      Reports reports = new Reports();
      Report report = new Report();
      List<MessageBodyCustomerInfo> bodyCustomerInfoList1 = new List<MessageBodyCustomerInfo>();
      List<MessageBodyCustomerInfo> bodyCustomerInfoList2 = new List<MessageBodyCustomerInfo>();
      List<MessageBodyCustomerInfo> customers = OSCUSDAT_Manager.GetCustomers(Msg);
      for (int index = 0; index < customers.Count<MessageBodyCustomerInfo>(); ++index)
      {
        try
        {
          ValidationEngine.Validate((object) customers[index]);
          bodyCustomerInfoList2.Add(customers[index]);
        }
        catch (Exception ex)
        {
          reports.Add(new Report()
          {
            Code = Util.XMLMessageParametersMissing(fileName),
            Detail = ex.Message
          });
        }
      }
      Customers = bodyCustomerInfoList2;
      return reports;
    }

    private static Reports ValidateHeaderFromDb(
      Message Msg,
      string fileName,
      string companyCode)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageHeader messageHeader1 = new MessageHeader();
      MessageHeader messageHeader2 = OSCUSDAT_Manager.GetMessageHeader(Msg);
      if (messageHeader2.Sender.Trim().ToLower() != CFCS_COMPANY_PROFILE_Manager.Item(companyCode, "COMPPROF").COMP_SYS_CODE.Trim().ToLower())
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid Sender found."
        });
      if (messageHeader2.Receiver.Trim().ToLower() != Codes.BankID.Trim().ToLower())
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid Receiver found."
        });
      if (!(messageHeader2.MessageType.Trim().ToLower() == "OSCUSDAT-CREDIT".Trim().ToLower()) && !(messageHeader2.MessageType.Trim().ToLower() == "OSCUSDAT".Trim().ToLower()))
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid MessageType found."
        });
      return reports;
    }

    private static Reports ValidateCustomersFromDb(
      List<MessageBodyCustomerInfo> Customers,
      string fileName,
      string companyCode,
      out List<MessageBodyCustomerInfo> VCustomers)
    {
      Reports reports1 = new Reports();
      Reports reports2 = new Reports();
      List<MessageBodyCustomerInfo> bodyCustomerInfoList = new List<MessageBodyCustomerInfo>();
      for (int index = 0; index < Customers.Count<MessageBodyCustomerInfo>(); ++index)
      {
        reports2 = new Reports();
        Reports source = OSCUSDATValidation_Manager.ValidateCustomerFromDb(Customers[index], fileName, companyCode);
        if (source.Count<Report>() <= 0)
          bodyCustomerInfoList.Add(Customers[index]);
        reports1.AddRange((IEnumerable<Report>) source);
      }
      VCustomers = bodyCustomerInfoList;
      return reports1;
    }

    private static Reports ValidateCustomerFromDb(
      MessageBodyCustomerInfo iCustomer,
      string fileName,
      string companyCode)
    {
      CFCS_CUSTOMERS cfcsCustomers = new CFCS_CUSTOMERS();
      Reports reports = new Reports();
      Report report = new Report();
      try
      {
        if (Convert.ToInt32(iCustomer.CustomerType.ToLower().Trim()) < 1 || Convert.ToInt32(iCustomer.CustomerType.ToLower().Trim()) > 5)
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " of CustomerID " + iCustomer.CustomerID + " customer type is not valid."
          });
        if (!(iCustomer.ActionFlag.ToLower().Trim() == "a"))
        {
          if (!(iCustomer.ActionFlag.ToLower().Trim() == "d"))
            reports.Add(new Report()
            {
              Code = Util.MessageParametersInvalid(fileName),
              Detail = "In " + fileName + " of CustomerID " + iCustomer.CustomerID + " customer action flag is not valid."
            });
        }
      }
      catch (Exception ex)
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName) + "  Not a valid customer found: " + iCustomer.CustomerID,
          Detail = ex.Message
        });
      }
      return reports;
    }
  }
}
