﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.OSCUSTINVValidation_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSTINV;
using System;
using System.Collections.Generic;
using System.Linq;
using Validation;

namespace BackEndLayers.BLL
{
  public class OSCUSTINVValidation_Manager
  {
    public static Reports MessageValidation(
      Message Msg,
      string fileName,
      out List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Details,
      string companyCode,
      out bool isValid)
    {
      Reports reports = new Reports();
      bool isValid1 = false;
      bool isValid2 = false;
      bool isValid3 = false;
      isValid = false;
      List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Details1 = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Detail_List = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.XMLMessageValidation(Msg, fileName, out Valid_Details1, out isValid1));
      if (isValid1)
        reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.ValidateHeaderFromDb(Msg, fileName, companyCode, out isValid2));
      if (isValid2 & isValid1)
        reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.Validate_All_Invoices_FromDb(Valid_Details1, fileName, out Valid_Detail_List, companyCode, out isValid3));
      if (isValid1 & isValid2 && Valid_Detail_List != null && Valid_Detail_List.Count<MessageBodyCustomerInvoiceInvoiceDetail>() > 0)
        isValid = true;
      Valid_Details = Valid_Detail_List;
      return reports;
    }

    private static Reports XMLMessageValidation(
      Message Msg,
      string fileName,
      out List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Details,
      out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      List<MessageBodyCustomerInvoiceInvoiceDetail> invoiceInvoiceDetailList = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Detail_List = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      isValid = false;
      bool isValid1 = false;
      bool isValid2 = false;
      bool isValid3 = false;
      bool isValid4 = false;
      bool isValid5 = false;
      try
      {
        reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.ValidateXmlHeader(Msg, fileName, out isValid1));
        reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.ValidateXmlBody(Msg, fileName, out isValid2));
        reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.ValidateXmlInvoices(Msg, fileName, out isValid3));
        reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.ValidateXmlResponseStatus(Msg, fileName, out isValid5));
        if (isValid1 & isValid2 & isValid3 & isValid5)
        {
          List<MessageBodyCustomerInvoiceInvoiceDetail> bodyInvoicesDetail = OSCUSTINV_Manager.GetMessageBodyInvoicesDetail(Msg);
          reports.AddRange((IEnumerable<Report>) OSCUSTINVValidation_Manager.ValidateXmlInvoiceDetails(bodyInvoicesDetail, fileName, out Valid_Detail_List, out isValid4));
          isValid = true;
        }
      }
      catch (Exception ex)
      {
        reports.Add(new Report()
        {
          Code = Util.XMLMessageParametersMissing(fileName),
          Detail = ex.Message.Trim()
        });
        isValid = false;
      }
      Valid_Details = Valid_Detail_List;
      return reports;
    }

    private static Reports ValidateXmlHeader(Message Msg, string fileName, out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageHeader messageHeader = new MessageHeader();
      isValid = true;
      try
      {
        ValidationEngine.Validate((object) OSCUSTINV_Manager.GetMessageHeader(Msg));
      }
      catch (Exception ex)
      {
        report.Code = Util.XMLMessageParametersMissing(fileName);
        report.Detail = ex.Message;
        reports.Add(report);
        isValid = false;
      }
      return reports;
    }

    private static Reports ValidateXmlBody(Message Msg, string fileName, out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageBody messageBody = new MessageBody();
      isValid = true;
      try
      {
        ValidationEngine.Validate((object) OSCUSTINV_Manager.GetMessageBody(Msg));
      }
      catch (Exception ex)
      {
        report.Code = Util.XMLMessageParametersMissing(fileName);
        report.Detail = ex.Message;
        reports.Add(report);
        isValid = false;
      }
      return reports;
    }

    private static Reports ValidateXmlInvoices(
      Message Msg,
      string fileName,
      out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      List<MessageBodyCustomerInvoice> bodyCustomerInvoiceList = new List<MessageBodyCustomerInvoice>();
      isValid = true;
      try
      {
        List<MessageBodyCustomerInvoice> messageBodyInvoices = OSCUSTINV_Manager.GetMessageBodyInvoices(Msg);
        for (int index = 0; index < messageBodyInvoices.Count<MessageBodyCustomerInvoice>(); ++index)
        {
          try
          {
            ValidationEngine.Validate((object) messageBodyInvoices[index]);
          }
          catch (Exception ex)
          {
            report.Code = Util.XMLMessageParametersMissing(fileName);
            report.Detail = ex.Message;
            reports.Add(report);
            isValid = false;
          }
        }
      }
      catch (Exception ex)
      {
        report.Code = report.Code = Util.XMLMessageParametersMissing(fileName);
        report.Detail = ex.Message;
        reports.Add(report);
        isValid = false;
      }
      return reports;
    }

    private static Reports ValidateXmlInvoiceDetails(
      List<MessageBodyCustomerInvoiceInvoiceDetail> Detail_List,
      string fileName,
      out List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Detail_List,
      out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      List<MessageBodyCustomerInvoiceInvoiceDetail> invoiceInvoiceDetailList = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      isValid = true;
      for (int index = 0; index < Detail_List.Count<MessageBodyCustomerInvoiceInvoiceDetail>(); ++index)
      {
        try
        {
          ValidationEngine.Validate((object) Detail_List[index]);
          invoiceInvoiceDetailList.Add(Detail_List[index]);
        }
        catch (Exception ex)
        {
          report.Code = Util.XMLMessageParametersMissing(fileName);
          report.Detail = ex.Message;
          reports.Add(report);
          isValid = false;
        }
      }
      Valid_Detail_List = invoiceInvoiceDetailList;
      return reports;
    }

    private static Reports ValidateXmlResponseStatus(
      Message Msg,
      string fileName,
      out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageResponseStatus messageResponseStatus = new MessageResponseStatus();
      MessageResponseStatus responseStatus = OSCUSTINV_Manager.GetResponseStatus(Msg);
      isValid = true;
      if (responseStatus.StatusCode != null)
      {
        if (responseStatus.StatusCode.Trim().ToLower() != Codes.StatusCode.Trim().ToLower())
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " ResponseStatus, not a valid StatusCode found."
          });
          isValid = false;
        }
      }
      else
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " ResponseStatus, not a valid StatusCode found."
        });
        isValid = false;
      }
      if (responseStatus.StatusDetail != null)
      {
        if (responseStatus.StatusDetail.Trim().ToLower() != Codes.StatusDetail.Trim().ToLower())
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " ResponseStatus, not a valid StatusDetail found."
          });
          isValid = false;
        }
      }
      else
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " ResponseStatus, not a valid StatusDetail found."
        });
        isValid = false;
      }
      return reports;
    }

    private static Reports Validate_All_Invoices_FromDb(
      List<MessageBodyCustomerInvoiceInvoiceDetail> Detail_List,
      string fileName,
      out List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Detail_List,
      string companyCode,
      out bool isValid)
    {
      Reports reports = new Reports();
      Reports source1 = new Reports();
      Report report = new Report();
      List<MessageBodyCustomerInvoiceInvoiceDetail> invoiceInvoiceDetailList = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      isValid = true;
      for (int index = 0; index < Detail_List.Count<MessageBodyCustomerInvoiceInvoiceDetail>(); ++index)
      {
        Reports source2 = OSCUSTINVValidation_Manager.ValidateInvoiceFromDb(Detail_List[index], fileName, companyCode, out isValid);
        if (source2.Count<Report>() <= 0)
          invoiceInvoiceDetailList.Add(Detail_List[index]);
        source1.AddRange((IEnumerable<Report>) source2);
      }
      if (source1.Count<Report>() > 0)
        isValid = false;
      Valid_Detail_List = invoiceInvoiceDetailList;
      return source1;
    }

    private static Reports ValidateHeaderFromDb(
      Message Msg,
      string fileName,
      string companyCode,
      out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      MessageHeader messageHeader1 = new MessageHeader();
      MessageHeader messageHeader2 = OSCUSTINV_Manager.GetMessageHeader(Msg);
      isValid = true;
      if (messageHeader2.Sender.Trim().ToLower() != CFCS_COMPANY_PROFILE_Manager.Item(companyCode, "COMPPROF").COMP_SYS_CODE.Trim().ToLower())
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid Sender found."
        });
        isValid = false;
      }
      if (messageHeader2.Receiver.Trim().ToLower() != Codes.BankID.Trim().ToLower())
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid Receiver found."
        });
        isValid = false;
      }
      if (messageHeader2.MessageType.Trim().ToLower() != Codes.MessageType.Trim().ToLower())
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid MessageType found."
        });
        isValid = false;
      }
      return reports;
    }

    private static Reports ValidateInvoiceFromDb(
      MessageBodyCustomerInvoiceInvoiceDetail Detail,
      string fileName,
      string companyCode,
      out bool isValid)
    {
      Reports reports = new Reports();
      Report report = new Report();
      isValid = true;
      try
      {
        if (!(Detail.Status.Trim().ToLower() == "open") && !(Detail.Status.Trim().ToLower() == "cleared"))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid Status."
          });
          isValid = false;
        }
        if (!CFCS_CUSTOMERS_Manager.IsValidCustomer(Detail.CustomerNumber, companyCode))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid CustomerNumber."
          });
          isValid = false;
        }
        if (!(Convert.ToDateTime(Detail.InvoiceDate) > DateTime.MinValue) || !(Convert.ToDateTime(Detail.InvoiceDate) < DateTime.MaxValue))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid InvoiceDate."
          });
          isValid = false;
        }
        if (!(Convert.ToDateTime(Detail.InvoiceDueDate) > DateTime.MinValue) || !(Convert.ToDateTime(Detail.InvoiceDueDate) < DateTime.MaxValue))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid InvoiceDueDate."
          });
          isValid = false;
        }
        if (Convert.ToDouble(Detail.InvoiceAmount) <= 0.0 && Convert.ToDouble(Detail.InvoiceAmount) >= 0.0)
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid InvoiceAmount."
          });
          isValid = false;
        }
        if (Convert.ToDouble(Detail.EquivalentAmount) <= 0.0 && Convert.ToDouble(Detail.EquivalentAmount) >= 0.0)
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid EquivalentAmount."
          });
          isValid = false;
        }
        if (Convert.ToDouble(Detail.InvoiceAmount) < 0.0 && Convert.ToDouble(Detail.EquivalentAmount) >= 0.0)
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid InvoiceAmount and EquivalentAmount."
          });
          isValid = false;
        }
        if (Convert.ToDouble(Detail.EquivalentAmount) < 0.0 && Convert.ToDouble(Detail.InvoiceAmount) >= 0.0)
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", dose not contains valid InvoiceAmount and EquivalentAmount."
          });
          isValid = false;
        }
        if (!(Detail.EquivalentCurrency.Trim().ToLower() != Detail.InvoiceCurrency.Trim().ToLower()))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", there is conflict between InvoiceCurrency and EquivalentCurrency."
          });
          isValid = false;
        }
        if (!OSCUSTINVValidation_Manager.CurrencyExists(companyCode, Detail.InvoiceCurrency))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", InvoiceCurrency is not supported."
          });
          isValid = false;
        }
        if (!OSCUSTINVValidation_Manager.CurrencyExists(companyCode, Detail.EquivalentCurrency))
        {
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", EquivalentCurrency is not supported."
          });
          isValid = false;
        }
      }
      catch (Exception ex)
      {
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " invoice number: " + Detail.InvoiceNumber + ", " + ex.Message
        });
        isValid = false;
      }
      return reports;
    }

    private static bool CurrencyExists(string companyCode, string curcny)
    {
      CFCS_COMPANY_PROFILE_List companyProfileList = new CFCS_COMPANY_PROFILE_List();
      CFCS_COMPANY_PROFILE_List source = CFCS_COMPANY_PROFILE_Manager.Get(companyCode, "INVCRNCY");
      for (int index = 0; index < source.Count<CFCS_COMPANY_PROFILE>(); ++index)
      {
        if (source[index].CRNCY_Code.Trim().ToLower() == curcny.Trim().ToLower())
          return true;
      }
      return false;
    }
  }
}
