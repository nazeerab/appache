﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CCACKValidation_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.CCACK;
using System;
using System.Collections.Generic;
using System.Linq;
using Validation;

namespace BackEndLayers.BLL
{
  public class CCACKValidation_Manager
  {
    public static Reports MessageValidation(
      Message Msg,
      string fileName,
      string companyCode,
      out List<Transaction> Valid_ACK,
      out bool isValid)
    {
      bool flag1 = true;
      bool flag2 = true;
      bool flag3 = true;
      isValid = false;
      Reports source = new Reports();
      List<Transaction> V_Acks = new List<Transaction>();
      List<Transaction> Acks = new List<Transaction>();
      int num = 0;
      source.AddRange((IEnumerable<Report>) CCACKValidation_Manager.ValidateXmlHeader(Msg, fileName));
      if (source.Count<Report>() > 0)
      {
        num = source.Count<Report>();
        flag1 = false;
      }
      if (flag1)
      {
        source.AddRange((IEnumerable<Report>) CCACKValidation_Manager.ValidateHeaderFromDb(Msg, fileName, companyCode));
        if (num != source.Count<Report>())
        {
          num = source.Count<Report>();
          flag2 = false;
        }
      }
      if (flag1 & flag2)
      {
        source.AddRange((IEnumerable<Report>) CCACKValidation_Manager.ValidateXmlAcks(CCACK_Manager.GetAckTransaction(Msg), fileName, out Acks));
        if (num != source.Count<Report>())
        {
          num = source.Count<Report>();
          flag3 = false;
        }
      }
      if (flag1 & flag2 & flag3)
      {
        source.AddRange((IEnumerable<Report>) CCACKValidation_Manager.ValidateAcksFromDb(Acks, out V_Acks, fileName, companyCode));
        if (num != source.Count<Report>())
          source.Count<Report>();
      }
      Valid_ACK = V_Acks;
      if (V_Acks.Count<Transaction>() > 0)
        isValid = true;
      return source;
    }

    private static Reports ValidateXmlHeader(Message Msg, string fileName)
    {
      Reports reports = new Reports();
      Report report = new Report();
      Header header = new Header();
      try
      {
        ValidationEngine.Validate((object) CCACK_Manager.GetMessageHeader(Msg));
      }
      catch (Exception ex)
      {
        report.Code = Util.XMLMessageParametersMissing(fileName);
        report.Detail = ex.Message;
        reports.Add(report);
      }
      return reports;
    }

    private static Reports ValidateXmlAcks(
      List<Transaction> Ack_List,
      string fileName,
      out List<Transaction> Acks)
    {
      Reports reports = new Reports();
      Report report = new Report();
      List<Transaction> transactionList = new List<Transaction>();
      for (int index = 0; index < Ack_List.Count<Transaction>(); ++index)
      {
        try
        {
          ValidationEngine.Validate((object) Ack_List[index]);
          transactionList.Add(Ack_List[index]);
        }
        catch (Exception ex)
        {
          reports.Add(new Report()
          {
            Code = Util.XMLMessageParametersMissing(fileName),
            Detail = ex.Message
          });
        }
      }
      Acks = transactionList;
      return reports;
    }

    private static Reports ValidateHeaderFromDb(
      Message Msg,
      string fileName,
      string companyCode)
    {
      Reports reports = new Reports();
      Report report = new Report();
      Header header = new Header();
      Header messageHeader = CCACK_Manager.GetMessageHeader(Msg);
      if (messageHeader.Sender.Trim().ToLower() != CFCS_COMPANY_PROFILE_Manager.Item(companyCode, "COMPPROF").COMP_SYS_CODE.Trim().ToLower())
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid Sender found."
        });
      if (messageHeader.Receiver.Trim().ToLower() != Codes.BankID.Trim().ToLower())
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid Receiver found."
        });
      if (!(messageHeader.MessageType.Trim().ToLower() == "CCACK-CREDIT".Trim().ToLower()))
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " header, not a valid MessageType found."
        });
      return reports;
    }

    private static Reports ValidateAcksFromDb(
      List<Transaction> Acks,
      out List<Transaction> V_Acks,
      string fileName,
      string companyCode)
    {
      Report report = new Report();
      Reports reports1 = new Reports();
      Reports reports2 = new Reports();
      List<Transaction> transactionList = new List<Transaction>();
      for (int index = 0; index < Acks.Count<Transaction>(); ++index)
      {
        Reports source = new Reports();
        source.AddRange((IEnumerable<Report>) CCACKValidation_Manager.ValidateAckFromDb(Acks[index], fileName, companyCode));
        if (source.Count<Report>() <= 0)
          transactionList.Add(Acks[index]);
        reports2.AddRange((IEnumerable<Report>) source);
      }
      V_Acks = transactionList;
      return reports2;
    }

    private static Reports ValidateAckFromDb(
      Transaction Ack,
      string fileName,
      string companyCode)
    {
      Reports reports = new Reports();
      Report report = new Report();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog1 = new CFCS_PAYMENTS_LOG();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog2 = CFCS_PAYMENTS_LOG_Manager.GetItem(companyCode, Ack.SequenceNumber, PaymentStatus.CONF, InqType.SQDET);
      if (cfcsPaymentsLog2 != null)
      {
        if (!(cfcsPaymentsLog2.PAYMENT_STATUS.ToLower().Trim() == PaymentStatus.CONF.ToString().Trim().ToLower()))
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " sequence number: " + Ack.SequenceNumber + ", does not have a vaild invoice."
          });
        if (!(Ack.StatusCode.Trim().ToLower() == "ok") && !(Ack.StatusCode.Trim().ToLower() == "de"))
          reports.Add(new Report()
          {
            Code = Util.MessageParametersInvalid(fileName),
            Detail = "In " + fileName + " sequence number: " + Ack.SequenceNumber + ", does not have a vaild status(" + Ack.StatusCode + ")."
          });
      }
      else
        reports.Add(new Report()
        {
          Code = Util.MessageParametersInvalid(fileName),
          Detail = "In " + fileName + " sequence number: " + Ack.SequenceNumber + ", does not have a vaild invoice."
        });
      return reports;
    }
  }
}
