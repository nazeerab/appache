﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.LogISCCCON
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BLL;
using BackEndLayers.BO.ISCCON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BackEndLayers.Log
{
  public class LogISCCCON : Logs
  {
    public void Log(Message Msg, string fileName)
    {
      MessageBody messageBody1 = new MessageBody();
      StringBuilder stringBuilder = new StringBuilder();
      MessageBody messageBody2 = ISCCON_Manager.GetMessageBody(Msg);
      int num1 = 0;
      int num2 = 0;
      int num3 = 0;
      if (messageBody2 != null && messageBody2.CreditConfirmation != null)
      {
        ((IEnumerable<MessageBodyCreditConfirmationTransaction>) messageBody2.CreditConfirmation).Count<MessageBodyCreditConfirmationTransaction>();
        for (int index1 = 0; index1 < ((IEnumerable<MessageBodyCreditConfirmationTransaction>) messageBody2.CreditConfirmation).Count<MessageBodyCreditConfirmationTransaction>(); ++index1)
        {
          if (((IEnumerable<MessageBodyCreditConfirmationTransactionInvoiceDetail>) messageBody2.CreditConfirmation[index1].InvoiceDetail).Count<MessageBodyCreditConfirmationTransactionInvoiceDetail>() > 1)
          {
            ++num1;
            for (int index2 = 0; index2 < ((IEnumerable<MessageBodyCreditConfirmationTransactionInvoiceDetail>) messageBody2.CreditConfirmation[index1].InvoiceDetail).Count<MessageBodyCreditConfirmationTransactionInvoiceDetail>(); ++index2)
              ++num3;
          }
          else
          {
            ++num2;
            int num4 = 0;
            while (num4 < ((IEnumerable<MessageBodyCreditConfirmationTransactionInvoiceDetail>) messageBody2.CreditConfirmation[index1].InvoiceDetail).Count<MessageBodyCreditConfirmationTransactionInvoiceDetail>())
              ++num4;
          }
        }
      }
      stringBuilder.Append("Process: ISCCON");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Groups:" + Convert.ToString(num1));
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Transactions In Groups:" + Convert.ToString(num3));
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Individuals Transactions:" + Convert.ToString(num2));
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Invoices: " + Convert.ToString(num1 + num2));
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), Eventtype.informaton);
    }

    public void Log(string str, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: ISCCCON");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(str);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }

    public void Log(Exception ex, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: ISCCCON");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Exception:  " + (object) ex);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }
  }
}
