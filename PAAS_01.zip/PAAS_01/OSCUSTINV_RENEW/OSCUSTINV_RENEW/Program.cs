﻿// Decompiled with JetBrains decompiler
// Type: OSCUSTINV_RENEW.Program
// Assembly: OSCUSTINV_RENEW, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2E27618C-7E0A-4D08-B5FC-7C9B64A32C92
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\OSCUSTINV_RENEW.exe

using BackEndLayers.BLL;
using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSTINV_RENEW;
using BackEndLayers.Log;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OSCUSTINV_RENEW
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      DateTime now = DateTime.Now;
      Reports reports = new Reports();
      List<MessageBodyCustomerInvoiceInvoiceDetail> InvDetail = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      CFCS_INVOICE_LOG_List cfcsInvoiceLogList = new CFCS_INVOICE_LOG_List();
      LogInvoiceRenew logInvoiceRenew = new LogInvoiceRenew();
      Message message = new Message();
      bool flag1 = false;
      string fileName1 = "";
      string empty = string.Empty;
      bool flag2 = true;
      Console.WriteLine("Process OSCUSTINV_RENEW is started.");
      try
      {
        string companyCode1 = args[0];
        Console.WriteLine("Company Code: " + companyCode1);
        string str = args[1];
        Console.WriteLine("File path: " + str);
        fileName1 = Util.GetFileName(str);
        Console.WriteLine("File name: " + fileName1);
        Console.WriteLine("Parsing message.");
        Message Msg = OSCUSTINV_RENEW_Manager.XMLtoOSCUSTINV_RENEW(str);
        Console.WriteLine("Parsing message done.");
        Console.WriteLine("Runing validation on message.");
        string fileName2 = fileName1;
        ref List<MessageBodyCustomerInvoiceInvoiceDetail> local1 = ref InvDetail;
        string companyCode2 = companyCode1;
        ref bool local2 = ref flag1;
        Reports R = OSCUSTINVRENEWValidation_Manager.MessageValidation(Msg, fileName2, out local1, companyCode2, out local2);
        Console.WriteLine("Validation on message done.");
        if (flag1)
        {
          if (flag1)
          {
            Console.WriteLine("Validation done and message parsed successfully.");
            CFCS_INVOICE_LOG_List invoices = CFCS_INVOICE_LOG_RENEW_Manager.GetInvoices(InvDetail, companyCode1);
            CFCS_INVOICE_LOG_RENEW_Manager.Save(invoices, fileName1);
            Console.WriteLine(invoices.Count<CFCS_INVOICE_LOG>().ToString() + " Invoice(s) proccess Successfully.");
            Console.WriteLine(Util.PrintReport(R));
            Console.WriteLine("Logging file.");
            logInvoiceRenew.Log(Util.PrintReport(R), fileName1, Eventtype.informaton);
            Console.WriteLine("Logging Complete.");
          }
        }
        else
        {
          Console.WriteLine("Invalid xml file, please check logs");
          Console.WriteLine(Util.PrintReport(R));
          Console.WriteLine("Logging files.");
          logInvoiceRenew.Log(Util.PrintReport(R), fileName1, Eventtype.informaton);
          Console.WriteLine("Logging Complete.");
        }
      }
      catch (IndexOutOfRangeException ex)
      {
        logInvoiceRenew.Log((Exception) ex, fileName1, Eventtype.Error);
        Console.WriteLine("Please provide compnay code as args[0] and path as args[1]");
        flag2 = false;
      }
      catch (Exception ex)
      {
        logInvoiceRenew.Log(ex, fileName1, Eventtype.Error);
        Console.WriteLine("Application terminated unsuccessfully, please check logs for detail.");
        flag2 = false;
      }
      if (flag2)
        Console.WriteLine("Process end with Success.");
      else
        Console.WriteLine("Process end with Failure.");
      Console.WriteLine("Process tooks " + (DateTime.Now - now).Milliseconds.ToString() + " MS to compelete.");
    }
  }
}
