﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.OSCUSDAT_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using BackEndLayers.BO.OSCUSDAT;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BackEndLayers.BLL
{
  public class OSCUSDAT_Manager
  {
    public static Message XMLtoOSCUSDAT(string path)
    {
      Message message = new Message();
      try
      {
        string xml = Util.ReadFile(path);
        if (xml != null)
          message = Util.DeserializeFromXml<Message>(xml);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return message;
    }

    public static MessageHeader GetMessageHeader(Message M)
    {
      MessageHeader messageHeader = new MessageHeader();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageHeader":
                return (MessageHeader) M.Items[index];
              default:
                continue;
            }
          }
        }
      }
      return messageHeader;
    }

    public static MessageBody GetMessageBody(Message M)
    {
      MessageBody messageBody = new MessageBody();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageBody":
                return (MessageBody) M.Items[index];
              default:
                continue;
            }
          }
        }
      }
      return messageBody;
    }

    public static List<MessageBodyCustomerInfo> GetCustomers(Message M)
    {
      MessageBody messageBody1 = new MessageBody();
      List<MessageBodyCustomerInfo> bodyCustomerInfoList = new List<MessageBodyCustomerInfo>();
      if (M != null && M.Items != null)
      {
        int num = ((IEnumerable<object>) M.Items).Count<object>();
        for (int index = 0; index < num; ++index)
        {
          if (M.Items[index] != null)
          {
            switch (M.Items[index].GetType().Name)
            {
              case "MessageBody":
                MessageBody messageBody2 = (MessageBody) M.Items[index];
                if (messageBody2 != null && messageBody2.CustomerInfo != null)
                {
                  bodyCustomerInfoList = ((IEnumerable<MessageBodyCustomerInfo>) messageBody2.CustomerInfo).ToList<MessageBodyCustomerInfo>();
                  continue;
                }
                continue;
              default:
                continue;
            }
          }
        }
      }
      return bodyCustomerInfoList;
    }
  }
}
