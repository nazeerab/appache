﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_COLC_REF_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.DAL;

namespace BackEndLayers.BLL
{
  public class CFCS_COLC_REF_Manager
  {
    public static string Get(string companyCode)
    {
      Status status1 = new Status();
      Status status2 = CFCS_COLC_REF_DB.Get(companyCode, "CFCREF");
      if (status2.Code == "FAILED")
        return string.Empty;
      return status2.Description;
    }
  }
}
