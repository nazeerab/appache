﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.DAL.CFCS_Fin_Bus_Date_DB
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace BackEndLayers.DAL
{
  public class CFCS_Fin_Bus_Date_DB
  {
    public static string Get()
    {
      string empty = string.Empty;
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("CFCS_PKG.GET_FIN_BUS_DATE", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          OracleParameter oracleParameter1 = new OracleParameter("PO_BUS_DATE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter3 = new OracleParameter("PO_RET_DESCR", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          oracleCommand.Parameters.Add(oracleParameter3);
          ((DbConnection) conn).Open();
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            if (((DbParameter) oracleParameter2).Value.ToString().Trim() == "0000")
              return ((DbParameter) oracleParameter1).Value.ToString();
            throw new Exception("Unable to fetch date from CFCS_PKG.GET_FIN_BUS_DATE, return code is," + ((DbParameter) oracleParameter2).Value.ToString());
          }
          catch (Exception ex)
          {
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
    }
  }
}
