﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.InqType
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public enum InqType
  {
    I = 1,
    GS = 2,
    GD = 3,
    G = 4,
    GX = 5,
    SQDET = 6,
    SQSMRY = 7,
  }
}
