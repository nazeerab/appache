﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Transaction
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.ComponentModel;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "Transaction")]
  [Serializable]
  public class Transaction
  {
    private string _tuxMsgIn = string.Empty;
    private string _tuxMsgOut = string.Empty;
    private string _dbFailReason = string.Empty;
    private string _tuxFailReason = string.Empty;
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(DataType = "string", ElementName = "SequenceNumber", IsNullable = false)]
    public string __SequenceNumber;
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(DataType = "string", ElementName = "AckNumber", IsNullable = false)]
    public string __AckNumber;
    [XmlElement(DataType = "string", ElementName = "StatusCode", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __StatusCode;
    [XmlElement(DataType = "string", ElementName = "StatusDetail", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __StatusDetail;
    private bool _isTux;
    private bool _isDb;

    [NotEmptyStringValidator("SequenceNumber should not be empty.")]
    [XmlIgnore]
    public string SequenceNumber
    {
      get
      {
        return this.__SequenceNumber;
      }
      set
      {
        this.__SequenceNumber = value;
      }
    }

    [XmlIgnore]
    public string AckNumber
    {
      get
      {
        return this.__AckNumber;
      }
      set
      {
        this.__AckNumber = value;
      }
    }

    [NotEmptyStringValidator("StatusCode should not be empty.")]
    [XmlIgnore]
    public string StatusCode
    {
      get
      {
        return this.__StatusCode;
      }
      set
      {
        this.__StatusCode = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("StatusDetail should not be empty.")]
    public string StatusDetail
    {
      get
      {
        return this.__StatusDetail;
      }
      set
      {
        this.__StatusDetail = value;
      }
    }

    public string TuxMsgIn
    {
      get
      {
        return this._tuxMsgIn;
      }
      set
      {
        this._tuxMsgIn = value;
      }
    }

    public string TuxMsgOut
    {
      get
      {
        return this._tuxMsgOut;
      }
      set
      {
        this._tuxMsgOut = value;
      }
    }

    public bool IsTux
    {
      get
      {
        return this._isTux;
      }
      set
      {
        this._isTux = value;
      }
    }

    public string DbFailReason
    {
      get
      {
        return this._dbFailReason;
      }
      set
      {
        this._dbFailReason = value;
      }
    }

    public string TuxFailReason
    {
      get
      {
        return this._tuxFailReason;
      }
      set
      {
        this._tuxFailReason = value;
      }
    }

    public bool IsDb
    {
      get
      {
        return this._isDb;
      }
      set
      {
        this._isDb = value;
      }
    }
  }
}
