﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.PayFile
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class PayFile
  {
    private string _path = string.Empty;
    private string _name = string.Empty;
    private string _fileRef = string.Empty;

    public string Path
    {
      get
      {
        return this._path;
      }
      set
      {
        this._path = value;
      }
    }

    public string Name
    {
      get
      {
        return this._name;
      }
      set
      {
        this._name = value;
      }
    }

    public string FileRef
    {
      get
      {
        return this._fileRef;
      }
      set
      {
        this._fileRef = value;
      }
    }
  }
}
