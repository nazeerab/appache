﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Fin_Out_TuxMsg
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class Fin_Out_TuxMsg
  {
    private string _SourceSystem = string.Empty;
    private string _RequestFunction = string.Empty;
    private string _ServerDate = string.Empty;
    private string _ServerTime = string.Empty;
    private string _FTSReference = string.Empty;
    private string _FtsTransFunc = string.Empty;
    private string _CammTranNum = string.Empty;
    private string _NoOfBlocks = string.Empty;
    private string _CurrBlockNo = string.Empty;
    private string _NoOfItems = string.Empty;
    private string _CustomerCode = string.Empty;
    private string _AccountNo = string.Empty;
    private string _InitBranch = string.Empty;
    private string _InitOfficer = string.Empty;
    private string _CardNumber = string.Empty;
    private string _CAMMActionCode = string.Empty;
    private string _LastUpdateDate = string.Empty;
    private string _LastUpdateTime = string.Empty;
    private string _TransactionStatus = string.Empty;
    private string _FTSActionCode = string.Empty;
    private string _ProcessingSeq = string.Empty;
    private string _DetailLength = string.Empty;

    public string SourceSystem
    {
      get
      {
        return this._SourceSystem;
      }
      set
      {
        this._SourceSystem = value;
      }
    }

    public string RequestFunction
    {
      get
      {
        return this._RequestFunction;
      }
      set
      {
        this._RequestFunction = value;
      }
    }

    public string ServerDate
    {
      get
      {
        return this._ServerDate;
      }
      set
      {
        this._ServerDate = value;
      }
    }

    public string ServerTime
    {
      get
      {
        return this._ServerTime;
      }
      set
      {
        this._ServerTime = value;
      }
    }

    public string FTSReference
    {
      get
      {
        return this._FTSReference;
      }
      set
      {
        this._FTSReference = value;
      }
    }

    public string FtsTransFunc
    {
      get
      {
        return this._FtsTransFunc;
      }
      set
      {
        this._FtsTransFunc = value;
      }
    }

    public string CammTranNum
    {
      get
      {
        return this._CammTranNum;
      }
      set
      {
        this._CammTranNum = value;
      }
    }

    public string NoOfBlocks
    {
      get
      {
        return this._NoOfBlocks;
      }
      set
      {
        this._NoOfBlocks = value;
      }
    }

    public string CurrBlockNo
    {
      get
      {
        return this._CurrBlockNo;
      }
      set
      {
        this._CurrBlockNo = value;
      }
    }

    public string NoOfItems
    {
      get
      {
        return this._NoOfItems;
      }
      set
      {
        this._NoOfItems = value;
      }
    }

    public string CustomerCode
    {
      get
      {
        return this._CustomerCode;
      }
      set
      {
        this._CustomerCode = value;
      }
    }

    public string AccountNo
    {
      get
      {
        return this._AccountNo;
      }
      set
      {
        this._AccountNo = value;
      }
    }

    public string InitBranch
    {
      get
      {
        return this._InitBranch;
      }
      set
      {
        this._InitBranch = value;
      }
    }

    public string InitOfficer
    {
      get
      {
        return this._InitOfficer;
      }
      set
      {
        this._InitOfficer = value;
      }
    }

    public string CardNumber
    {
      get
      {
        return this._CardNumber;
      }
      set
      {
        this._CardNumber = value;
      }
    }

    public string CAMMActionCode
    {
      get
      {
        return this._CAMMActionCode;
      }
      set
      {
        this._CAMMActionCode = value;
      }
    }

    public string LastUpdateDate
    {
      get
      {
        return this._LastUpdateDate;
      }
      set
      {
        this._LastUpdateDate = value;
      }
    }

    public string LastUpdateTime
    {
      get
      {
        return this._LastUpdateTime;
      }
      set
      {
        this._LastUpdateTime = value;
      }
    }

    public string TransactionStatus
    {
      get
      {
        return this._TransactionStatus;
      }
      set
      {
        this._TransactionStatus = value;
      }
    }

    public string FTSActionCode
    {
      get
      {
        return this._FTSActionCode;
      }
      set
      {
        this._FTSActionCode = value;
      }
    }

    public string ProcessingSeq
    {
      get
      {
        return this._ProcessingSeq;
      }
      set
      {
        this._ProcessingSeq = value;
      }
    }

    public string DetailLength
    {
      get
      {
        return this._DetailLength;
      }
      set
      {
        this._DetailLength = value;
      }
    }
  }
}
