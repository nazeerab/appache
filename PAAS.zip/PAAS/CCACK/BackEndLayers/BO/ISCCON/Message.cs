﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.Message
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.ISCCON
{
  [XmlRoot(IsNullable = false, Namespace = "")]
  [DesignerCategory("code")]
  [XmlType(AnonymousType = true)]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [Serializable]
  public class Message
  {
    private object[] itemsField;

    [XmlElement("Header", typeof (MessageHeader), Form = XmlSchemaForm.Unqualified)]
    [XmlElement("ResponseStatus", typeof (MessageResponseStatus), Form = XmlSchemaForm.Unqualified)]
    [XmlElement("Body", typeof (MessageBody), Form = XmlSchemaForm.Unqualified)]
    public object[] Items
    {
      get
      {
        return this.itemsField;
      }
      set
      {
        this.itemsField = value;
      }
    }
  }
}
