﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.OSCUSTINV.MessageBodyCustomerInvoiceInvoiceDetail
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.OSCUSTINV
{
  [DesignerCategory("code")]
  [DebuggerStepThrough]
  [XmlType(AnonymousType = true)]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [Serializable]
  public class MessageBodyCustomerInvoiceInvoiceDetail
  {
    private string status;
    private string customerNumberField;
    private string invoiceNumberField;
    private string invoiceDateField;
    private string invoiceCurrencyField;
    private string invoiceAmountField;
    private string equivalentCurrencyField;
    private string equivalentAmountField;
    private string invoiceDueDateField;
    private string remarkField;

    public string Status
    {
      get
      {
        return this.status;
      }
      set
      {
        this.status = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("CustomerNumber should not be empty.")]
    public string CustomerNumber
    {
      get
      {
        return this.customerNumberField;
      }
      set
      {
        this.customerNumberField = value;
      }
    }

    [NotEmptyStringValidator("InvoiceNumber should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceNumber
    {
      get
      {
        return this.invoiceNumberField;
      }
      set
      {
        this.invoiceNumberField = value;
      }
    }

    [NotEmptyStringValidator("InvoiceDate should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceDate
    {
      get
      {
        return this.invoiceDateField;
      }
      set
      {
        this.invoiceDateField = value;
      }
    }

    [LengthValidator("Incorrect Currency length should be in-betwen 1 to 3.", MaxLength = 3, MinLength = 1)]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceCurrency
    {
      get
      {
        return this.invoiceCurrencyField;
      }
      set
      {
        this.invoiceCurrencyField = value;
      }
    }

    [NotEmptyStringValidator("InvoiceAmount should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceAmount
    {
      get
      {
        return this.invoiceAmountField;
      }
      set
      {
        this.invoiceAmountField = value;
      }
    }

    [LengthValidator("Incorrect EquivalentCurrency length should be in-betwen 1 to 3.", MaxLength = 3, MinLength = 1)]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string EquivalentCurrency
    {
      get
      {
        return this.equivalentCurrencyField;
      }
      set
      {
        this.equivalentCurrencyField = value;
      }
    }

    [NotEmptyStringValidator("EquivalentAmount should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string EquivalentAmount
    {
      get
      {
        return this.equivalentAmountField;
      }
      set
      {
        this.equivalentAmountField = value;
      }
    }

    [NotEmptyStringValidator("InvoiceDueDate should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceDueDate
    {
      get
      {
        return this.invoiceDueDateField;
      }
      set
      {
        this.invoiceDueDateField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string Remark
    {
      get
      {
        return this.remarkField;
      }
      set
      {
        this.remarkField = value;
      }
    }
  }
}
