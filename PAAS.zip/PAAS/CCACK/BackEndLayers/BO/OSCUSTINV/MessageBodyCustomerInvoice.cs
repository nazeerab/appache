﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.OSCUSTINV.MessageBodyCustomerInvoice
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C0B2A425-497E-4D4F-889E-066F1674EAE2
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.OSCUSTINV
{
  [XmlType(AnonymousType = true)]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [DesignerCategory("code")]
  [Serializable]
  public class MessageBodyCustomerInvoice
  {
    private string invoiceStatusField;
    private MessageBodyCustomerInvoiceInvoiceDetail[] invoiceDetailField;

    [NotEmptyStringValidator("InvoiceStatus should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string InvoiceStatus
    {
      get
      {
        return this.invoiceStatusField;
      }
      set
      {
        this.invoiceStatusField = value;
      }
    }

    [XmlElement("InvoiceDetail", Form = XmlSchemaForm.Unqualified)]
    public MessageBodyCustomerInvoiceInvoiceDetail[] InvoiceDetail
    {
      get
      {
        return this.invoiceDetailField;
      }
      set
      {
        this.invoiceDetailField = value;
      }
    }
  }
}
