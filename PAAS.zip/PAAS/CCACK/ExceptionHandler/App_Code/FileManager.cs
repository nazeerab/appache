﻿// Decompiled with JetBrains decompiler
// Type: ExceptionHandler.App_Code.FileManager
// Assembly: ExceptionHandler, Version=1.0.0.0, Culture=neutral, PublicKeyToken=0c15d54584087478
// MVID: 5C3E5B5A-7F96-4C3F-B207-DBB70CFB7B69
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\ExceptionHandler.dll

using System;
using System.Configuration;
using System.IO;
using System.Reflection;

namespace ExceptionHandler.App_Code
{
  internal class FileManager
  {
    private static string GetPath()
    {
      string str = ConfigurationManager.AppSettings["path"].ToString();
      switch (str)
      {
        case "Auto":
          return FileManager.NormalPath(Assembly.GetExecutingAssembly().Location.ToString()) + "\\";
        default:
          return str + "\\";
      }
    }

    private static string GetFileExt()
    {
      return ConfigurationManager.AppSettings["fileExt"].ToString();
    }

    private static string NormalPath(string path)
    {
      int startIndex = path.LastIndexOf("\\");
      return path.Remove(startIndex);
    }

    public static bool IsFile(string path)
    {
      return File.Exists(path);
    }

    public static double GetFileSize(string path)
    {
      return Convert.ToDouble(new FileInfo(path).Length);
    }

    public static bool CreateFile(string path)
    {
      if (FileManager.IsFile(path))
        return false;
      using (new FileStream(path, FileMode.CreateNew))
        ;
      return true;
    }

    public static string GetFileName()
    {
      return ConfigurationManager.AppSettings["fileName"].ToString();
    }

    public static string LogFilePath(string BySizeOrDate)
    {
      switch (BySizeOrDate)
      {
        case "Date":
          return FileManager.GetFilePath_ByDate(FileManager.GetPath(), FileManager.GetFileName(), FileManager.GetFileExt());
        default:
          if (FileManager.CreateFile(FileManager.GetPath().ToString() + FileManager.GetFileName().ToString() + FileManager.GetFileExt().ToString()))
            return FileManager.GetPath().ToString() + FileManager.GetFileName().ToString() + FileManager.GetFileExt().ToString();
          return FileManager.GetPath().ToString() + FileManager.GetFileName().ToString() + FileManager.GetFileExt().ToString();
      }
    }

    private static string GetFilePath_ByDate(string path, string fileName, string fileExt)
    {
      fileName = fileName + "_" + DateTime.Now.ToString("dd-MM-yyyy") + fileExt;
      if (!FileManager.IsFile(path + fileName) && !FileManager.CreateFile(path + fileName))
        return "";
      return path + fileName;
    }
  }
}
