﻿// Decompiled with JetBrains decompiler
// Type: ExceptionHandler.App_Code.Logger
// Assembly: ExceptionHandler, Version=1.0.0.0, Culture=neutral, PublicKeyToken=0c15d54584087478
// MVID: 5C3E5B5A-7F96-4C3F-B207-DBB70CFB7B69
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_CCACK\ExceptionHandler.dll

using System;
using System.Configuration;
using System.IO;
using System.Text;

namespace ExceptionHandler.App_Code
{
  public class Logger
  {
    private string physicalPath = "";

    public Logger()
    {
      this.physicalPath = FileManager.LogFilePath(ConfigurationManager.AppSettings["mode"].ToString());
    }

    private string GetLine()
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str = ConfigurationManager.AppSettings["LogLineSymbol"].ToString();
      int int32 = Convert.ToInt32(ConfigurationManager.AppSettings["SymbolCount"].ToString());
      for (int index = 0; index < int32; ++index)
        stringBuilder.Append(str);
      return stringBuilder.ToString();
    }

    private string GetLine(string heading)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str = ConfigurationManager.AppSettings["LogLineSymbol"].ToString();
      int num = Convert.ToInt32(ConfigurationManager.AppSettings["SymbolCount"].ToString()) / 2;
      for (int index = 0; index < num; ++index)
        stringBuilder.Append(str);
      stringBuilder.Append(heading);
      for (int index = 0; index < num; ++index)
        stringBuilder.Append(str);
      return stringBuilder.ToString();
    }

    public void LogIt(Exception ex)
    {
      this.physicalPath = FileManager.LogFilePath(ConfigurationManager.AppSettings["mode"].ToString());
      using (StreamWriter streamWriter = File.AppendText(this.physicalPath))
      {
        streamWriter.WriteLine(this.GetLine("EXCEPTION STARTED AT " + DateTime.Now.ToString()));
        streamWriter.WriteLine(ex.Message);
        if (ex.StackTrace != null)
        {
          streamWriter.WriteLine(this.GetLine("STACK TRACE"));
          streamWriter.WriteLine(ex.StackTrace);
        }
        if (ex.Source != null)
        {
          streamWriter.WriteLine(this.GetLine("SOURCE"));
          streamWriter.WriteLine(ex.Source);
        }
        if (ex.InnerException != null)
        {
          streamWriter.WriteLine(this.GetLine("INNER EXCEPTION"));
          streamWriter.WriteLine(ex.InnerException.ToString());
        }
        if (ex.GetBaseException() != null)
        {
          streamWriter.WriteLine(this.GetLine("BASE EXCEPTION"));
          streamWriter.WriteLine(ex.GetBaseException().ToString());
        }
        streamWriter.WriteLine(this.GetLine("END"));
      }
    }

    public void LogIt(string msg)
    {
      using (StreamWriter streamWriter = File.AppendText(this.physicalPath))
      {
        if (msg == null)
          return;
        streamWriter.WriteLine(this.GetLine("LOGGING STARTED AT " + DateTime.Now.ToString()));
        streamWriter.WriteLine(msg);
        streamWriter.WriteLine(this.GetLine("END"));
      }
    }

    public string ShowPath()
    {
      return this.physicalPath;
    }
  }
}
