﻿// Decompiled with JetBrains decompiler
// Type: OSCUSTINV.Program
// Assembly: OSCUSTINV, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 801D87E8-0A60-4BEE-9320-00F8BE16918E
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV\OSCUSTINV.exe

using BackEndLayers.BLL;
using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSTINV;
using BackEndLayers.Log;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OSCUSTINV
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      DateTime now = DateTime.Now;
      Reports reports = new Reports();
      List<MessageBodyCustomerInvoiceInvoiceDetail> Valid_Details = new List<MessageBodyCustomerInvoiceInvoiceDetail>();
      CFCS_INVOICE_LOG_List cfcsInvoiceLogList = new CFCS_INVOICE_LOG_List();
      LogInvoice logInvoice = new LogInvoice();
      Message message = new Message();
      bool isValid = false;
      string fileName = "";
      bool flag = true;
      Console.WriteLine("Process OSCUSTINV is started.");
      try
      {
        string companyCode = args[0];
        Console.WriteLine("Company Code: " + companyCode);
        string str = args[1];
        Console.WriteLine("File path: " + str);
        fileName = Util.GetFileName(str);
        Console.WriteLine("File name: " + fileName);
        Console.WriteLine("Parsing message.");
        Message Msg = OSCUSTINV_Manager.XMLtoOSCUSTINV(str);
        Console.WriteLine("Parsing message done.");
        Console.WriteLine("Runing validation on message.");
        Reports R = OSCUSTINVValidation_Manager.MessageValidation(Msg, fileName, out Valid_Details, companyCode, out isValid);
        Console.WriteLine("Validation on message done.");
        switch (isValid)
        {
          case false:
            Console.WriteLine("Invalid xml file, please check logs");
            Console.WriteLine(Util.PrintReport(R));
            Console.WriteLine("Logging files.");
            logInvoice.Log(Util.PrintReport(R), fileName, Eventtype.informaton);
            Console.WriteLine("Logging Complete.");
            break;
          case true:
            Console.WriteLine("Validation done and message parsed successfully.");
            CFCS_INVOICE_LOG_List invoices = CFCS_INVOICE_LOG_Manager.GetInvoices(Valid_Details, companyCode);
            CFCS_INVOICE_LOG_Manager.Save(invoices, fileName);
            Console.WriteLine(invoices.Count<CFCS_INVOICE_LOG>().ToString() + " Invoice(s) proccess Successfully.");
            Console.WriteLine(Util.PrintReport(R));
            Console.WriteLine("Logging file.");
            logInvoice.Log(Util.PrintReport(R), fileName, Eventtype.informaton);
            Console.WriteLine("Logging Complete.");
            break;
        }
      }
      catch (IndexOutOfRangeException ex)
      {
        logInvoice.Log((Exception) ex, fileName, Eventtype.Error);
        Console.WriteLine("Please provide compnay code as args[0] and path as args[1]");
        flag = false;
      }
      catch (Exception ex)
      {
        logInvoice.Log(ex, fileName, Eventtype.Error);
        Console.WriteLine("Application terminated unsuccessfully, please check logs for detail.");
        flag = false;
      }
      if (flag)
        Console.WriteLine("Process end with Success.");
      else
        Console.WriteLine("Process end with Failure.");
      Console.WriteLine("Process tooks " + (DateTime.Now - now).Milliseconds.ToString() + " MS to compelete.");
    }
  }
}
