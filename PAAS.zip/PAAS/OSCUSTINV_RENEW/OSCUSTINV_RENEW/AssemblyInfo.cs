﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("OSCUSTINV_RENEW")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("OSCUSTINV_RENEW")]
[assembly: AssemblyCopyright("Copyright © BSF 2012")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("7cdb43ce-3f6c-413a-875d-ca79d4651423")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
