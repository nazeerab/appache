﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.LogInvoice
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BackEndLayers.Log
{
  public class LogInvoice : Logs
  {
    public void Log(
      CFCS_INVOICE_LOG_List Invoices,
      string invoiceStatus,
      string fileName,
      string[] sucess_Status)
    {
      StringBuilder stringBuilder = new StringBuilder();
      int num1 = 0;
      int num2 = 0;
      stringBuilder.Append("Process: OSCUSTINV");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Invoice Status: " + invoiceStatus);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Invoices: " + Invoices.Count<CFCS_INVOICE_LOG>().ToString());
      stringBuilder.Append(Environment.NewLine);
      for (int index = 0; index < Invoices.Count<CFCS_INVOICE_LOG>(); ++index)
      {
        stringBuilder.Append("Invoice Sequence: " + (index + 1).ToString());
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("Invoice Number: " + Invoices[index].INV_NO.ToString().Trim());
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("Status_Db: " + sucess_Status[index]);
        stringBuilder.Append(Environment.NewLine);
      }
      for (int index = 0; index < ((IEnumerable<string>) sucess_Status).Count<string>(); ++index)
      {
        if (sucess_Status[index] != null)
        {
          if (sucess_Status[index].Trim().ToLower() == "failed")
            ++num2;
          else
            ++num1;
        }
      }
      stringBuilder.Append("OverAll Success: " + num1.ToString() + " / Failed: " + num2.ToString());
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), Eventtype.informaton);
    }

    public void Log(string str, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: OSCUSTINV");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(str);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }

    public void Log(Exception ex, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: OSCUSTINV");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Exception:  " + (object) ex);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }
  }
}
