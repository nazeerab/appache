﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.Logs
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using ExceptionHandler;
using System;

namespace BackEndLayers.Log
{
  public class Logs
  {
    public void Log(Exception ex)
    {
      Loger.Log(ex);
    }

    public void Log(string str)
    {
      Loger.Log(str);
    }
  }
}
