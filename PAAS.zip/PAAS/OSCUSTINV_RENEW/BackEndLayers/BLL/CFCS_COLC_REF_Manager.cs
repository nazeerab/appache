﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_COLC_REF_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.DAL;

namespace BackEndLayers.BLL
{
  public class CFCS_COLC_REF_Manager
  {
    public static string Get(string companyCode)
    {
      Status status1 = new Status();
      Status status2 = CFCS_COLC_REF_DB.Get(companyCode, "CFCREF");
      if (status2.Code == "FAILED")
        return string.Empty;
      return status2.Description;
    }
  }
}
