﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_COMPANY_PROFILE_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.DAL;

namespace BackEndLayers.BLL
{
  public class CFCS_COMPANY_PROFILE_Manager
  {
    public static CFCS_COMPANY_PROFILE_List Get(
      string companyCode,
      string type)
    {
      return CFCS_COMPANY_PROFILE_DB.GetList(companyCode, type);
    }

    public static CFCS_COMPANY_PROFILE Item(string companyCode, string type)
    {
      return CFCS_COMPANY_PROFILE_DB.Item(companyCode, type);
    }
  }
}
