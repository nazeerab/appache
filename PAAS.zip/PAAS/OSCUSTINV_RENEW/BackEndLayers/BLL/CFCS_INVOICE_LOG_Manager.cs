﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_INVOICE_LOG_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSTINV;
using BackEndLayers.DAL;
using BackEndLayers.Log;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BackEndLayers.BLL
{
  public static class CFCS_INVOICE_LOG_Manager
  {
    public static Status Save(CFCS_INVOICE_LOG Invoice)
    {
      return CFCS_INVOICE_LOG_DB.Save(Invoice);
    }

    public static CFCS_INVOICE_LOG_List GetInvoices(
      List<MessageBodyCustomerInvoiceInvoiceDetail> InvDetail,
      string companyCode)
    {
      CFCS_INVOICE_LOG cfcsInvoiceLog = new CFCS_INVOICE_LOG();
      CFCS_INVOICE_LOG_List cfcsInvoiceLogList = new CFCS_INVOICE_LOG_List();
      for (int index = 0; index < InvDetail.Count<MessageBodyCustomerInvoiceInvoiceDetail>(); ++index)
        cfcsInvoiceLogList.Add(new CFCS_INVOICE_LOG()
        {
          COMP_CODE = companyCode,
          CUSTOMER_ID = InvDetail[index].CustomerNumber,
          INV_NO = InvDetail[index].InvoiceNumber,
          INV_DATE = Convert.ToDateTime(InvDetail[index].InvoiceDate),
          CRNCY_CODE = InvDetail[index].InvoiceCurrency,
          AMOUNT = Convert.ToDouble(InvDetail[index].InvoiceAmount),
          EQUIVALENT_CRNCY = InvDetail[index].EquivalentCurrency,
          EQUIVALENT_AMOUNT = Convert.ToDouble(InvDetail[index].EquivalentAmount),
          DUE_DATE = Convert.ToDateTime(InvDetail[index].InvoiceDueDate),
          REMARKS = InvDetail[index].Remark,
          STATUS = InvDetail[index].Status
        });
      return cfcsInvoiceLogList;
    }

    public static CFCS_INVOICE_LOG_List GetInvoices(
      Message Msg,
      string companyCode)
    {
      CFCS_INVOICE_LOG cfcsInvoiceLog = new CFCS_INVOICE_LOG();
      CFCS_INVOICE_LOG_List cfcsInvoiceLogList = new CFCS_INVOICE_LOG_List();
      MessageBody messageBody1 = new MessageBody();
      MessageHeader messageHeader = new MessageHeader();
      OSCUSTINV_Manager.GetMessageHeader(Msg);
      MessageBody messageBody2 = OSCUSTINV_Manager.GetMessageBody(Msg);
      int num1 = ((IEnumerable<MessageBodyCustomerInvoice>) messageBody2.CustomerInvoice).Count<MessageBodyCustomerInvoice>();
      string empty = string.Empty;
      for (int index1 = 0; index1 < num1; ++index1)
      {
        int num2 = ((IEnumerable<MessageBodyCustomerInvoiceInvoiceDetail>) messageBody2.CustomerInvoice[index1].InvoiceDetail).Count<MessageBodyCustomerInvoiceInvoiceDetail>();
        string str = messageBody2.CustomerInvoice[index1].InvoiceStatus.ToString().Trim();
        for (int index2 = 0; index2 < num2; ++index2)
          cfcsInvoiceLogList.Add(new CFCS_INVOICE_LOG()
          {
            COMP_CODE = companyCode,
            CUSTOMER_ID = messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].CustomerNumber,
            INV_NO = messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].InvoiceNumber,
            INV_DATE = Convert.ToDateTime(messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].InvoiceDate),
            CRNCY_CODE = messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].InvoiceCurrency,
            AMOUNT = Convert.ToDouble(messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].InvoiceAmount),
            EQUIVALENT_CRNCY = messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].EquivalentCurrency,
            EQUIVALENT_AMOUNT = Convert.ToDouble(messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].EquivalentAmount),
            DUE_DATE = Convert.ToDateTime(messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].InvoiceDueDate),
            REMARKS = messageBody2.CustomerInvoice[index1].InvoiceDetail[index2].Remark,
            STATUS = str
          });
      }
      return cfcsInvoiceLogList;
    }

    public static Status Save(CFCS_INVOICE_LOG_List Invoices, string fileName)
    {
      Status status1 = new Status();
      Status status2 = new Status();
      string[] sucess_Status = new string[Invoices.Count<CFCS_INVOICE_LOG>()];
      LogInvoice logInvoice = new LogInvoice();
      string invoiceStatus = "";
      for (int index = 0; index < Invoices.Count<CFCS_INVOICE_LOG>(); ++index)
      {
        try
        {
          invoiceStatus = Invoices[index].STATUS;
          Status status3 = CFCS_INVOICE_LOG_Manager.Save(Invoices[index]);
          sucess_Status[index] = !(status3.Code != "0000") ? "OK" : "FAILED | " + status3.Code + " | " + status3.Description;
        }
        catch (Exception ex)
        {
          status1.Code = "FAILED";
          status1.Code = ex.Message;
          logInvoice.Log(ex, fileName, Eventtype.Error);
        }
      }
      logInvoice.Log(Invoices, invoiceStatus, fileName, sucess_Status);
      status1.Code = "OK";
      status1.Description = "OK";
      return status1;
    }
  }
}
