﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.Tuxedo_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using System;
using System.Configuration;
using System.Text;

namespace BackEndLayers.BLL
{
  public class Tuxedo_Manager
  {
    private static string GetSpaces(int length)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < length; ++index)
        stringBuilder.Append(" ");
      return stringBuilder.ToString();
    }

    private static string GetConfig(string attrib)
    {
      return ConfigurationManager.AppSettings[attrib].ToString().Trim();
    }

    public static string TuxMsgIn(
      string ftsRef,
      string bsfCfcRef,
      string aramcoRef,
      string companyCode,
      string status,
      string bDate)
    {
      Fin_In_TuxMsg finInTuxMsg = new Fin_In_TuxMsg();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog1 = new CFCS_PAYMENTS_LOG();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog2 = new CFCS_PAYMENTS_LOG();
      StringBuilder stringBuilder1 = new StringBuilder();
      CFCS_PAYMENTS_LOG cfcsPaymentsLog3 = CFCS_PAYMENTS_LOG_Manager.GetItem(companyCode, bsfCfcRef, PaymentStatus.CONF, InqType.SQDET);
      CFCS_PAYMENTS_LOG cfcsPaymentsLog4 = CFCS_PAYMENTS_LOG_Manager.GetItem(companyCode, bsfCfcRef, PaymentStatus.CONF, InqType.SQSMRY);
      finInTuxMsg.SourceSystem = Tuxedo_Manager.GetConfig("SourceSystem");
      finInTuxMsg.RequestFunction = "FINUPD04";
      finInTuxMsg.ServerDate = DateTime.Now.ToString("yyyyMMdd");
      finInTuxMsg.ServerTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg.FTSReferece = ftsRef.PadRight(10, ' ');
      finInTuxMsg.FTSTransFunc = Tuxedo_Manager.GetSpaces(10);
      finInTuxMsg.CammTranNum = "000000";
      finInTuxMsg.NoOfBlocks = "1".PadLeft(3, '0');
      finInTuxMsg.CurrBlockNo = "1".PadLeft(3, '0');
      finInTuxMsg.NoOfItems = "1".PadLeft(3, '0');
      finInTuxMsg.CustomerCode = Tuxedo_Manager.GetSpaces(10);
      finInTuxMsg.AccountNo = Tuxedo_Manager.GetSpaces(20);
      finInTuxMsg.InitBranch = Tuxedo_Manager.GetConfig("InitBranch").PadRight(6, ' ');
      finInTuxMsg.InitOfficer = Tuxedo_Manager.GetConfig("InitOfficer").PadRight(9, ' ');
      finInTuxMsg.CardNumber = Tuxedo_Manager.GetSpaces(23);
      finInTuxMsg.CAMMActionCode = "5555";
      finInTuxMsg.LastUpdateDate = DateTime.Now.ToString("yyyyMMdd");
      finInTuxMsg.LastUpdateTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg.TransactionStatus = "NOR";
      finInTuxMsg.FTSActionCode = "6666";
      finInTuxMsg.ProcessingSeq = "1".PadLeft(3, '0');
      finInTuxMsg.DetailLength = "529".PadLeft(4, '0');
      if (status.Trim().ToLower() == "ok")
        finInTuxMsg.TransType = Tuxedo_Manager.GetConfig("ok_Status");
      else if (status.Trim().ToLower() == "de")
        finInTuxMsg.TransType = Tuxedo_Manager.GetConfig("de_Status");
      finInTuxMsg.TransDate = bDate;
      finInTuxMsg.ValueDate = bDate;
      finInTuxMsg.TransCrncy = cfcsPaymentsLog3.CREDT_ACCT_CRNCY.PadRight(3, ' ');
      finInTuxMsg.TransAmount = cfcsPaymentsLog4.TOTAL_INV_AMOUNT.ToString().PadLeft(16, '0');
      finInTuxMsg.TransAmountSar = (cfcsPaymentsLog4.TOTAL_INV_AMOUNT + 1.0).ToString().PadLeft(16, '0');
      if (status.Trim().ToLower() == "ok")
      {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.Append("AR");
        stringBuilder2.Append(" ");
        stringBuilder2.Append("ACK#");
        stringBuilder2.Append(aramcoRef);
        stringBuilder2.Append(" ");
        stringBuilder2.Append(bsfCfcRef);
        stringBuilder2.Append(" ");
        finInTuxMsg.GenNarrative = stringBuilder2.ToString().PadRight(40, ' ');
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.Append(finInTuxMsg.GenNarrative);
        stringBuilder3.Append(cfcsPaymentsLog3.CUSTOMER_ID.PadRight(20, ' '));
        finInTuxMsg.GenNarrative = stringBuilder3.ToString();
      }
      else if (status.Trim().ToLower() == "de")
      {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.Append("Cust ID#");
        stringBuilder2.Append(cfcsPaymentsLog3.CUSTOMER_ID);
        stringBuilder2.Append(" ");
        stringBuilder2.Append(cfcsPaymentsLog4.PAY_TXN_REFERENCE);
        stringBuilder2.Append(" ");
        stringBuilder2.Append("de BY CO.");
        finInTuxMsg.GenNarrative = stringBuilder2.ToString().PadRight(60, ' ');
      }
      finInTuxMsg.ScrNarrative = Tuxedo_Manager.GetSpaces(20);
      if (status.Trim().ToLower() == "de" || status.Trim().ToLower() == "ok")
      {
        finInTuxMsg.DebitAcctNo = cfcsPaymentsLog3.CREDT_ACCT_NO.PadLeft(20, '0');
        finInTuxMsg.DebitAcctCrncy = cfcsPaymentsLog3.CREDT_ACCT_CRNCY.PadRight(3, ' ');
        finInTuxMsg.DebitAmount = cfcsPaymentsLog4.TOTAL_INV_AMOUNT.ToString().PadLeft(16, '0');
      }
      finInTuxMsg.DebitCrncyRate = "00.000000";
      finInTuxMsg.DebitValueDate = bDate;
      finInTuxMsg.DebitSrfFlag = "N";
      finInTuxMsg.DebitBranch = Tuxedo_Manager.GetSpaces(6);
      if (status.Trim().ToLower() == "ok")
      {
        finInTuxMsg.CreditAcctNo = cfcsPaymentsLog3.COLLCT_ACCT_NO.PadLeft(20, '0');
        finInTuxMsg.CreditAcctCrncy = cfcsPaymentsLog3.CREDT_ACCT_CRNCY.PadRight(3, ' ');
      }
      else if (status.Trim().ToLower() == "de")
      {
        finInTuxMsg.CreditAcctNo = cfcsPaymentsLog3.DEBIT_ACCT_NO.PadLeft(20, '0');
        finInTuxMsg.CreditAcctCrncy = cfcsPaymentsLog3.DEBIT_ACCT_CRNCY.PadRight(3, ' ');
      }
      finInTuxMsg.CreditAmount = cfcsPaymentsLog4.TOTAL_INV_AMOUNT.ToString().PadLeft(16, '0');
      finInTuxMsg.CreditCrncyRate = "000.00000";
      finInTuxMsg.CreditValueDate = bDate;
      finInTuxMsg.CreditSrfFlag = Tuxedo_Manager.GetSpaces(1);
      finInTuxMsg.CreditBranch = Tuxedo_Manager.GetSpaces(6);
      finInTuxMsg.CommissionCrncy = Tuxedo_Manager.GetSpaces(3);
      finInTuxMsg.CommissionAmount = Tuxedo_Manager.GetSpaces(16);
      finInTuxMsg.CommissionAcct = "00000000000000000000";
      finInTuxMsg.ChargesCrncy = Tuxedo_Manager.GetSpaces(3);
      finInTuxMsg.ChargesAmount = "0000000000000.00";
      finInTuxMsg.ChargesAcct = "00000000000000000000";
      finInTuxMsg.GtdDealTicket = Tuxedo_Manager.GetSpaces(20);
      finInTuxMsg.InitTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg.ValidationOfficer = Tuxedo_Manager.GetConfig("ValidationOfficer").PadRight(9, ' ');
      finInTuxMsg.ValidationTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg.AuthorznOfficer = Tuxedo_Manager.GetConfig("AuthorznOfficer").PadRight(9, ' ');
      finInTuxMsg.AuthorznTime = DateTime.Now.ToString("HHmmss");
      finInTuxMsg.AuthorznReason = Tuxedo_Manager.GetSpaces(10);
      finInTuxMsg.AuthorznStatus = Tuxedo_Manager.GetSpaces(6);
      finInTuxMsg.DynamicPartLen = "000";
      finInTuxMsg.StaticPart_ChequeNo = Tuxedo_Manager.GetSpaces(15);
      finInTuxMsg.StaticPart_Id_Type = Tuxedo_Manager.GetSpaces(6);
      finInTuxMsg.StaticPart_Id_Number = Tuxedo_Manager.GetSpaces(20);
      finInTuxMsg.StaticPart_PrintDetail = Tuxedo_Manager.GetSpaces(1);
      finInTuxMsg.StaticPart_MailAdvice = Tuxedo_Manager.GetSpaces(1);
      finInTuxMsg.CompanyCustomerId = cfcsPaymentsLog3.CUSTOMER_ID.PadRight(20, ' ');
      finInTuxMsg.CompanyCode = companyCode.PadRight(3, ' ');
      finInTuxMsg.InvoiceNumber = cfcsPaymentsLog3.INV_NO.PadRight(20, ' ');
      finInTuxMsg.InvoiceDate = cfcsPaymentsLog3.INV_DATE.ToString("yyyyMMdd");
      finInTuxMsg.PaymentsType = cfcsPaymentsLog4.PAY_TYPE.PadRight(3, ' ');
      finInTuxMsg.ChannelPaymentReference = cfcsPaymentsLog4.PAY_TXN_REFERENCE.PadRight(15, ' ');
      finInTuxMsg.CustomerDebitAcct = cfcsPaymentsLog3.DEBIT_ACCT_NO.PadLeft(20, '0');
      if (status.Trim().ToLower() == "ok")
        finInTuxMsg.CompanyAckType = "A".PadRight(3, ' ');
      else if (status.Trim().ToLower() == "de")
        finInTuxMsg.CompanyAckType = "R".PadRight(3, ' ');
      return finInTuxMsg.print();
    }

    public static Fin_Out_TuxMsg TuxMsgOut(string tuxMsg)
    {
      char[] charArray = tuxMsg.ToCharArray();
      Fin_Out_TuxMsg finOutTuxMsg = new Fin_Out_TuxMsg();
      string empty1 = string.Empty;
      try
      {
        if (charArray.Length != 0)
        {
          string empty2 = string.Empty;
          for (int index = 25; index <= 34; ++index)
            empty2 += charArray[index].ToString();
          finOutTuxMsg.FTSReference = empty2;
          string empty3 = string.Empty;
          for (int index = 128; index <= 131; ++index)
            empty3 += charArray[index].ToString();
          finOutTuxMsg.CAMMActionCode = empty3;
          string empty4 = string.Empty;
          for (int index = 149; index <= 152; ++index)
            empty4 += charArray[index].ToString();
          finOutTuxMsg.FTSActionCode = empty4;
        }
        else
        {
          finOutTuxMsg.CAMMActionCode = "9999";
          finOutTuxMsg.FTSActionCode = "9999";
        }
      }
      catch (Exception ex)
      {
        finOutTuxMsg.CAMMActionCode = "9999";
        finOutTuxMsg.FTSActionCode = "9999";
      }
      return finOutTuxMsg;
    }

    public static Fin_Out_TuxMsg Tuxedo(string msg, out string reply)
    {
      string tuxMsg = string.Empty;
      Fin_Out_TuxMsg finOutTuxMsg = new Fin_Out_TuxMsg();
      TuxedoConnector tuxedoConnector = new TuxedoConnector(ConfigurationManager.AppSettings["TuxServer"], Convert.ToInt32(ConfigurationManager.AppSettings["TuxPort"].ToString()));
      try
      {
        tuxMsg = tuxedoConnector.SendReceiveMessage(msg);
        reply = tuxMsg;
        return Tuxedo_Manager.TuxMsgOut(tuxMsg);
      }
      catch (Exception ex)
      {
        reply = ex.Message;
        return Tuxedo_Manager.TuxMsgOut(tuxMsg);
      }
    }
  }
}
