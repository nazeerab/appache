﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.TuxedoConnector
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace BackEndLayers.BLL
{
  public class TuxedoConnector
  {
    private string server;
    private int port;
    private Socket Sockt;

    public TuxedoConnector(string inServer, int inPort)
    {
      this.server = inServer;
      this.port = inPort;
      this.connectSocket();
    }

    public TuxedoConnector(string inServer, string inPort)
    {
      this.server = inServer;
      this.port = Convert.ToInt32(inPort);
      this.connectSocket();
    }

    public void connectSocket()
    {
      this.Sockt = (Socket) null;
      try
      {
        foreach (IPAddress address in Dns.GetHostEntry(this.server).AddressList)
        {
          IPEndPoint ipEndPoint = new IPEndPoint(address, this.port);
          Socket socket = new Socket(ipEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
          socket.Connect((EndPoint) ipEndPoint);
          if (socket.Connected)
          {
            this.Sockt = socket;
            break;
          }
        }
      }
      catch (Exception ex)
      {
        throw new Exception(ex.Message);
      }
    }

    public void CloseSocket()
    {
      this.Sockt.Close();
    }

    public string SendReceiveMessage(string msg)
    {
      Encoding encoding = Encoding.Default;
      string str1 = msg;
      string s = str1.Length.ToString().PadLeft(4, '0') + str1;
      byte[] bytes = encoding.GetBytes(s);
      byte[] numArray = new byte[10240];
      string str2 = " ";
      try
      {
        if (!this.Sockt.Connected)
          this.connectSocket();
        this.Sockt.Send(bytes, bytes.Length, SocketFlags.None);
        int count = this.Sockt.Receive(numArray, numArray.Length, SocketFlags.None);
        str2 = encoding.GetString(numArray, 0, count);
        str2 = str2.PadRight(164, ' ');
        str2 = str2.Remove(0, 4);
      }
      catch (Exception ex)
      {
      }
      if (this.Sockt.Connected)
        this.CloseSocket();
      return str2;
    }
  }
}
