﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_PAYMENTS_LOG_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.DAL;

namespace BackEndLayers.BLL
{
  public class CFCS_PAYMENTS_LOG_Manager
  {
    public static CFCS_PAYMENTS_LOG_List Get(
      string companyCode,
      string txnRef,
      PaymentStatus S,
      InqType T)
    {
      return CFCS_PAYMENTS_LOG_DB.GetList(companyCode, S.ToString(), T.ToString(), txnRef);
    }

    public static CFCS_PAYMENTS_LOG GetItem(
      string companyCode,
      string txnRef,
      PaymentStatus S,
      InqType T)
    {
      return CFCS_PAYMENTS_LOG_DB.GetItem(companyCode, S.ToString(), T.ToString(), txnRef);
    }

    public static CFCS_PAYMENTS_LOG_List GetReadyFTP(PaymentStatus S)
    {
      return CFCS_PAYMENTS_LOG_DB.GetList_ReadyFTP(S.ToString());
    }

    public static Status Save(CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG, UpdateType T)
    {
      return CFCS_PAYMENTS_LOG_DB.Save(myCFCS_PAYMENTS_LOG, T.ToString());
    }

    public static Status Save(CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG)
    {
      return CFCS_PAYMENTS_LOG_DB.Save(myCFCS_PAYMENTS_LOG);
    }

    public static Status SavePayment(CFCS_PAYMENTS_LOG myCFCS_PAYMENTS_LOG)
    {
      return CFCS_PAYMENTS_LOG_DB.SavePayment(myCFCS_PAYMENTS_LOG);
    }
  }
}
