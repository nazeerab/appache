﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.Util
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.DAL;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace BackEndLayers.BLL
{
  public static class Util
  {
    public static string PrintReport(Reports R)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < R.Count<Report>(); ++index)
      {
        stringBuilder.Append("------" + (index + 1).ToString() + "------");
        stringBuilder.Append("\r\n");
        stringBuilder.Append(R[index].Detail);
        stringBuilder.Append("\r\n");
        stringBuilder.Append(R[index].Code);
        stringBuilder.Append("\r\n");
        stringBuilder.Append("--------------");
        stringBuilder.Append("\r\n");
      }
      return stringBuilder.ToString();
    }

    public static T DeserializeFromXml<T>(string xml)
    {
      using (TextReader textReader = (TextReader) new StringReader(xml))
        return (T) new XmlSerializer(typeof (T)).Deserialize(textReader);
    }

    public static string SerializeToFile<T>(T obj)
    {
      Stream stream = (Stream) new MemoryStream();
      new XmlSerializer(typeof (T)).Serialize(stream, (object) obj);
      return new StreamReader(stream)
      {
        BaseStream = {
          Position = 0L
        }
      }.ReadToEnd();
    }

    public static string RemoveCRLF(string txt)
    {
      if (txt.Contains("\r\n"))
        txt = txt.Replace("\r\n", " ");
      else if (txt.Contains("\n"))
        txt = txt.Replace("\n", " ");
      return txt;
    }

    public static string RemoveNamespace(string xmlData, string rootTag)
    {
      StringBuilder stringBuilder = new StringBuilder();
      int num = 0;
      stringBuilder.Append("<?xml version=\"1.0\"?>");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(rootTag + Environment.NewLine);
      using (StringReader stringReader = new StringReader(xmlData))
      {
        string str;
        while ((str = stringReader.ReadLine()) != null)
        {
          if (num > 1)
          {
            stringBuilder.Append(str);
            stringBuilder.Append(Environment.NewLine);
          }
          ++num;
        }
      }
      return stringBuilder.ToString();
    }

    public static string ReadFile(string path)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (!File.Exists(path))
        throw new Exception("File dose not exists. Verify path,[ " + path + " ]");
      using (StreamReader streamReader = File.OpenText(path))
      {
        try
        {
          if (streamReader != null)
            stringBuilder.Append(streamReader.ReadToEnd());
        }
        catch (Exception ex)
        {
          throw ex;
        }
      }
      return stringBuilder.ToString();
    }

    public static string GetFileName(string filePath)
    {
      if (File.Exists(filePath))
        return Path.GetFileName(filePath);
      return "";
    }

    public static string GetDateFormat()
    {
      return "yyyy-MM-dd";
    }

    public static string GetTimeStamp()
    {
      return DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
    }

    public static bool WriteFile(string msg, string fileName)
    {
      string path = ConfigurationManager.AppSettings["PathOfFile"] + "\\" + fileName + ".xml";
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(path))
        {
          if (msg != null)
            streamWriter.Write(msg);
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return true;
    }

    public static string GetRef(string str)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(str);
      stringBuilder.Append(DateTime.Now.ToString("dd"));
      stringBuilder.Append(DateTime.Now.ToString("MM"));
      stringBuilder.Append(DateTime.Now.ToString("HH"));
      stringBuilder.Append(DateTime.Now.ToString("mm"));
      stringBuilder.Append(DateTime.Now.ToString("ff"));
      return stringBuilder.ToString();
    }

    public static string MessageParametersInvalid(string fileName)
    {
      string parametersInvalid = Codes.MessageParametersInvalid;
      int length = parametersInvalid.IndexOf("[");
      int num = parametersInvalid.IndexOf("]");
      parametersInvalid.Substring(0, length);
      string str = parametersInvalid.Substring(num + 1, parametersInvalid.Length - (num + 1));
      return fileName + " " + str;
    }

    public static string XMLMessageParametersMissing(string fileName)
    {
      string parametersMissing = Codes.XMLMessageParametersMissing;
      int length = parametersMissing.IndexOf("[");
      int num = parametersMissing.IndexOf("]");
      string str1 = parametersMissing.Substring(0, length);
      string str2 = parametersMissing.Substring(num + 1, parametersMissing.Length - (num + 1));
      return fileName + " " + str1 + " " + str2;
    }

    public static DateTime GetBusinessDate()
    {
      DateTime dateTime = new DateTime();
      string s = "";
      try
      {
        s = CFCS_Fin_Bus_Date_DB.Get();
        return DateTime.ParseExact(s, "yyyyMMdd", (IFormatProvider) null);
      }
      catch (Exception ex)
      {
        throw new Exception("Unable to parse business date as, " + s + ", to yyyyMMdd", ex);
      }
    }

    public static bool WriteDscpncyFile(string msg, string fileName)
    {
      string path = ConfigurationManager.AppSettings["PathOfDiscFile"] + "\\" + fileName;
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(path, true))
        {
          if (msg != null)
            streamWriter.WriteLine(msg);
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return true;
    }
  }
}
