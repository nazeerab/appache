﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Codes
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace BackEndLayers
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Codes
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Codes()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Codes.resourceMan == null)
          Codes.resourceMan = new ResourceManager("BackEndLayers.Codes", typeof (Codes).Assembly);
        return Codes.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return Codes.resourceCulture;
      }
      set
      {
        Codes.resourceCulture = value;
      }
    }

    internal static string BankID
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (BankID), Codes.resourceCulture);
      }
    }

    internal static string CompanyCode
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (CompanyCode), Codes.resourceCulture);
      }
    }

    internal static string MessageParametersInvalid
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (MessageParametersInvalid), Codes.resourceCulture);
      }
    }

    internal static string MessageType
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (MessageType), Codes.resourceCulture);
      }
    }

    internal static string Sender
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (Sender), Codes.resourceCulture);
      }
    }

    internal static string StatusCode
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (StatusCode), Codes.resourceCulture);
      }
    }

    internal static string StatusDetail
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (StatusDetail), Codes.resourceCulture);
      }
    }

    internal static string XMLMessageParametersMissing
    {
      get
      {
        return Codes.ResourceManager.GetString(nameof (XMLMessageParametersMissing), Codes.resourceCulture);
      }
    }
  }
}
