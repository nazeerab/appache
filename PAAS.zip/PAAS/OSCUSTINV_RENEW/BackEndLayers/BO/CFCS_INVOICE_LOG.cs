﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CFCS_INVOICE_LOG
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;

namespace BackEndLayers.BO
{
  public class CFCS_INVOICE_LOG
  {
    private string _COMP_CODE = string.Empty;
    private string _INV_NO = string.Empty;
    private string _CUSTOMER_ID = string.Empty;
    private string _CRNCY_CODE = string.Empty;
    private string _STATUS = string.Empty;
    private string _CREATED_BY = string.Empty;
    private string _UPDATED_BY = string.Empty;
    private string _EQUIVALENT_CRNCY = string.Empty;
    private string _REMARKS = string.Empty;
    private DateTime _INV_DATE;
    private double _AMOUNT;
    private DateTime _DUE_DATE;
    private DateTime _CREATED_DATE;
    private DateTime _UPDATED_DATE;
    private double _EQUIVALENT_AMOUNT;

    public CFCS_INVOICE_LOG()
    {
      this._INV_DATE = DateTime.Now.Date;
      this._DUE_DATE = DateTime.Now.Date;
      this._CREATED_DATE = DateTime.Now.Date;
      this._UPDATED_DATE = DateTime.Now.Date;
    }

    public string COMP_CODE
    {
      get
      {
        return this._COMP_CODE;
      }
      set
      {
        this._COMP_CODE = value.Trim();
      }
    }

    public DateTime INV_DATE
    {
      get
      {
        return this._INV_DATE;
      }
      set
      {
        this._INV_DATE = value;
      }
    }

    public string INV_NO
    {
      get
      {
        return this._INV_NO;
      }
      set
      {
        this._INV_NO = value.Trim();
      }
    }

    public string CUSTOMER_ID
    {
      get
      {
        return this._CUSTOMER_ID;
      }
      set
      {
        this._CUSTOMER_ID = value.Trim();
      }
    }

    public string CRNCY_CODE
    {
      get
      {
        return this._CRNCY_CODE;
      }
      set
      {
        this._CRNCY_CODE = value;
      }
    }

    public double AMOUNT
    {
      get
      {
        return this._AMOUNT;
      }
      set
      {
        this._AMOUNT = value;
      }
    }

    public DateTime DUE_DATE
    {
      get
      {
        return this._DUE_DATE;
      }
      set
      {
        this._DUE_DATE = value;
      }
    }

    public string STATUS
    {
      get
      {
        return this._STATUS;
      }
      set
      {
        this._STATUS = value.Trim();
      }
    }

    public string CREATED_BY
    {
      get
      {
        return this._CREATED_BY;
      }
      set
      {
        this._CREATED_BY = value.Trim();
      }
    }

    public DateTime CREATED_DATE
    {
      get
      {
        return this._CREATED_DATE;
      }
      set
      {
        this._CREATED_DATE = value;
      }
    }

    public string UPDATED_BY
    {
      get
      {
        return this._UPDATED_BY;
      }
      set
      {
        this._UPDATED_BY = value.Trim();
      }
    }

    public DateTime UPDATED_DATE
    {
      get
      {
        return this._UPDATED_DATE;
      }
      set
      {
        this._UPDATED_DATE = value;
      }
    }

    public string EQUIVALENT_CRNCY
    {
      get
      {
        return this._EQUIVALENT_CRNCY;
      }
      set
      {
        this._EQUIVALENT_CRNCY = value.Trim();
      }
    }

    public double EQUIVALENT_AMOUNT
    {
      get
      {
        return this._EQUIVALENT_AMOUNT;
      }
      set
      {
        this._EQUIVALENT_AMOUNT = value;
      }
    }

    public string REMARKS
    {
      get
      {
        return this._REMARKS;
      }
      set
      {
        this._REMARKS = value.Trim();
      }
    }
  }
}
