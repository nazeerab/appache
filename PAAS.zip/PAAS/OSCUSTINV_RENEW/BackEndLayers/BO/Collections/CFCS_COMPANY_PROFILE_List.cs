﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Collections.CFCS_COMPANY_PROFILE_List
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System.Collections.Generic;

namespace BackEndLayers.BO.Collections
{
  public class CFCS_COMPANY_PROFILE_List : List<CFCS_COMPANY_PROFILE>
  {
  }
}
