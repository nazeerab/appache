﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.OSCUSDAT.MessageBodyCustomerInfo
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.OSCUSDAT
{
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [DesignerCategory("code")]
  [XmlType(AnonymousType = true)]
  [Serializable]
  public class MessageBodyCustomerInfo
  {
    private string customerIDField;
    private string customerTypeField;
    private string nameField;
    private string cityField;
    private string actionFlagField;

    [NotEmptyStringValidator("CustomerID should not be empty.")]
    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string CustomerID
    {
      get
      {
        return this.customerIDField;
      }
      set
      {
        this.customerIDField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("CustomerType should not be empty.")]
    public string CustomerType
    {
      get
      {
        return this.customerTypeField;
      }
      set
      {
        this.customerTypeField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("Name should not be empty.")]
    public string Name
    {
      get
      {
        return this.nameField;
      }
      set
      {
        this.nameField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("City should not be empty.")]
    public string City
    {
      get
      {
        return this.cityField;
      }
      set
      {
        this.cityField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("ActionFlag should not be empty.")]
    public string ActionFlag
    {
      get
      {
        return this.actionFlagField;
      }
      set
      {
        this.actionFlagField = value;
      }
    }
  }
}
