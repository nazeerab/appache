﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Status
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class Status
  {
    private string _CODE = string.Empty;
    private string _DESC = string.Empty;
    private string _EXISTATUS = string.Empty;

    public string Code
    {
      get
      {
        return this._CODE;
      }
      set
      {
        this._CODE = value;
      }
    }

    public string Description
    {
      get
      {
        return this._DESC;
      }
      set
      {
        this._DESC = value;
      }
    }

    public string existingstatus
    {
      get
      {
        return this._EXISTATUS;
      }
      set
      {
        this._EXISTATUS = value;
      }
    }
  }
}
