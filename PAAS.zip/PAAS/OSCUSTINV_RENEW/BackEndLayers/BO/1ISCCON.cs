﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.MessageBody
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.ISCCON
{
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [DesignerCategory("code")]
  [XmlType(AnonymousType = true)]
  [Serializable]
  public class MessageBody
  {
    private MessageBodyCreditConfirmationTransaction[] creditConfirmationField;

    [XmlArray(Form = XmlSchemaForm.Unqualified)]
    [XmlArrayItem("Transaction", typeof (MessageBodyCreditConfirmationTransaction), Form = XmlSchemaForm.Unqualified, IsNullable = false)]
    public MessageBodyCreditConfirmationTransaction[] CreditConfirmation
    {
      get
      {
        return this.creditConfirmationField;
      }
      set
      {
        this.creditConfirmationField = value;
      }
    }
  }
}
