﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Transaction
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.ComponentModel;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "Transaction")]
  [Serializable]
  public class Transaction
  {
    private string _tuxMsgIn = string.Empty;
    private string _tuxMsgOut = string.Empty;
    private string _dbFailReason = string.Empty;
    private string _tuxFailReason = string.Empty;
    [XmlElement(DataType = "string", ElementName = "SequenceNumber", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __SequenceNumber;
    [XmlElement(DataType = "string", ElementName = "AckNumber", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __AckNumber;
    [XmlElement(DataType = "string", ElementName = "StatusCode", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __StatusCode;
    [XmlElement(DataType = "string", ElementName = "StatusDetail", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __StatusDetail;
    private bool _isTux;
    private bool _isDb;

    [XmlIgnore]
    [NotEmptyStringValidator("SequenceNumber should not be empty.")]
    public string SequenceNumber
    {
      get
      {
        return this.__SequenceNumber;
      }
      set
      {
        this.__SequenceNumber = value;
      }
    }

    [XmlIgnore]
    public string AckNumber
    {
      get
      {
        return this.__AckNumber;
      }
      set
      {
        this.__AckNumber = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("StatusCode should not be empty.")]
    public string StatusCode
    {
      get
      {
        return this.__StatusCode;
      }
      set
      {
        this.__StatusCode = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("StatusDetail should not be empty.")]
    public string StatusDetail
    {
      get
      {
        return this.__StatusDetail;
      }
      set
      {
        this.__StatusDetail = value;
      }
    }

    public string TuxMsgIn
    {
      get
      {
        return this._tuxMsgIn;
      }
      set
      {
        this._tuxMsgIn = value;
      }
    }

    public string TuxMsgOut
    {
      get
      {
        return this._tuxMsgOut;
      }
      set
      {
        this._tuxMsgOut = value;
      }
    }

    public bool IsTux
    {
      get
      {
        return this._isTux;
      }
      set
      {
        this._isTux = value;
      }
    }

    public string DbFailReason
    {
      get
      {
        return this._dbFailReason;
      }
      set
      {
        this._dbFailReason = value;
      }
    }

    public string TuxFailReason
    {
      get
      {
        return this._tuxFailReason;
      }
      set
      {
        this._tuxFailReason = value;
      }
    }

    public bool IsDb
    {
      get
      {
        return this._isDb;
      }
      set
      {
        this._isDb = value;
      }
    }
  }
}
