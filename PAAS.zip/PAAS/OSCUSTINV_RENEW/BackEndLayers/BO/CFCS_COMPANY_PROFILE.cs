﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CFCS_COMPANY_PROFILE
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;

namespace BackEndLayers.BO
{
  public class CFCS_COMPANY_PROFILE
  {
    private string _COMP_CODE = string.Empty;
    private string _DESCR_ENG = string.Empty;
    private string _DESCR_ARB = string.Empty;
    private string _COMP_SYS_CODE = string.Empty;
    private string _STATUS = string.Empty;
    private string _PAYMENT_MODE = string.Empty;
    private string _PAYMENT_TYPE = string.Empty;
    private string _REVERSAL_ALLOWED = string.Empty;
    private string _BSF_MAINTAINS_ID = string.Empty;
    private string _CREATED_BY = string.Empty;
    private string _UPDATED_BY = string.Empty;
    private string _INCOMING_TRF_ALLOWED = string.Empty;
    private string _CRNCY_Code = string.Empty;
    private double _ID_LENGTH;
    private DateTime _CREATED_DATE;
    private DateTime _UPDATED_DATE;

    public string CRNCY_Code
    {
      get
      {
        return this._CRNCY_Code;
      }
      set
      {
        this._CRNCY_Code = value;
      }
    }

    public string COMP_CODE
    {
      get
      {
        return this._COMP_CODE;
      }
      set
      {
        this._COMP_CODE = value.Trim();
      }
    }

    public string COMP_SYS_CODE
    {
      get
      {
        return this._COMP_SYS_CODE;
      }
      set
      {
        this._COMP_SYS_CODE = value;
      }
    }

    public string DESCR_ENG
    {
      get
      {
        return this._DESCR_ENG;
      }
      set
      {
        this._DESCR_ENG = value.Trim();
      }
    }

    public string DESCR_ARB
    {
      get
      {
        return this._DESCR_ARB;
      }
      set
      {
        this._DESCR_ARB = value.Trim();
      }
    }

    public string STATUS
    {
      get
      {
        return this._STATUS;
      }
      set
      {
        this._STATUS = value.Trim();
      }
    }

    public string PAYMENT_MODE
    {
      get
      {
        return this._PAYMENT_MODE;
      }
      set
      {
        this._PAYMENT_MODE = value.Trim();
      }
    }

    public string PAYMENT_TYPE
    {
      get
      {
        return this._PAYMENT_TYPE;
      }
      set
      {
        this._PAYMENT_TYPE = value.Trim();
      }
    }

    public string REVERSAL_ALLOWED
    {
      get
      {
        return this._REVERSAL_ALLOWED;
      }
      set
      {
        this._REVERSAL_ALLOWED = value.Trim();
      }
    }

    public string BSF_MAINTAINS_ID
    {
      get
      {
        return this._BSF_MAINTAINS_ID;
      }
      set
      {
        this._BSF_MAINTAINS_ID = value.Trim();
      }
    }

    public double ID_LENGTH
    {
      get
      {
        return this._ID_LENGTH;
      }
      set
      {
        this._ID_LENGTH = value;
      }
    }

    public string CREATED_BY
    {
      get
      {
        return this._CREATED_BY;
      }
      set
      {
        this._CREATED_BY = value.Trim();
      }
    }

    public DateTime CREATED_DATE
    {
      get
      {
        return this._CREATED_DATE;
      }
      set
      {
        this._CREATED_DATE = value;
      }
    }

    public string UPDATED_BY
    {
      get
      {
        return this._UPDATED_BY;
      }
      set
      {
        this._UPDATED_BY = value.Trim();
      }
    }

    public DateTime UPDATED_DATE
    {
      get
      {
        return this._UPDATED_DATE;
      }
      set
      {
        this._UPDATED_DATE = value;
      }
    }

    public string INCOMING_TRF_ALLOWED
    {
      get
      {
        return this._INCOMING_TRF_ALLOWED;
      }
      set
      {
        this._INCOMING_TRF_ALLOWED = value.Trim();
      }
    }
  }
}
