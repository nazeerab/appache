﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.CreditConfirmationAck
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.Collections;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "CreditConfirmationAck")]
  [Serializable]
  public class CreditConfirmationAck
  {
    [XmlElement(ElementName = "Transaction", IsNullable = false, Type = typeof (Transaction))]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public TransactionCollection __TransactionCollection;

    [DispId(-4)]
    public IEnumerator GetEnumerator()
    {
      return this.TransactionCollection.GetEnumerator();
    }

    public Transaction Add(Transaction obj)
    {
      return this.TransactionCollection.Add(obj);
    }

    [XmlIgnore]
    public Transaction this[int index]
    {
      get
      {
        return this.TransactionCollection[index];
      }
    }

    [XmlIgnore]
    public int Count
    {
      get
      {
        return this.TransactionCollection.Count;
      }
    }

    public void Clear()
    {
      this.TransactionCollection.Clear();
    }

    public Transaction Remove(int index)
    {
      Transaction transaction = this.TransactionCollection[index];
      this.TransactionCollection.Remove(transaction);
      return transaction;
    }

    public void Remove(object obj)
    {
      this.TransactionCollection.Remove(obj);
    }

    [XmlIgnore]
    public TransactionCollection TransactionCollection
    {
      get
      {
        if (this.__TransactionCollection == null)
          this.__TransactionCollection = new TransactionCollection();
        return this.__TransactionCollection;
      }
      set
      {
        this.__TransactionCollection = value;
      }
    }
  }
}
