﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Message
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.ComponentModel;
using System.Xml.Serialization;

namespace BackEndLayers.BO.CCACK
{
  [XmlRoot(ElementName = "Message", IsNullable = false)]
  [Serializable]
  public class Message
  {
    [XmlElement(ElementName = "Header", IsNullable = false, Type = typeof (Header))]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public HeaderCollection __HeaderCollection;
    [XmlElement(ElementName = "Body", IsNullable = false, Type = typeof (Body))]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public BodyCollection __BodyCollection;

    [XmlIgnore]
    public HeaderCollection HeaderCollection
    {
      get
      {
        if (this.__HeaderCollection == null)
          this.__HeaderCollection = new HeaderCollection();
        return this.__HeaderCollection;
      }
      set
      {
        this.__HeaderCollection = value;
      }
    }

    [XmlIgnore]
    public BodyCollection BodyCollection
    {
      get
      {
        if (this.__BodyCollection == null)
          this.__BodyCollection = new BodyCollection();
        return this.__BodyCollection;
      }
      set
      {
        this.__BodyCollection = value;
      }
    }
  }
}
