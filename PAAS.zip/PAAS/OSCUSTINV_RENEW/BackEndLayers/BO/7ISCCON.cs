﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.Tag32A
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;

namespace BackEndLayers.BO.ISCCON
{
  public class Tag32A
  {
    private string _creditAcctCrcny = string.Empty;
    private DateTime _transDate;
    private double _creditAmt;

    public DateTime TransDate
    {
      get
      {
        return this._transDate;
      }
      set
      {
        this._transDate = value;
      }
    }

    public string CreditAcctCrcny
    {
      get
      {
        return this._creditAcctCrcny;
      }
      set
      {
        this._creditAcctCrcny = value;
      }
    }

    public double CreditAmt
    {
      get
      {
        return this._creditAmt;
      }
      set
      {
        this._creditAmt = value;
      }
    }
  }
}
