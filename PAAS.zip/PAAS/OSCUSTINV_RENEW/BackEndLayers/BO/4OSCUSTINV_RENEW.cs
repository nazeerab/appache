﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.OSCUSTINV_RENEW.MessageHeader
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.OSCUSTINV_RENEW
{
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [DesignerCategory("code")]
  [XmlType(AnonymousType = true)]
  [Serializable]
  public class MessageHeader
  {
    private string senderField;
    private string receiverField;
    private string messageTypeField;
    private string messageDescriptionField;
    private string timeStampField;

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("Sender should not be empty.")]
    public string Sender
    {
      get
      {
        return this.senderField;
      }
      set
      {
        this.senderField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("Receiver should not be empty.")]
    public string Receiver
    {
      get
      {
        return this.receiverField;
      }
      set
      {
        this.receiverField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("MessageType should not be empty.")]
    public string MessageType
    {
      get
      {
        return this.messageTypeField;
      }
      set
      {
        this.messageTypeField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("MessageDescription should not be empty.")]
    public string MessageDescription
    {
      get
      {
        return this.messageDescriptionField;
      }
      set
      {
        this.messageDescriptionField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    [NotEmptyStringValidator("TimeStamp should not be empty.")]
    public string TimeStamp
    {
      get
      {
        return this.timeStampField;
      }
      set
      {
        this.timeStampField = value;
      }
    }
  }
}
