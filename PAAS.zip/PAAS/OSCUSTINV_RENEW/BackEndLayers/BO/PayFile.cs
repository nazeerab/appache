﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.PayFile
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class PayFile
  {
    private string _path = string.Empty;
    private string _name = string.Empty;
    private string _fileRef = string.Empty;

    public string Path
    {
      get
      {
        return this._path;
      }
      set
      {
        this._path = value;
      }
    }

    public string Name
    {
      get
      {
        return this._name;
      }
      set
      {
        this._name = value;
      }
    }

    public string FileRef
    {
      get
      {
        return this._fileRef;
      }
      set
      {
        this._fileRef = value;
      }
    }
  }
}
