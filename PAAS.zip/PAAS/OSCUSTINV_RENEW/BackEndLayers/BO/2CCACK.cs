﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.BodyCollection
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using System;
using System.Collections;
using System.ComponentModel;

namespace BackEndLayers.BO.CCACK
{
  [EditorBrowsable(EditorBrowsableState.Advanced)]
  [Serializable]
  public class BodyCollection : ArrayList
  {
    public Body Add(Body obj)
    {
      this.Add((object) obj);
      return obj;
    }

    public Body Add()
    {
      return this.Add(new Body());
    }

    public void Insert(int index, Body obj)
    {
      this.Insert(index, (object) obj);
    }

    public void Remove(Body obj)
    {
      this.Remove((object) obj);
    }

    public Body this[int index]
    {
      get
      {
        return (Body) base[index];
      }
      set
      {
        this[index] = (object) value;
      }
    }
  }
}
