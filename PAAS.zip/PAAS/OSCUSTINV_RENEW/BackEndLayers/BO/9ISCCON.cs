﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.TransactionRef
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

namespace BackEndLayers.BO.ISCCON
{
  public class TransactionRef
  {
    private string _transRef = string.Empty;
    private string _sequenceNo = string.Empty;

    public string TransRef
    {
      get
      {
        return this._transRef;
      }
      set
      {
        this._transRef = value;
      }
    }

    public string SequenceNo
    {
      get
      {
        return this._sequenceNo;
      }
      set
      {
        this._sequenceNo = value;
      }
    }
  }
}
