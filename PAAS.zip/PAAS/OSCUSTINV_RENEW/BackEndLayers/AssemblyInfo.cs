﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BackEndLayers")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("BackEndLayers")]
[assembly: AssemblyCopyright("Copyright © BSF 2011")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("121ea6a6-8b31-4825-ac29-c1d883430815")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
