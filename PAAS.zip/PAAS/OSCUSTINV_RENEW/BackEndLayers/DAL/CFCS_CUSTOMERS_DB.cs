﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.DAL.CFCS_CUSTOMERS_DB
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D4C0286C-5005-4133-8C47-428496AB92E9
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSTINV_RENEW\BackEndLayers.dll

using BackEndLayers.BO;
using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace BackEndLayers.DAL
{
  public class CFCS_CUSTOMERS_DB
  {
    public static Status Save(CFCS_CUSTOMERS myCFCS_CUSTOMERS)
    {
      Status status = new Status();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("cfcs_pkg.maintain_cfc_customers", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (myCFCS_CUSTOMERS.COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) myCFCS_CUSTOMERS.COMP_CODE.ToString());
          if (myCFCS_CUSTOMERS.CUSTOMER_ID == string.Empty)
            oracleCommand.Parameters.Add("PI_CUST_ID", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_CUST_ID", (object) myCFCS_CUSTOMERS.CUSTOMER_ID.ToString());
          if (myCFCS_CUSTOMERS.CUSTOMER_NAME == string.Empty)
            oracleCommand.Parameters.Add("PI_CUST_NAME", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_CUST_NAME", (object) myCFCS_CUSTOMERS.CUSTOMER_NAME.ToString());
          if (myCFCS_CUSTOMERS.CUSTOMER_TYPE == string.Empty)
            oracleCommand.Parameters.Add("PI_CUST_TYPE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_CUST_TYPE", (object) myCFCS_CUSTOMERS.CUSTOMER_TYPE.ToString());
          if (myCFCS_CUSTOMERS.CUSTOMER_CITY == string.Empty)
          {
            oracleCommand.Parameters.Add("PI_CUST_CITY", (object) DBNull.Value);
          }
          else
          {
            if (myCFCS_CUSTOMERS.CUSTOMER_CITY.Length > 20)
              myCFCS_CUSTOMERS.CUSTOMER_CITY = myCFCS_CUSTOMERS.CUSTOMER_CITY.Substring(0, 19);
            oracleCommand.Parameters.Add("PI_CUST_CITY", (object) myCFCS_CUSTOMERS.CUSTOMER_CITY.ToString());
          }
          if (myCFCS_CUSTOMERS.STATUS == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) myCFCS_CUSTOMERS.STATUS.ToString());
          OracleParameter oracleParameter1 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_RET_DESCR", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          ((DbConnection) conn).Open();
          OracleTransaction oracleTransaction = conn.BeginTransaction(IsolationLevel.ReadCommitted);
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            ((DbTransaction) oracleTransaction).Commit();
            status.Code = ((DbParameter) oracleParameter1).Value.ToString();
            status.Description = ((DbParameter) oracleParameter2).Value.ToString();
          }
          catch (Exception ex)
          {
            status.Code = "FAILED";
            status.Description = ex.Message;
            ((DbTransaction) oracleTransaction).Rollback();
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
      return status;
    }

    public static CFCS_CUSTOMERS Get(
      string Channel,
      string CompanyCode,
      string CustomerID,
      string InquiryType)
    {
      CFCS_CUSTOMERS cfcsCustomers = new CFCS_CUSTOMERS();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("cfcs_pkg.get_cfcs_cust_dets", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (Channel == string.Empty)
            oracleCommand.Parameters.Add("PI_CHANNEL", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_CHANNEL", OracleDbType.Varchar2, (object) Channel, ParameterDirection.Input);
          if (CompanyCode == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", OracleDbType.Varchar2, (object) CompanyCode, ParameterDirection.Input);
          if (CustomerID == string.Empty)
            oracleCommand.Parameters.Add("PI_CUST_ID", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_CUST_ID", OracleDbType.Varchar2, (object) CustomerID, ParameterDirection.Input);
          if (InquiryType == string.Empty)
            oracleCommand.Parameters.Add("PI_INQ_TYPE", OracleDbType.Varchar2, (object) DBNull.Value, ParameterDirection.Input);
          else
            oracleCommand.Parameters.Add("PI_INQ_TYPE", OracleDbType.Varchar2, (object) InquiryType, ParameterDirection.Input);
          oracleCommand.Parameters.Add("po_cur_invc", OracleDbType.RefCursor, (object) DBNull.Value, ParameterDirection.Output);
          ((DbConnection) conn).Open();
          using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader())
          {
            if (((DbDataReader) oracleDataReader).HasRows)
              cfcsCustomers = CFCS_CUSTOMERS_DB.FillDataRecord((IDataRecord) oracleDataReader);
            ((DbDataReader) oracleDataReader).Close();
          }
          ((DbConnection) conn).Close();
        }
      }
      return cfcsCustomers;
    }

    private static CFCS_CUSTOMERS FillDataRecord(IDataRecord myDataRecord)
    {
      CFCS_CUSTOMERS cfcsCustomers = new CFCS_CUSTOMERS();
      int fieldCount = myDataRecord.FieldCount;
      for (int i = 0; i < fieldCount; ++i)
      {
        switch (myDataRecord.GetName(i))
        {
          case "COMP_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.COMP_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CREATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CREATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "CRNCY_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CRNCY_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CUSTOMER_CITY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CUSTOMER_CITY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CUSTOMER_ID":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CUSTOMER_ID = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CUSTOMER_NAME":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CUSTOMER_NAME = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CUSTOMER_TYPE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.CUSTOMER_TYPE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "STATUS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.STATUS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "UPDATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.UPDATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "UPDATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsCustomers.UPDATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          default:
            throw new Exception("New column found in CFCS_CUSTOMERS or column name not matched, verify data persistence over class", new Exception("myCFCS_CUSTOMERS filling failed"));
        }
      }
      return cfcsCustomers;
    }
  }
}
