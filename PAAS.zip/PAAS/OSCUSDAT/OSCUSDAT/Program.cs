﻿// Decompiled with JetBrains decompiler
// Type: OSCUSDAT.Program
// Assembly: OSCUSDAT, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CD014E78-CF5E-406F-9C7E-A7FA7EBBB215
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_OSCUSDAT\OSCUSDAT.exe

using BackEndLayers.BLL;
using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSDAT;
using BackEndLayers.Log;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OSCUSDAT
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      DateTime now = DateTime.Now;
      Message message1 = new Message();
      Reports reports = new Reports();
      LogOSCUSDAT logOscusdat = new LogOSCUSDAT();
      CFCS_CUSTOMERS_List cfcsCustomersList1 = new CFCS_CUSTOMERS_List();
      List<MessageBodyCustomerInfo> Valid_Customers_List = new List<MessageBodyCustomerInfo>();
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string fileName = string.Empty;
      bool isValid = false;
      bool flag = true;
      Console.WriteLine("Process OSCUSDAT is started.");
      try
      {
        string companyCode = args[0];
        Console.WriteLine("Company Code: " + companyCode);
        string str = args[1];
        Console.WriteLine("File path: " + str);
        fileName = Util.GetFileName(str);
        Console.WriteLine("File name: " + fileName);
        Console.WriteLine("Parsing message.");
        Message message2 = OSCUSDAT_Manager.XMLtoOSCUSDAT(str);
        Console.WriteLine("Parsing message done.");
        Console.WriteLine("Runing validation on message.");
        Reports R = OSCUSDATValidation_Manager.MessageValidation(message2, fileName, companyCode, out Valid_Customers_List, out isValid);
        Console.WriteLine("Validation on message done.");
        switch (isValid)
        {
          case false:
            Console.WriteLine("Invalid xml file, please check logs");
            Console.WriteLine("Logging files.");
            logOscusdat.Log(Util.PrintReport(R), fileName, Eventtype.informaton);
            Console.WriteLine("Logging Complete.");
            Console.WriteLine(Util.PrintReport(R));
            break;
          case true:
            Console.WriteLine("Validation done and message parsed successfully.");
            CFCS_CUSTOMERS_List cfcsCustomersList2 = CFCS_CUSTOMERS_Manager.Get(Valid_Customers_List, companyCode);
            CFCS_CUSTOMERS_Manager.Save(OSCUSDAT_Manager.GetCustomers(message2), cfcsCustomersList2, fileName);
            Console.WriteLine(cfcsCustomersList2.Count<CFCS_CUSTOMERS>().ToString() + " Invoice(s) proccess Successfully.");
            Console.WriteLine("Logging file.");
            logOscusdat.Log(Util.PrintReport(R), fileName, Eventtype.informaton);
            Console.WriteLine("Logging Complete.");
            Console.WriteLine(Util.PrintReport(R));
            break;
        }
      }
      catch (IndexOutOfRangeException ex)
      {
        logOscusdat.Log((Exception) ex, fileName, Eventtype.Error);
        Console.WriteLine("Please provide compnay code as args[0] and path as args[1]");
        flag = false;
      }
      catch (Exception ex)
      {
        logOscusdat.Log(ex, fileName, Eventtype.Error);
        Console.WriteLine("Application terminated unsuccessfully, please check logs for detail.");
        flag = false;
      }
      if (flag)
        Console.WriteLine("Process end with Success.");
      else
        Console.WriteLine("Process end with Failure.");
      Console.WriteLine("Process tooks " + (DateTime.Now - now).Milliseconds.ToString() + " MS to compelete.");
    }
  }
}
