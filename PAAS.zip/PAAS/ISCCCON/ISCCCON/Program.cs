﻿// Decompiled with JetBrains decompiler
// Type: ISCCCON.Program
// Assembly: ISCCCON, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B25C3019-8A8A-429A-93CC-B4830EAC8ACC
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\ISCCCON.exe

using BackEndLayers.BLL;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.ISCCON;
using BackEndLayers.Log;
using System;

namespace ISCCCON
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      DateTime now = DateTime.Now;
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string fileRef = string.Empty;
      string fileName = string.Empty;
      bool isNotr = false;
      bool flag = true;
      Message message1 = new Message();
      LogISCCCON logIscccon = new LogISCCCON();
      TransactionRef_List O_grpRefs = new TransactionRef_List();
      TransactionRef_List O_indRefs = new TransactionRef_List();
      Console.WriteLine("Process ISCCCON is started.");
      try
      {
        empty1 = args[0];
        Console.WriteLine("Company Code: " + empty1);
        Console.WriteLine("Fetching message.");
        Message message2 = ISCCON_Manager.GetMessage(empty1, out fileRef, out O_grpRefs, out O_indRefs, out isNotr);
        Console.WriteLine("Fetching message done.");
        Console.WriteLine("Preparing message xml.");
        string file = Util.SerializeToFile<Message>(message2);
        Console.WriteLine("Preparing message xml done.");
        if (!isNotr)
        {
          Console.WriteLine("Message has transactions.");
          fileName = "ARAMCO.PASS.ISCCCON-CREDIT." + DateTime.Now.ToString("yyyyMMddTHHmmss") + "." + fileRef;
        }
        else
        {
          Console.WriteLine("Message is NOTR.");
          fileName = "ARAMCO.PASS.ISSSCON-CREDIT." + DateTime.Now.ToString("yyyyMMddTHHmmss") + ".NOTR";
        }
        Console.WriteLine("Its file name is: " + fileName);
        Console.WriteLine("Writing message.");
        Util.WriteFile(Util.RemoveNamespace(file, "<Message>"), fileName);
        Console.WriteLine("Writing message done.");
        Console.WriteLine("Loging message.");
        logIscccon.Log(message2, fileName);
        Console.WriteLine("Loging complete.");
      }
      catch (IndexOutOfRangeException ex)
      {
        logIscccon.Log((Exception) ex, fileName, Eventtype.Error);
        Console.WriteLine("Please provide compnay code as args[0].");
        flag = false;
      }
      catch (Exception ex)
      {
        ISCCON_Manager.RollbackFileRef(empty1, true, O_grpRefs);
        ISCCON_Manager.RollbackFileRef(empty1, false, O_indRefs);
        logIscccon.Log(ex, fileName, Eventtype.Error);
        Console.WriteLine("Application terminated unsuccessfully, please check logs for detail.");
        flag = false;
      }
      if (flag)
        Console.WriteLine("Process end with Success.");
      else
        Console.WriteLine("Process end with Failure.");
      Console.WriteLine("Process tooks " + (DateTime.Now - now).Milliseconds.ToString() + " MS to compelete.");
    }
  }
}
