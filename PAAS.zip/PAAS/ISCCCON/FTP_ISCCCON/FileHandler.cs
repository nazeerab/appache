﻿// Decompiled with JetBrains decompiler
// Type: FTP_ISCCCON.FileHandler
// Assembly: FTP_ISCCCON, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F3B3A18E-EFA4-4D83-B0BB-8347D2BDD9A5
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\FTP_ISCCCON.exe

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.Log;
using System;
using System.Configuration;
using System.IO;
using System.Linq;

namespace FTP_ISCCCON
{
  public class FileHandler
  {
    public static bool MoveFile(string fullFileName)
    {
      string str1 = ConfigurationManager.AppSettings["FTP_Sucess"].ToString();
      string str2 = fullFileName;
      LogFTP logFtp = new LogFTP();
      FileInfo fileInfo = new FileInfo(str2);
      try
      {
        string str3 = str1.Trim() + "\\" + fileInfo.Name;
        if (File.Exists(str3))
          File.Delete(str3);
        File.Copy(fullFileName, str3);
        if (File.Exists(str2))
          File.Delete(str2);
      }
      catch (Exception ex)
      {
        logFtp.Log(ex, Eventtype.Error);
        throw ex;
      }
      return true;
    }

    public static void MoveFile(PayFile_List FileList)
    {
      for (int index = 0; index < FileList.Count<PayFile>(); ++index)
      {
        if (!FileHandler.MoveFile(FileList[index].Path))
          ;
      }
    }
  }
}
