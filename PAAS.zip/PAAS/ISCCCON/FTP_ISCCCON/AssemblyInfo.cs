﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FTP_ISCCCON")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BSF")]
[assembly: AssemblyProduct("FTP_ISCCCON")]
[assembly: AssemblyCopyright("Copyright © BSF 2011")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("cc0b7784-0a87-4f4d-a66f-23ed53492288")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
