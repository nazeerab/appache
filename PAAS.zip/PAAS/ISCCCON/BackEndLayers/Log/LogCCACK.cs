﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.Log.LogCCACK
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BLL;
using BackEndLayers.BO;
using BackEndLayers.BO.CCACK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BackEndLayers.Log
{
  public class LogCCACK : Logs
  {
    public void Log(
      string fileName,
      List<Transaction> Valid_ACK,
      List<Transaction> ALL_ACK,
      Reports R)
    {
      StringBuilder stringBuilder = new StringBuilder();
      int num1 = 0;
      int num2 = 0;
      stringBuilder.Append("Process: CCACK");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Acks: " + ALL_ACK.Count<Transaction>().ToString());
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Total Valid Acks: " + Valid_ACK.Count<Transaction>().ToString());
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Invalid Acks Reasons");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(Util.PrintReport(R));
      stringBuilder.Append("Valid Acks Processing Report");
      stringBuilder.Append(Environment.NewLine);
      for (int index = 0; index < Valid_ACK.Count<Transaction>(); ++index)
      {
        stringBuilder.Append("Ack Sequence No: " + Valid_ACK[index].SequenceNumber);
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("Tux Status: " + Valid_ACK[index].IsTux.ToString());
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("Tux Msg_In: " + Valid_ACK[index].TuxMsgIn);
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("Tux Msg_Out: " + Valid_ACK[index].TuxMsgOut);
        stringBuilder.Append(Environment.NewLine);
        stringBuilder.Append("Db Status: " + Valid_ACK[index].IsDb.ToString());
        stringBuilder.Append(Environment.NewLine);
        if (Valid_ACK[index].IsDb && Valid_ACK[index].IsTux)
        {
          stringBuilder.Append("Ack Marked As: Success");
          stringBuilder.Append(Environment.NewLine);
          ++num1;
        }
        else
        {
          stringBuilder.Append("Ack Marked As: Failed");
          stringBuilder.Append(Environment.NewLine);
          ++num2;
        }
      }
      stringBuilder.Append("Summary");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("T. Valid Acks: " + Valid_ACK.Count<Transaction>().ToString());
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("T. Valid Acks Success: " + num1.ToString());
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("T. Valid Acks Failed: " + num2.ToString());
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), Eventtype.informaton);
    }

    public void Log(string str, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: CCACK");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append(str);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }

    public void Log(Exception ex, string fileName, Eventtype T)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("Process: CCACK");
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("File Name: " + fileName);
      stringBuilder.Append(Environment.NewLine);
      stringBuilder.Append("Exception:  " + (object) ex);
      this.Log(stringBuilder.ToString());
      EventViewer.Log(stringBuilder.ToString(), T);
    }
  }
}
