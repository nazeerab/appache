﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.DAL.CFCS_INVOICE_LOG_DB
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO;
using Oracle.DataAccess.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace BackEndLayers.DAL
{
  public class CFCS_INVOICE_LOG_DB
  {
    public static Status Save(CFCS_INVOICE_LOG myCFCS_INVOICE_LOG)
    {
      Status status = new Status();
      using (OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["DB_CFCS"].ConnectionString))
      {
        using (OracleCommand oracleCommand = new OracleCommand("cfcs_pkg.maintain_cfc_inv_dets", conn))
        {
          ((DbCommand) oracleCommand).CommandType = CommandType.StoredProcedure;
          if (myCFCS_INVOICE_LOG.COMP_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_COMP_CODE", (object) myCFCS_INVOICE_LOG.COMP_CODE.ToString());
          DateTime invDate = myCFCS_INVOICE_LOG.INV_DATE;
          bool flag = true;
          oracleCommand.Parameters.Add("PI_INV_DATE", (object) myCFCS_INVOICE_LOG.INV_DATE.ToString("yyyy-MM-dd"));
          if (myCFCS_INVOICE_LOG.INV_NO == string.Empty)
            oracleCommand.Parameters.Add("PI_INV_NO", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_INV_NO", (object) myCFCS_INVOICE_LOG.INV_NO.ToString());
          if (myCFCS_INVOICE_LOG.CUSTOMER_ID == string.Empty)
            oracleCommand.Parameters.Add("PI_CUST_ID", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_CUST_ID", (object) myCFCS_INVOICE_LOG.CUSTOMER_ID.ToString());
          if (myCFCS_INVOICE_LOG.CRNCY_CODE == string.Empty)
            oracleCommand.Parameters.Add("PI_INV_CRNCY", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_INV_CRNCY", (object) myCFCS_INVOICE_LOG.CRNCY_CODE.ToString());
          if (myCFCS_INVOICE_LOG.AMOUNT == 0.0)
            oracleCommand.Parameters.Add("PI_INV_AMOUNT", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_INV_AMOUNT", (object) myCFCS_INVOICE_LOG.AMOUNT.ToString());
          if (myCFCS_INVOICE_LOG.EQUIVALENT_CRNCY == string.Empty)
            oracleCommand.Parameters.Add("PI_INV_EQV_CRNCY", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_INV_EQV_CRNCY", (object) myCFCS_INVOICE_LOG.EQUIVALENT_CRNCY.ToString());
          if (myCFCS_INVOICE_LOG.EQUIVALENT_AMOUNT == 0.0)
            oracleCommand.Parameters.Add("PI_INV_EQV_AMOUNT", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_INV_EQV_AMOUNT", (object) myCFCS_INVOICE_LOG.EQUIVALENT_AMOUNT.ToString());
          DateTime dueDate = myCFCS_INVOICE_LOG.DUE_DATE;
          flag = true;
          oracleCommand.Parameters.Add("DUE_DATE", (object) myCFCS_INVOICE_LOG.DUE_DATE.ToString("yyyy-MM-dd"));
          if (myCFCS_INVOICE_LOG.STATUS == string.Empty)
            oracleCommand.Parameters.Add("PI_INV_STATUS", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_INV_STATUS", (object) myCFCS_INVOICE_LOG.STATUS.ToString());
          if (myCFCS_INVOICE_LOG.REMARKS == string.Empty)
            oracleCommand.Parameters.Add("PI_REMARKS", (object) DBNull.Value);
          else
            oracleCommand.Parameters.Add("PI_REMARKS", (object) myCFCS_INVOICE_LOG.REMARKS);
          OracleParameter oracleParameter1 = new OracleParameter("PO_RET_CODE", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          OracleParameter oracleParameter2 = new OracleParameter("PO_RET_DESCR", OracleDbType.Varchar2, 250, (object) DBNull.Value, ParameterDirection.Output);
          oracleCommand.Parameters.Add(oracleParameter1);
          oracleCommand.Parameters.Add(oracleParameter2);
          ((DbConnection) conn).Open();
          OracleTransaction oracleTransaction = conn.BeginTransaction(IsolationLevel.ReadCommitted);
          try
          {
            ((DbCommand) oracleCommand).ExecuteNonQuery();
            ((DbTransaction) oracleTransaction).Commit();
            status.Code = ((DbParameter) oracleParameter1).Value.ToString();
            status.Description = ((DbParameter) oracleParameter2).Value.ToString();
          }
          catch (Exception ex)
          {
            status.Code = "FAILED";
            status.Description = ex.Message;
            ((DbTransaction) oracleTransaction).Rollback();
            throw ex;
          }
          finally
          {
            ((DbConnection) conn).Close();
          }
        }
      }
      return status;
    }

    private static CFCS_INVOICE_LOG FillDataRecord(IDataRecord myDataRecord)
    {
      CFCS_INVOICE_LOG cfcsInvoiceLog = new CFCS_INVOICE_LOG();
      int fieldCount = myDataRecord.FieldCount;
      for (int i = 0; i < fieldCount; ++i)
      {
        switch (myDataRecord.GetName(i))
        {
          case "COMP_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.COMP_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "INV_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.INV_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "INV_NO":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.INV_NO = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CUSTOMER_ID":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.CUSTOMER_ID = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CRNCY_CODE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.CRNCY_CODE = myDataRecord.GetString(i);
              break;
            }
            break;
          case "AMOUNT":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.AMOUNT = myDataRecord.GetDouble(i);
              break;
            }
            break;
          case "DUE_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.DUE_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "STATUS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.STATUS = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.CREATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "CREATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.CREATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "UPDATED_BY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.UPDATED_BY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "UPDATED_DATE":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.UPDATED_DATE = myDataRecord.GetDateTime(i);
              break;
            }
            break;
          case "EQUIVALENT_CRNCY":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.EQUIVALENT_CRNCY = myDataRecord.GetString(i);
              break;
            }
            break;
          case "EQUIVALENT_AMOUNT":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.EQUIVALENT_AMOUNT = myDataRecord.GetDouble(i);
              break;
            }
            break;
          case "REMARKS":
            if (!myDataRecord.IsDBNull(i))
            {
              cfcsInvoiceLog.REMARKS = myDataRecord.GetString(i);
              break;
            }
            break;
          default:
            throw new Exception("New column found in CFCS_INVOICE_LOG or column name not matched, verify data persistence over class", new Exception("myCFCS_INVOICE_LOG filling failed"));
        }
      }
      return cfcsInvoiceLog;
    }
  }
}
