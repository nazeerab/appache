﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_COLC_REF_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.DAL;

namespace BackEndLayers.BLL
{
  public class CFCS_COLC_REF_Manager
  {
    public static string Get(string companyCode)
    {
      Status status1 = new Status();
      Status status2 = CFCS_COLC_REF_DB.Get(companyCode, "CFCREF");
      if (status2.Code == "FAILED")
        return string.Empty;
      return status2.Description;
    }
  }
}
