﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BLL.CFCS_CUSTOMERS_Manager
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO;
using BackEndLayers.BO.Collections;
using BackEndLayers.BO.OSCUSDAT;
using BackEndLayers.DAL;
using BackEndLayers.Log;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BackEndLayers.BLL
{
  public class CFCS_CUSTOMERS_Manager
  {
    public static bool IsValidCustomer(string cutomerId, string companyCode)
    {
      bool flag = false;
      CFCS_CUSTOMERS cfcsCustomers1 = new CFCS_CUSTOMERS();
      CFCS_CUSTOMERS cfcsCustomers2 = CFCS_CUSTOMERS_DB.Get("Channel", Codes.CompanyCode, cutomerId, "CUSTINQ");
      if (cfcsCustomers2 != null && cfcsCustomers2.CUSTOMER_ID.Trim().ToLower() == cutomerId.Trim().ToLower())
        flag = true;
      return flag;
    }

    public static CFCS_CUSTOMERS Get(string cutomerId, string companyCode)
    {
      CFCS_CUSTOMERS cfcsCustomers = new CFCS_CUSTOMERS();
      return CFCS_CUSTOMERS_DB.Get("Channel", companyCode, cutomerId, "CUSTINQ");
    }

    public static CFCS_CUSTOMERS_List Get(
      List<MessageBodyCustomerInfo> CusInfo,
      string companyCode)
    {
      CFCS_CUSTOMERS_List cfcsCustomersList = new CFCS_CUSTOMERS_List();
      CFCS_CUSTOMERS cfcsCustomers = new CFCS_CUSTOMERS();
      for (int index = 0; index < CusInfo.Count<MessageBodyCustomerInfo>(); ++index)
        cfcsCustomersList.Add(new CFCS_CUSTOMERS()
        {
          STATUS = CusInfo[index].ActionFlag.Trim(),
          CUSTOMER_ID = CusInfo[index].CustomerID.Trim(),
          CUSTOMER_TYPE = CusInfo[index].CustomerType.Trim(),
          CUSTOMER_NAME = CusInfo[index].Name.Trim(),
          CUSTOMER_CITY = CusInfo[index].City.Trim(),
          COMP_CODE = companyCode.Trim()
        });
      return cfcsCustomersList;
    }

    public static Status Save(CFCS_CUSTOMERS Customer)
    {
      return CFCS_CUSTOMERS_DB.Save(Customer);
    }

    public static Status Save(
      List<MessageBodyCustomerInfo> TCustomers,
      CFCS_CUSTOMERS_List VCustomers,
      string fileName)
    {
      Status status = new Status();
      string[] sucess_Status = new string[VCustomers.Count<CFCS_CUSTOMERS>()];
      LogOSCUSDAT logOscusdat = new LogOSCUSDAT();
      for (int index = 0; index < VCustomers.Count<CFCS_CUSTOMERS>(); ++index)
      {
        try
        {
          status = new Status();
          status = CFCS_CUSTOMERS_Manager.Save(VCustomers[index]);
          sucess_Status[index] = !(status.Code != "0000") ? "OK" : "FAILED | " + status.Code + " | " + status.Description;
        }
        catch (Exception ex)
        {
          status.Code = "FAILED";
          status.Code = ex.Message;
        }
      }
      logOscusdat.Log(TCustomers, VCustomers, fileName, sucess_Status);
      status.Code = "OK";
      status.Description = "OK";
      return status;
    }
  }
}
