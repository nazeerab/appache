﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.OSCUSDAT.Message
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.OSCUSDAT
{
  [XmlRoot(IsNullable = false, Namespace = "")]
  [DesignerCategory("code")]
  [XmlType(AnonymousType = true)]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DebuggerStepThrough]
  [Serializable]
  public class Message
  {
    private object[] itemsField;

    [XmlElement("Body", typeof (MessageBody), Form = XmlSchemaForm.Unqualified)]
    [XmlElement("Header", typeof (MessageHeader), Form = XmlSchemaForm.Unqualified)]
    public object[] Items
    {
      get
      {
        return this.itemsField;
      }
      set
      {
        this.itemsField = value;
      }
    }
  }
}
