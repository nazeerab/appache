﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Collections.TransactionRef_List
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using BackEndLayers.BO.ISCCON;
using System.Collections.Generic;

namespace BackEndLayers.BO.Collections
{
  public class TransactionRef_List : List<TransactionRef>
  {
  }
}
