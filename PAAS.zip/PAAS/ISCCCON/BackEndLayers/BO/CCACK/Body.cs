﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Body
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.Collections;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "Body")]
  [Serializable]
  public class Body
  {
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(ElementName = "CreditConfirmationAck", IsNullable = false, Type = typeof (CreditConfirmationAck))]
    public CreditConfirmationAckCollection __CreditConfirmationAckCollection;

    [DispId(-4)]
    public IEnumerator GetEnumerator()
    {
      return this.CreditConfirmationAckCollection.GetEnumerator();
    }

    public CreditConfirmationAck Add(CreditConfirmationAck obj)
    {
      return this.CreditConfirmationAckCollection.Add(obj);
    }

    [XmlIgnore]
    public CreditConfirmationAck this[int index]
    {
      get
      {
        return this.CreditConfirmationAckCollection[index];
      }
    }

    [XmlIgnore]
    public int Count
    {
      get
      {
        return this.CreditConfirmationAckCollection.Count;
      }
    }

    public void Clear()
    {
      this.CreditConfirmationAckCollection.Clear();
    }

    public CreditConfirmationAck Remove(int index)
    {
      CreditConfirmationAck creditConfirmationAck = this.CreditConfirmationAckCollection[index];
      this.CreditConfirmationAckCollection.Remove(creditConfirmationAck);
      return creditConfirmationAck;
    }

    public void Remove(object obj)
    {
      this.CreditConfirmationAckCollection.Remove(obj);
    }

    [XmlIgnore]
    public CreditConfirmationAckCollection CreditConfirmationAckCollection
    {
      get
      {
        if (this.__CreditConfirmationAckCollection == null)
          this.__CreditConfirmationAckCollection = new CreditConfirmationAckCollection();
        return this.__CreditConfirmationAckCollection;
      }
      set
      {
        this.__CreditConfirmationAckCollection = value;
      }
    }
  }
}
