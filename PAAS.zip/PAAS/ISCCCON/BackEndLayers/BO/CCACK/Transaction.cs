﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Transaction
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.ComponentModel;
using System.Xml.Serialization;
using Validation;

namespace BackEndLayers.BO.CCACK
{
  [XmlType(TypeName = "Transaction")]
  [Serializable]
  public class Transaction
  {
    private string _tuxMsgIn = string.Empty;
    private string _tuxMsgOut = string.Empty;
    private bool _isTux = false;
    private string _dbFailReason = string.Empty;
    private string _tuxFailReason = string.Empty;
    private bool _isDb = false;
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(DataType = "string", ElementName = "SequenceNumber", IsNullable = false)]
    public string __SequenceNumber;
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(DataType = "string", ElementName = "AckNumber", IsNullable = false)]
    public string __AckNumber;
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(DataType = "string", ElementName = "StatusCode", IsNullable = false)]
    public string __StatusCode;
    [XmlElement(DataType = "string", ElementName = "StatusDetail", IsNullable = false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public string __StatusDetail;

    [XmlIgnore]
    [NotEmptyStringValidator("SequenceNumber should not be empty.")]
    public string SequenceNumber
    {
      get
      {
        return this.__SequenceNumber;
      }
      set
      {
        this.__SequenceNumber = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("AckNumber should not be empty.")]
    public string AckNumber
    {
      get
      {
        return this.__AckNumber;
      }
      set
      {
        this.__AckNumber = value;
      }
    }

    [NotEmptyStringValidator("StatusCode should not be empty.")]
    [XmlIgnore]
    public string StatusCode
    {
      get
      {
        return this.__StatusCode;
      }
      set
      {
        this.__StatusCode = value;
      }
    }

    [XmlIgnore]
    [NotEmptyStringValidator("StatusDetail should not be empty.")]
    public string StatusDetail
    {
      get
      {
        return this.__StatusDetail;
      }
      set
      {
        this.__StatusDetail = value;
      }
    }

    public string TuxMsgIn
    {
      get
      {
        return this._tuxMsgIn;
      }
      set
      {
        this._tuxMsgIn = value;
      }
    }

    public string TuxMsgOut
    {
      get
      {
        return this._tuxMsgOut;
      }
      set
      {
        this._tuxMsgOut = value;
      }
    }

    public bool IsTux
    {
      get
      {
        return this._isTux;
      }
      set
      {
        this._isTux = value;
      }
    }

    public string DbFailReason
    {
      get
      {
        return this._dbFailReason;
      }
      set
      {
        this._dbFailReason = value;
      }
    }

    public string TuxFailReason
    {
      get
      {
        return this._tuxFailReason;
      }
      set
      {
        this._tuxFailReason = value;
      }
    }

    public bool IsDb
    {
      get
      {
        return this._isDb;
      }
      set
      {
        this._isDb = value;
      }
    }
  }
}
