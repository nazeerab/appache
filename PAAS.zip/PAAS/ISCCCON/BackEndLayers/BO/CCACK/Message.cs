﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.CCACK.Message
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.ComponentModel;
using System.Xml.Serialization;

namespace BackEndLayers.BO.CCACK
{
  [XmlRoot(ElementName = "Message", IsNullable = false)]
  [Serializable]
  public class Message
  {
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(ElementName = "Header", IsNullable = false, Type = typeof (Header))]
    public HeaderCollection __HeaderCollection;
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [XmlElement(ElementName = "Body", IsNullable = false, Type = typeof (Body))]
    public BodyCollection __BodyCollection;

    [XmlIgnore]
    public HeaderCollection HeaderCollection
    {
      get
      {
        if (this.__HeaderCollection == null)
          this.__HeaderCollection = new HeaderCollection();
        return this.__HeaderCollection;
      }
      set
      {
        this.__HeaderCollection = value;
      }
    }

    [XmlIgnore]
    public BodyCollection BodyCollection
    {
      get
      {
        if (this.__BodyCollection == null)
          this.__BodyCollection = new BodyCollection();
        return this.__BodyCollection;
      }
      set
      {
        this.__BodyCollection = value;
      }
    }
  }
}
