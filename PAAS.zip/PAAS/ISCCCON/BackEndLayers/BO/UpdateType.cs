﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.UpdateType
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public enum UpdateType
  {
    I = 1,
    G = 2,
  }
}
