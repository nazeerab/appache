﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.Fin_In_TuxMsg
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System.Text;

namespace BackEndLayers.BO
{
  public class Fin_In_TuxMsg
  {
    private string _SourceSystem = string.Empty;
    private string _RequestFunction = string.Empty;
    private string _ServerDate = string.Empty;
    private string _ServerTime = string.Empty;
    private string _FTSReferece = string.Empty;
    private string _FTSTransFunc = string.Empty;
    private string _CammTranNum = string.Empty;
    private string _NoOfBlocks = string.Empty;
    private string _CurrBlockNo = string.Empty;
    private string _NoOfItems = string.Empty;
    private string _CustomerCode = string.Empty;
    private string _AccountNo = string.Empty;
    private string _InitBranch = string.Empty;
    private string _InitOfficer = string.Empty;
    private string _CardNumber = string.Empty;
    private string _CAMMActionCode = string.Empty;
    private string _LastUpdateDate = string.Empty;
    private string _LastUpdateTime = string.Empty;
    private string _TransactionStatus = string.Empty;
    private string _FTSActionCode = string.Empty;
    private string _ProcessingSeq = string.Empty;
    private string _DetailLength = string.Empty;
    private string _TransType = string.Empty;
    private string _TransDate = string.Empty;
    private string _ValueDate = string.Empty;
    private string _TransCrncy = string.Empty;
    private string _TransAmount = string.Empty;
    private string _TransAmountSar = string.Empty;
    private string _GenNarrative = string.Empty;
    private string _ScrNarrative = string.Empty;
    private string _DebitAcctNo = string.Empty;
    private string _DebitAcctCrncy = string.Empty;
    private string _DebitAmount = string.Empty;
    private string _DebitCrncyRate = string.Empty;
    private string _DebitValueDate = string.Empty;
    private string _DebitSrfFlag = string.Empty;
    private string _DebitBranch = string.Empty;
    private string _CreditAcctNo = string.Empty;
    private string _CreditAcctCrncy = string.Empty;
    private string _CreditAmount = string.Empty;
    private string _CreditCrncyRate = string.Empty;
    private string _CreditValueDate = string.Empty;
    private string _CreditSrfFlag = string.Empty;
    private string _CreditBranch = string.Empty;
    private string _CommissionCrncy = string.Empty;
    private string _CommissionAmount = string.Empty;
    private string _CommissionAcct = string.Empty;
    private string _ChargesCrncy = string.Empty;
    private string _ChargesAmount = string.Empty;
    private string _ChargesAcct = string.Empty;
    private string _GtdDealTicket = string.Empty;
    private string _InitTime = string.Empty;
    private string _ValidationOfficer = string.Empty;
    private string _ValidationTime = string.Empty;
    private string _AuthorznOfficer = string.Empty;
    private string _AuthorznTime = string.Empty;
    private string _AuthorznReason = string.Empty;
    private string _AuthorznStatus = string.Empty;
    private string _DynamicPartLen = string.Empty;
    private string _StaticPart_ChequeNo = string.Empty;
    private string _StaticPart_Id_Type = string.Empty;
    private string _StaticPart_Id_Number = string.Empty;
    private string _StaticPart_PrintDetail = string.Empty;
    private string _StaticPart_MailAdvice = string.Empty;
    private string _CompanyCustomerId = string.Empty;
    private string _CompanyCode = string.Empty;
    private string _InvoiceNumber = string.Empty;
    private string _InvoiceDate = string.Empty;
    private string _PaymentsType = string.Empty;
    private string _ChannelPaymentReference = string.Empty;
    private string _CompanyAckType = string.Empty;
    private string _CustomerDebitAcct = string.Empty;

    public string SourceSystem
    {
      get
      {
        return this._SourceSystem;
      }
      set
      {
        this._SourceSystem = value;
      }
    }

    public string RequestFunction
    {
      get
      {
        return this._RequestFunction;
      }
      set
      {
        this._RequestFunction = value;
      }
    }

    public string ServerDate
    {
      get
      {
        return this._ServerDate;
      }
      set
      {
        this._ServerDate = value;
      }
    }

    public string ServerTime
    {
      get
      {
        return this._ServerTime;
      }
      set
      {
        this._ServerTime = value;
      }
    }

    public string FTSReferece
    {
      get
      {
        return this._FTSReferece;
      }
      set
      {
        this._FTSReferece = value;
      }
    }

    public string FTSTransFunc
    {
      get
      {
        return this._FTSTransFunc;
      }
      set
      {
        this._FTSTransFunc = value;
      }
    }

    public string CammTranNum
    {
      get
      {
        return this._CammTranNum;
      }
      set
      {
        this._CammTranNum = value;
      }
    }

    public string NoOfBlocks
    {
      get
      {
        return this._NoOfBlocks;
      }
      set
      {
        this._NoOfBlocks = value;
      }
    }

    public string CurrBlockNo
    {
      get
      {
        return this._CurrBlockNo;
      }
      set
      {
        this._CurrBlockNo = value;
      }
    }

    public string NoOfItems
    {
      get
      {
        return this._NoOfItems;
      }
      set
      {
        this._NoOfItems = value;
      }
    }

    public string CustomerCode
    {
      get
      {
        return this._CustomerCode;
      }
      set
      {
        this._CustomerCode = value;
      }
    }

    public string AccountNo
    {
      get
      {
        return this._AccountNo;
      }
      set
      {
        this._AccountNo = value;
      }
    }

    public string InitBranch
    {
      get
      {
        return this._InitBranch;
      }
      set
      {
        this._InitBranch = value;
      }
    }

    public string InitOfficer
    {
      get
      {
        return this._InitOfficer;
      }
      set
      {
        this._InitOfficer = value;
      }
    }

    public string CardNumber
    {
      get
      {
        return this._CardNumber;
      }
      set
      {
        this._CardNumber = value;
      }
    }

    public string CAMMActionCode
    {
      get
      {
        return this._CAMMActionCode;
      }
      set
      {
        this._CAMMActionCode = value;
      }
    }

    public string LastUpdateDate
    {
      get
      {
        return this._LastUpdateDate;
      }
      set
      {
        this._LastUpdateDate = value;
      }
    }

    public string LastUpdateTime
    {
      get
      {
        return this._LastUpdateTime;
      }
      set
      {
        this._LastUpdateTime = value;
      }
    }

    public string TransactionStatus
    {
      get
      {
        return this._TransactionStatus;
      }
      set
      {
        this._TransactionStatus = value;
      }
    }

    public string FTSActionCode
    {
      get
      {
        return this._FTSActionCode;
      }
      set
      {
        this._FTSActionCode = value;
      }
    }

    public string ProcessingSeq
    {
      get
      {
        return this._ProcessingSeq;
      }
      set
      {
        this._ProcessingSeq = value;
      }
    }

    public string DetailLength
    {
      get
      {
        return this._DetailLength;
      }
      set
      {
        this._DetailLength = value;
      }
    }

    public string TransType
    {
      get
      {
        return this._TransType;
      }
      set
      {
        this._TransType = value;
      }
    }

    public string TransDate
    {
      get
      {
        return this._TransDate;
      }
      set
      {
        this._TransDate = value;
      }
    }

    public string ValueDate
    {
      get
      {
        return this._ValueDate;
      }
      set
      {
        this._ValueDate = value;
      }
    }

    public string TransCrncy
    {
      get
      {
        return this._TransCrncy;
      }
      set
      {
        this._TransCrncy = value;
      }
    }

    public string TransAmount
    {
      get
      {
        return this._TransAmount;
      }
      set
      {
        this._TransAmount = value;
      }
    }

    public string TransAmountSar
    {
      get
      {
        return this._TransAmountSar;
      }
      set
      {
        this._TransAmountSar = value;
      }
    }

    public string GenNarrative
    {
      get
      {
        return this._GenNarrative;
      }
      set
      {
        this._GenNarrative = value;
      }
    }

    public string ScrNarrative
    {
      get
      {
        return this._ScrNarrative;
      }
      set
      {
        this._ScrNarrative = value;
      }
    }

    public string DebitAcctNo
    {
      get
      {
        return this._DebitAcctNo;
      }
      set
      {
        this._DebitAcctNo = value;
      }
    }

    public string DebitAcctCrncy
    {
      get
      {
        return this._DebitAcctCrncy;
      }
      set
      {
        this._DebitAcctCrncy = value;
      }
    }

    public string DebitAmount
    {
      get
      {
        return this._DebitAmount;
      }
      set
      {
        this._DebitAmount = value;
      }
    }

    public string DebitCrncyRate
    {
      get
      {
        return this._DebitCrncyRate;
      }
      set
      {
        this._DebitCrncyRate = value;
      }
    }

    public string DebitValueDate
    {
      get
      {
        return this._DebitValueDate;
      }
      set
      {
        this._DebitValueDate = value;
      }
    }

    public string DebitSrfFlag
    {
      get
      {
        return this._DebitSrfFlag;
      }
      set
      {
        this._DebitSrfFlag = value;
      }
    }

    public string DebitBranch
    {
      get
      {
        return this._DebitBranch;
      }
      set
      {
        this._DebitBranch = value;
      }
    }

    public string CreditAcctNo
    {
      get
      {
        return this._CreditAcctNo;
      }
      set
      {
        this._CreditAcctNo = value;
      }
    }

    public string CreditAcctCrncy
    {
      get
      {
        return this._CreditAcctCrncy;
      }
      set
      {
        this._CreditAcctCrncy = value;
      }
    }

    public string CreditAmount
    {
      get
      {
        return this._CreditAmount;
      }
      set
      {
        this._CreditAmount = value;
      }
    }

    public string CreditCrncyRate
    {
      get
      {
        return this._CreditCrncyRate;
      }
      set
      {
        this._CreditCrncyRate = value;
      }
    }

    public string CreditValueDate
    {
      get
      {
        return this._CreditValueDate;
      }
      set
      {
        this._CreditValueDate = value;
      }
    }

    public string CreditSrfFlag
    {
      get
      {
        return this._CreditSrfFlag;
      }
      set
      {
        this._CreditSrfFlag = value;
      }
    }

    public string CreditBranch
    {
      get
      {
        return this._CreditBranch;
      }
      set
      {
        this._CreditBranch = value;
      }
    }

    public string CommissionCrncy
    {
      get
      {
        return this._CommissionCrncy;
      }
      set
      {
        this._CommissionCrncy = value;
      }
    }

    public string CommissionAmount
    {
      get
      {
        return this._CommissionAmount;
      }
      set
      {
        this._CommissionAmount = value;
      }
    }

    public string CommissionAcct
    {
      get
      {
        return this._CommissionAcct;
      }
      set
      {
        this._CommissionAcct = value;
      }
    }

    public string ChargesCrncy
    {
      get
      {
        return this._ChargesCrncy;
      }
      set
      {
        this._ChargesCrncy = value;
      }
    }

    public string ChargesAmount
    {
      get
      {
        return this._ChargesAmount;
      }
      set
      {
        this._ChargesAmount = value;
      }
    }

    public string ChargesAcct
    {
      get
      {
        return this._ChargesAcct;
      }
      set
      {
        this._ChargesAcct = value;
      }
    }

    public string GtdDealTicket
    {
      get
      {
        return this._GtdDealTicket;
      }
      set
      {
        this._GtdDealTicket = value;
      }
    }

    public string InitTime
    {
      get
      {
        return this._InitTime;
      }
      set
      {
        this._InitTime = value;
      }
    }

    public string ValidationOfficer
    {
      get
      {
        return this._ValidationOfficer;
      }
      set
      {
        this._ValidationOfficer = value;
      }
    }

    public string ValidationTime
    {
      get
      {
        return this._ValidationTime;
      }
      set
      {
        this._ValidationTime = value;
      }
    }

    public string AuthorznOfficer
    {
      get
      {
        return this._AuthorznOfficer;
      }
      set
      {
        this._AuthorznOfficer = value;
      }
    }

    public string AuthorznTime
    {
      get
      {
        return this._AuthorznTime;
      }
      set
      {
        this._AuthorznTime = value;
      }
    }

    public string AuthorznReason
    {
      get
      {
        return this._AuthorznReason;
      }
      set
      {
        this._AuthorznReason = value;
      }
    }

    public string AuthorznStatus
    {
      get
      {
        return this._AuthorznStatus;
      }
      set
      {
        this._AuthorznStatus = value;
      }
    }

    public string DynamicPartLen
    {
      get
      {
        return this._DynamicPartLen;
      }
      set
      {
        this._DynamicPartLen = value;
      }
    }

    public string StaticPart_ChequeNo
    {
      get
      {
        return this._StaticPart_ChequeNo;
      }
      set
      {
        this._StaticPart_ChequeNo = value;
      }
    }

    public string StaticPart_Id_Type
    {
      get
      {
        return this._StaticPart_Id_Type;
      }
      set
      {
        this._StaticPart_Id_Type = value;
      }
    }

    public string StaticPart_Id_Number
    {
      get
      {
        return this._StaticPart_Id_Number;
      }
      set
      {
        this._StaticPart_Id_Number = value;
      }
    }

    public string StaticPart_PrintDetail
    {
      get
      {
        return this._StaticPart_PrintDetail;
      }
      set
      {
        this._StaticPart_PrintDetail = value;
      }
    }

    public string StaticPart_MailAdvice
    {
      get
      {
        return this._StaticPart_MailAdvice;
      }
      set
      {
        this._StaticPart_MailAdvice = value;
      }
    }

    public string CompanyCustomerId
    {
      get
      {
        return this._CompanyCustomerId;
      }
      set
      {
        this._CompanyCustomerId = value;
      }
    }

    public string CompanyCode
    {
      get
      {
        return this._CompanyCode;
      }
      set
      {
        this._CompanyCode = value;
      }
    }

    public string InvoiceNumber
    {
      get
      {
        return this._InvoiceNumber;
      }
      set
      {
        this._InvoiceNumber = value;
      }
    }

    public string InvoiceDate
    {
      get
      {
        return this._InvoiceDate;
      }
      set
      {
        this._InvoiceDate = value;
      }
    }

    public string PaymentsType
    {
      get
      {
        return this._PaymentsType;
      }
      set
      {
        this._PaymentsType = value;
      }
    }

    public string ChannelPaymentReference
    {
      get
      {
        return this._ChannelPaymentReference;
      }
      set
      {
        this._ChannelPaymentReference = value;
      }
    }

    public string CompanyAckType
    {
      get
      {
        return this._CompanyAckType;
      }
      set
      {
        this._CompanyAckType = value;
      }
    }

    public string CustomerDebitAcct
    {
      get
      {
        return this._CustomerDebitAcct;
      }
      set
      {
        this._CustomerDebitAcct = value;
      }
    }

    public string print()
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(this.SourceSystem);
      stringBuilder.Append(this.RequestFunction);
      stringBuilder.Append(this.ServerDate);
      stringBuilder.Append(this.ServerTime);
      stringBuilder.Append(this.FTSReferece);
      stringBuilder.Append(this.FTSTransFunc);
      stringBuilder.Append(this.CammTranNum);
      stringBuilder.Append(this.NoOfBlocks);
      stringBuilder.Append(this.CurrBlockNo);
      stringBuilder.Append(this.NoOfItems);
      stringBuilder.Append(this.CustomerCode);
      stringBuilder.Append(this.AccountNo);
      stringBuilder.Append(this.InitBranch);
      stringBuilder.Append(this.InitOfficer);
      stringBuilder.Append(this.CardNumber);
      stringBuilder.Append(this.CAMMActionCode);
      stringBuilder.Append(this.LastUpdateDate);
      stringBuilder.Append(this.LastUpdateTime);
      stringBuilder.Append(this.TransactionStatus);
      stringBuilder.Append(this.FTSActionCode);
      stringBuilder.Append(this.ProcessingSeq);
      stringBuilder.Append(this.DetailLength);
      stringBuilder.Append(this.TransType);
      stringBuilder.Append(this.TransDate);
      stringBuilder.Append(this.ValueDate);
      stringBuilder.Append(this.TransCrncy);
      stringBuilder.Append(this.TransAmount);
      stringBuilder.Append(this.TransAmountSar);
      stringBuilder.Append(this.GenNarrative);
      stringBuilder.Append(this.ScrNarrative);
      stringBuilder.Append(this.DebitAcctNo);
      stringBuilder.Append(this.DebitAcctCrncy);
      stringBuilder.Append(this.DebitAmount);
      stringBuilder.Append(this.DebitCrncyRate);
      stringBuilder.Append(this.DebitValueDate);
      stringBuilder.Append(this.DebitSrfFlag);
      stringBuilder.Append(this.DebitBranch);
      stringBuilder.Append(this.CreditAcctNo);
      stringBuilder.Append(this.CreditAcctCrncy);
      stringBuilder.Append(this.CreditAmount);
      stringBuilder.Append(this.CreditCrncyRate);
      stringBuilder.Append(this.CreditValueDate);
      stringBuilder.Append(this.CreditSrfFlag);
      stringBuilder.Append(this.CreditBranch);
      stringBuilder.Append(this.CommissionCrncy);
      stringBuilder.Append(this.CommissionAmount);
      stringBuilder.Append(this.CommissionAcct);
      stringBuilder.Append(this.ChargesCrncy);
      stringBuilder.Append(this.ChargesAmount);
      stringBuilder.Append(this.ChargesAcct);
      stringBuilder.Append(this.GtdDealTicket);
      stringBuilder.Append(this.InitTime);
      stringBuilder.Append(this.ValidationOfficer);
      stringBuilder.Append(this.ValidationTime);
      stringBuilder.Append(this.AuthorznOfficer);
      stringBuilder.Append(this.AuthorznTime);
      stringBuilder.Append(this.AuthorznReason);
      stringBuilder.Append(this.AuthorznStatus);
      stringBuilder.Append(this.DynamicPartLen);
      stringBuilder.Append(this.StaticPart_ChequeNo);
      stringBuilder.Append(this.StaticPart_Id_Type);
      stringBuilder.Append(this.StaticPart_Id_Number);
      stringBuilder.Append(this.StaticPart_PrintDetail);
      stringBuilder.Append(this.StaticPart_MailAdvice);
      stringBuilder.Append(this.CompanyCustomerId);
      stringBuilder.Append(this.CompanyCode);
      stringBuilder.Append(this.InvoiceNumber);
      stringBuilder.Append(this.InvoiceDate);
      stringBuilder.Append(this.PaymentsType);
      stringBuilder.Append(this.ChannelPaymentReference);
      stringBuilder.Append(this.CompanyAckType);
      stringBuilder.Append(this.CustomerDebitAcct);
      return stringBuilder.ToString();
    }
  }
}
