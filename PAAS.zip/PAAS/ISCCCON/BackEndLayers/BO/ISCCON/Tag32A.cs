﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.Tag32A
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;

namespace BackEndLayers.BO.ISCCON
{
  public class Tag32A
  {
    private DateTime _transDate = new DateTime();
    private string _creditAcctCrcny = string.Empty;
    private double _creditAmt = 0.0;

    public DateTime TransDate
    {
      get
      {
        return this._transDate;
      }
      set
      {
        this._transDate = value;
      }
    }

    public string CreditAcctCrcny
    {
      get
      {
        return this._creditAcctCrcny;
      }
      set
      {
        this._creditAcctCrcny = value;
      }
    }

    public double CreditAmt
    {
      get
      {
        return this._creditAmt;
      }
      set
      {
        this._creditAmt = value;
      }
    }
  }
}
