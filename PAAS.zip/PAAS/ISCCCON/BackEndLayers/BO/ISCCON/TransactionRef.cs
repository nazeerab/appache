﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.TransactionRef
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

namespace BackEndLayers.BO.ISCCON
{
  public class TransactionRef
  {
    private string _transRef = string.Empty;
    private string _sequenceNo = string.Empty;

    public string TransRef
    {
      get
      {
        return this._transRef;
      }
      set
      {
        this._transRef = value;
      }
    }

    public string SequenceNo
    {
      get
      {
        return this._sequenceNo;
      }
      set
      {
        this._sequenceNo = value;
      }
    }
  }
}
