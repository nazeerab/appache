﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.ISCCON.MessageHeader
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BackEndLayers.BO.ISCCON
{
  [XmlType(AnonymousType = true)]
  [DebuggerStepThrough]
  [GeneratedCode("xsd", "2.0.50727.3038")]
  [DesignerCategory("code")]
  [Serializable]
  public class MessageHeader
  {
    private string senderField;
    private string receiverField;
    private string messageTypeField;
    private string messageDescriptionField;
    private string timeStampField;

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string Sender
    {
      get
      {
        return this.senderField;
      }
      set
      {
        this.senderField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string Receiver
    {
      get
      {
        return this.receiverField;
      }
      set
      {
        this.receiverField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string MessageType
    {
      get
      {
        return this.messageTypeField;
      }
      set
      {
        this.messageTypeField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string MessageDescription
    {
      get
      {
        return this.messageDescriptionField;
      }
      set
      {
        this.messageDescriptionField = value;
      }
    }

    [XmlElement(Form = XmlSchemaForm.Unqualified)]
    public string TimeStamp
    {
      get
      {
        return this.timeStampField;
      }
      set
      {
        this.timeStampField = value;
      }
    }
  }
}
