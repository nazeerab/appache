﻿// Decompiled with JetBrains decompiler
// Type: BackEndLayers.BO.PayFile
// Assembly: BackEndLayers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: FA0FE27F-99A3-49BC-A420-D377E6C9ACB0
// Assembly location: C:\Users\ahye\OneDrive\Documents\Macug\PACK_Payroll\PASS\CFC_ISCCCON\BackEndLayers.dll

namespace BackEndLayers.BO
{
  public class PayFile
  {
    private string _path = string.Empty;
    private string _name = string.Empty;
    private string _fileRef = string.Empty;

    public string Path
    {
      get
      {
        return this._path;
      }
      set
      {
        this._path = value;
      }
    }

    public string Name
    {
      get
      {
        return this._name;
      }
      set
      {
        this._name = value;
      }
    }

    public string FileRef
    {
      get
      {
        return this._fileRef;
      }
      set
      {
        this._fileRef = value;
      }
    }
  }
}
